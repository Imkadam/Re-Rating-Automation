# ER/BDA Manual Re-rating Toolkit

A Streamlit app that automates the processes in the ER/BDA Manual Re-rating procedure.

Every output is an Excel workbook in which **each calculated cell is a live
formula**, not a baked-in number. The Current and Proposed net rate sheets are
embedded as tabs in the output, so you can click any cost cell in Excel and see
the exact `VLOOKUP` / `MATCH` an analyst would have written by hand.

---

## Running it

```bat
run_app.bat
```

First run creates a virtual environment and installs the dependencies; later
runs just start the app. Manually:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

The app opens at <http://localhost:8501>.

---

## Layout

```
app.py                      single entry point - sidebar picks the process
requirements.txt
run_app.bat

core/                       shared building blocks used by every process
  config.py                 zone map, column names, exclusion rules, formats
  ratesheet.py              net rate sheet parser - finds every rate table
  shipment.py               shipment data load, cleanse, zone normalisation
  dim.py                    DIM re-ordering + MBW surcharge rules
  surcharge.py              Surcharge Pricing Template parser, fuel rules
  formulas.py               Excel formula builders (VLOOKUP / INDEX / SUMIFS)
  evaluate.py               resolves the same lookups in Python, for the
                            on-screen Summary
  excel_writer.py           workbook assembly, styling, rate-sheet embedding
  registry.py               process registry - the sidebar reads this

processes/                  one module per process (calculation)
  rate_comparison.py        ✅ Rate Comparison
  dim_mbw.py                ✅ DIM Change & MBW
  surcharge_analysis.py     ✅ Surcharge Analysis

ui/                         one module per process (screen)
  theme.py                  FedEx palette, masthead, cards, chips
  rate_comparison_ui.py     ✅ Rate Comparison
  dim_mbw_ui.py             ✅ DIM Change & MBW
  surcharge_ui.py           ✅ Surcharge Analysis — SurchargeStep, its
                            reusable Template/Surcharges/Fuel sub-flow, is
                            also embedded by the other two screens

.streamlit/config.toml      Streamlit theme (FedEx purple / orange)
```

### Look and feel

The UI uses the FedEx corporate palette — purple `#4D148C` and orange
`#FF6600` — applied in one place, `ui/theme.py`, plus `.streamlit/config.toml`.
Every process screen gets the same masthead, section rules, cards and chips, so
a new process inherits the styling for free and a rebrand is a single edit.

### Adding a process

1. Write `processes/<name>.py` with a `run(...)` function returning the workbook.
2. Write `ui/<name>_ui.py` with a `render()` function.
3. Add one `Process(...)` entry to `core/registry.py`.

`app.py` never changes.

---

## Process 1 — Rate Comparison ✅

Implements the *Rate comparison* procedure.

| Tab | What happens |
| --- | --- |
| **1 · Inputs** | Upload the Shipment Detail extract, the Current / Proposed Net Rate Sheets and, optionally, a List Rate Sheet. Rate tables are detected automatically, along with each sheet's customer, effective date and any *"refer to list rates"* notices. |
| **2 · Cleanse** | The six exclusion rules from procedure step 2, each toggleable, with a preview of how many rows each removes. |
| **3 · Rate sheet mapping** | Shows which rate table will rate each service, and lets you override it (billing type, heavyweight table, …). |
| **4 · Missing rates** | Services with no table on the Proposed sheet — see below. |
| **5 · Surcharges** | Optional — append a Surcharge Analysis onto this same workbook. See *Combined with Surcharge Analysis* below. |
| **6 · Build** | Date range, CHT ID, notes, fuel rates and the heavyweight method, then produces the workbook and shows the **Summary tab on screen** before you download it. |

### Rules implemented

- **Cleansing** — drops services not under review, $0/blank list freight, non-US
  domestic zones (51, 00), multi-piece rows, non-US origin and destination.
- **Retained columns** — procedure step 3.
- **Zone normalisation** — alphabetical zones translated via the `Zone Map` tab
  (A→17 Alaska, H→9 Hawaii, M→99 Military, P→10 Puerto Rico, Z→26 other).
- **Envelope / Letter** — always rated at the 1 lb Envelope rate, whatever the
  rated weight.
- **Pak** — Pak rates up to 2 lbs, Customer Packaging above that or when the
  rate sheet carries no Pak table.
- **First Overnight** — when the Proposed sheet has no FO table, you choose how
  to fill the gap; see *Missing Proposed rates* below.
- **Heavyweight (>150 lbs)** — see the dedicated section below.
- **Freight services** — approximate match on a helper column of weight-range
  start weights, `× rated weight`.
- **Missing rates** — left blank rather than guessed, and counted in the UI.

### Missing Proposed rates

Procedure, *First Overnight (FO) Shipments*:

> If Proposed Rates are unavailable and both Net Rate Sheets are from the same
> year, use the Current Rates as the Proposed Rates. If the Current and
> Proposed Net Rate Sheets are from different years, use FO List Rates to rate
> the shipments.

The app reads the **effective date off each rate sheet**, works out whether the
two are from the same year, and pre-selects the option the procedure points at.
It also surfaces any *"Please refer to list rates for this service"* notice the
Proposed sheet carries. The choice is yours on the **Missing rates** tab, per
service:

| Option | Effect |
| --- | --- |
| **Use the Current rates as the Proposed rates** | Same-year rule. Proposed formulas point at the `current_rates` tab, so impact is $0 for that service. |
| **Use List Rates** | Different-year rule. Requires a List Rate Sheet upload; formulas point at a `list_rates` tab. Two sub-options: what to do when the list sheet has no table for that service (below), and whether to put the Current side on list rates too. |
| **Exclude this service** | Those shipments drop out of the analysis entirely and are counted in the cleansing notes. |
| **Leave the Proposed cost blank** | Rows stay in, Proposed cost is empty, and they are reported as unrated. |

**When the List Rate Sheet doesn't cover a service.** A list sheet rarely
carries every product, so *Use List Rates* has a per-service fallback:

| Fallback | Effect |
| --- | --- |
| **Use the Current rates for that service** (default) | Proposed formulas point at `current_rates` for that product only. |
| **Leave the Proposed cost blank** | That product stays unrated and is counted as such. |

The choice is per product, so one analysis can mix all three sources — the
services the list sheet covers rate from `list_rates`, the ones it doesn't fall
back to `current_rates`, and everything present on the Proposed sheet rates
from `proposed_rates`. The screen tells you, per service, whether the list
sheet actually has a table for it before you choose. When several services are
missing at once, a **Set every service below to…** control applies one strategy
to all of them in a click.

Whichever is chosen, it is recorded in three places: the Summary notes, a
**Proposed Rate Source** column on the Rate Detail tab, and an on-screen banner
after the build. Nothing is substituted silently — a service the rules do not
cover is left blank rather than guessed, so a missing table can never quietly
become a fabricated saving.

### Heavyweight shipments (> 150 lbs)

Implements the *Heavyweight Shipment Re-Rating* procedure literally.

**The per-pound row.** When the rate sheets are embedded, a row is inserted
**immediately below the 150 lb rate row** of every standard service table —
exactly where the procedure says to put it. Column A is labelled `AS`, and each
zone holds a live formula:

```excel
A4620 = "AS"      B4620 = =B4619/150      …      P4620 = =P4619/150
```

So the derived per-pound rate is visible and checkable on the rate sheet
itself rather than buried inside the shipment formula. Because inserting rows
moves everything below them, every block's coordinates are re-pointed through
the same shift, so all other lookups stay correct.

**The shipment formula** is then the analyst's formula verbatim —
`Shipment Rate = Per-Pound Rate × Rated Weight`:

```excel
=VLOOKUP("AS",current_rates!$A$4620:$P$4620,
   MATCH($J2,current_rates!$A$4468:$P$4468,0),FALSE)*$K2
```

**Express heavyweight.** Where a service carries its own heavyweight table
below the standard table (the `100 - 150`, `151 - 299`, `300 - 499` … bands),
the procedure says to use an approximate-match lookup on rated weight and zone.
That table's first column is text (`"151 - 299"`), so the approximate match
runs against the highlighted helper column of range start weights:

```excel
=INDEX(current_rates!$A$405:$P$410,
   MATCH($K2,current_rates!$R$405:$R$410,1),
   MATCH($J2,current_rates!$A$404:$P$404,0))*$K2
```

**Choosing between them** — a control on the *Build* tab:

| Method | Behaviour |
| --- | --- |
| **Auto** (default) | Express heavyweight table when the sheet has one, otherwise the derived `AS` row. Matches the procedure's own ordering. |
| **Always per-pound** | Always `150 lb rate ÷ 150 × rated weight`, ignoring any heavyweight table. |
| **Always heavyweight table** | Always the approximate-match table, falling back to the `AS` row only where no table exists. |

The threshold defaults to 150 lbs but is adjustable, and inserting the `AS`
rows can be switched off. The `Method` columns on the Rate Detail tab record
which rule produced each cell, and the Summary notes state how many
heavyweight shipments were rated and under which method.

> Note: for a table that stops short of 150 lbs (Ground Economy tops out at
> 71), the divisor is that table's own maximum weight rather than a hard-coded
> 150.

### The Summary on screen

The downloaded workbook holds live formulas, so the app never sees a number —
which would leave the Summary blank until the file is opened in Excel. Instead
the same lookups are resolved in Python and rendered on the **Build** tab:
headline Current / Proposed / Impact, the full service table with Impact %, and
the notes, assumptions and disclaimer that go into the tab.

Preview and workbook cannot drift apart, because both are driven by the *same*
`RatePlan`, built once per shipment in `plan_rate()`. The plan decides the
table, the sub-section and the heavyweight rule; `formula_for()` renders it as
Excel, `evaluate()` reads the same cells in Python. Add a rule in one place and
both sides get it.

Verified on the sample data: all 23,378 row-level values and every line of the
Summary table match the workbook's own figures after Excel recalculates it —
to the cent.

### Output workbook

| Tab | Contents |
| --- | --- |
| `Summary` | Date range, CHT ID, cleansing notes, assumptions, service table with **live `SUMIFS`** over the detail tab, Impact and Impact %, disclaimer. |
| `Rate Detail` | One row per shipment. `Lookup Weight`, `Current Cost`, `Proposed Cost` and `Impact` are formulas. Two `Method` columns record which rule produced each cell, and `Proposed Rate Source` records whether the Proposed rate came from the Proposed sheet, the Current sheet or list rates. |
| `Shipment Data` | The cleansed dataset, retained columns only. |
| `current_rates` / `proposed_rates` / `list_rates` | The net rate sheets, embedded verbatim, plus the inserted `AS` per-pound rows and a highlighted helper column of weight-range start weights. `list_rates` appears only when a List Rate Sheet is supplied. |
| `Zone Map` | Alpha→numeric zone reference, backing the zone formulas. |

Formatting follows procedure step 10 — money with `$` and no decimals in the
Summary, impact percentages to one decimal, US comma separators.

### Example formulas produced

```excel
Standard package   =IFERROR(VLOOKUP($K2,current_rates!$A$240:$P$389,
                     MATCH($J2,current_rates!$A$233:$P$233,0),FALSE),"")

Envelope / Letter  =IFERROR(INDEX(current_rates!$A$235:$P$235,
                     MATCH($J2,current_rates!$A$233:$P$233,0)),"")

Express
heavyweight        =IFERROR(INDEX(current_rates!$A$405:$P$410,
                     MATCH($K2,current_rates!$R$405:$R$410,1),
                     MATCH($J2,current_rates!$A$404:$P$404,0))*$K2,"")

Heavyweight from
the "AS" row       =IFERROR(VLOOKUP("AS",current_rates!$A$1474:$P$1474,
                     MATCH($J2,current_rates!$A$1322:$P$1322,0),FALSE)*$K2,"")

The "AS" row
itself (on the
rate sheet tab)    =B1473/150

Lookup weight      =IF($H2<=1,1,CEILING($H2,1))

Summary roll-up    =SUMIFS('Rate Detail'!$L$2:$L$11570,
                     'Rate Detail'!$C$2:$C$11570,$B17)
```

---

## Validation

Tested against `Shipment Detail_2479023618.xlsx`:

- The parser's detected lookup ranges match the hand-built ranges in that
  file's `final_rates` tab **exactly** (e.g. Priority Overnight
  `$A$240:$P$389` with header `$A$233`; Ground `$A$1318:$P$1467` with header
  `$A$1316`).
- 11,569 shipments rated; all 23,138 cost formulas recalculated in Excel match
  an independent Python recomputation of the rate sheets — **0 mismatches**.
- Shipment counts per service match the sample exactly (Ground 7,476;
  Multiweight 3,010; Home Delivery 295; Priority Overnight 373 …).
- Heavyweight: 120 synthetic shipments (8 services × 5 weights from 151 to
  2,500 lbs × 3 zones) added to the dataset and re-verified — **0 mismatches**
  in Auto mode, and a separate 54-row check confirmed the `AS` row path
  returns exactly `150 lb rate ÷ 150 × rated weight`. Row-shift correctness is
  covered by the same run: all 11,569 standard rows still tie out after the 24
  per-pound rows are inserted.

> Note: the sample's Summary shows Priority Overnight Current = \$15,832, but
> that is a **stale pasted value** — recalculating the sample's own formulas
> against its own `current_rates` tab gives \$26,587, which is what this app
> produces. Worth confirming with the analyst who built that file.

### Combined with Surcharge Analysis

A request often covers a rate comparison **and** surcharges. Rather than
building two separate workbooks and copying a total between them, the
**Surcharges** tab lets you read a Surcharge Pricing Template right here —
same Template / Surcharges / Fuel & totals flow as the standalone Surcharge
Analysis process — and check *"Include surcharge analysis in this
workbook"*. The build then produces **one file**:

- `Surcharge Detail` and `Surcharge Rules` are added as their own tabs.
- The surcharge Summary section (fuel table, surcharge table, Total Cost
  Components) is written directly onto this workbook's own `Summary` tab,
  immediately after the rate impact table — one Summary, one disclaimer.
- The surcharge fuel calculation's **Transportation cost** is auto-filled
  per OpCo from this analysis's own Current / Proposed cost (see
  `rate_comparison.opco_cost_totals`), matched against the template's OpCo
  names — build the rate comparison once, revisit the **Surcharges** tab,
  and the transportation figures are already there. Every figure stays
  editable.

Surcharge Analysis has no sidebar entry of its own (see Process 3 below) — it
only runs from here or from DIM Change & MBW's equivalent tab.

---

## Process 2 — DIM Change & MBW ✅

Implements the *DIM changes and MBW* procedure.

| Tab | What happens |
| --- | --- |
| **1 · Inputs** | Shipment extract (needs Length / Width / Height) and the net rate sheet. A pure DIM change rates both sides from **one** sheet — upload a Proposed sheet only when the rates change too. |
| **2 · DIM factors** | Current and proposed DIM factors, with a per-OpCo override. The current default is read from the extract's own DIM Divisor column. |
| **3 · MBW rules** | The UA / OS / AHS rules — MBW, list rate, discount and every Service Guide threshold, all editable — plus the resulting test order. |
| **4 · Surcharges** | Optional — append a Surcharge Analysis onto this same workbook, the same way as Rate Comparison's **Surcharges** tab. |
| **5 · Build** | Notes, then the workbook, with the Summary shown on screen first. |

### The DIM calculation

Dimensions are re-ordered rather than trusted as given:

```
L = MAX(Length, Width, Height)     W = MEDIAN(…)     H = MIN(…)

DIM Volume  = L × W × H                    L & Girth = L + 2W + 2H
Current DIM Weight  = Volume ÷ current factor
Proposed DIM Weight = Volume ÷ proposed factor
Rated Weight = ROUNDUP(MAX(actual weight, DIM weight))   ← then floored at MBW
```

Rows with no dimensions keep their existing rated weight, rounded up — the
procedure: *"If in case the Dimension column is present as NA … replace the
value with the actual rated weight by rounding it up."* The app handles that case
up front rather than reproducing the `#NUM!` state and repairing it, and flags
those rows with a **Has DIM** column.

> The procedure text says `Round(...)`, but every row of its own worked example
> is **rounded up** (65.27 → 66, 15.19 → 16, 3.11 → 4). ROUNDUP is what the
> app implements; it reproduces the reference table exactly.

### Minimum Billable Weight

Mandatory whenever a DIM factor changes. Three surcharge families, each with
its own MBW and thresholds:

| Code | Surcharge | MBW | Triggers when it exceeds |
| --- | --- | --- | --- |
| **UA** | Unauthorized | 90 lbs | longest side 108 in · L+girth 165 in · actual weight 150 lbs — *Ground, Home Delivery, Multiweight, Return Manager only* |
| **OS** | Oversize | 90 lbs | longest side 96 in · L+girth 130 in · volume 17,280 in³ · actual weight 110 lbs |
| **AHS-Wt** | AHS Weight | 40 lbs | actual weight 50 lbs |
| **AHS-Dim** | AHS Dimension | 40 lbs | longest 48 in · 2nd longest 30 in · L+girth 105 in · volume 10,368 in³ |

Where several apply, *"the surcharge with highest amount is applied"* — so the
rules are tested in descending **net rate** order (list rate less the proposed
discount), not a fixed order. Change a discount on the MBW rules tab and the
test order re-sorts itself.

### The Rules tab

The DIM factors, MBW values, surcharge rates and every threshold are written
to a **Rules** tab, and the detail formulas point at it. Change the proposed
DIM factor in that one cell and the entire workbook recalculates in Excel —
no round trip through the app. For example:

```excel
Current DIM factor    =IFERROR(VLOOKUP($D2,Rules!$B$6:$D$7,2,FALSE),Rules!$C$8)
Current DIM Wt        =IF($K2="Y",$R2/$V2,"")
MBW (lbs)             =IFERROR(VLOOKUP($T2,Rules!$B$13:$D$16,3,FALSE),0)
Current Rated Weight  =MAX(IF($K2="Y",ROUNDUP(MAX($N2,$X2),0),ROUNDUP($M2,0)),$U2)
UA / OS / AHS         =IFERROR(IF(AND(COUNTIF(Rules!$I$13:$I$17,$C2)>0,
                          OR(AND($K2="Y",OR($O2>Rules!$C$22,$S2>Rules!$E$22)),
                          $N2>Rules!$G$22)),"UA", … )),"")
```

Note the `AND($K2="Y", …)` guard on every dimension test. Without it a
dimensionless row's blank cell would compare as **greater than** any threshold
— Excel sorts text above numbers — and every such row would falsely trigger
Oversize. That bug was caught by cross-checking Excel against Python; it is
invisible to inspection.

### Validation

- **The reference worked example reproduces exactly** — all 29 rows of the
  DIM table in the reference (volume, length + girth, surcharge label, and both
  DIM weights to 7 decimal places) match, including the two AHS-Dim rows.
- 20 engineered shipments covering every trigger, every boundary
  (108 in, 150 lbs, 110 lbs, 50 lbs), the UA product restriction, multi-rule
  priority and the no-dimensions path — all correct in Python **and** in Excel.
- On the sample file: 11,569 shipments × 6 fields = **69,414 values compared
  against the recalculated workbook, 0 mismatches**, for both the same-sheet
  and two-sheet modes.

### Combined with Surcharge Analysis

Same mechanism as Rate Comparison's **Surcharges** tab (above) — check
*"Include surcharge analysis in this workbook"*, and the surcharge Detail
and Rules tabs, plus its Summary section and auto-filled transportation
cost, are appended onto this DIM workbook instead of a separate download.
The DIM `Rules` tab and the surcharge `Surcharge Rules` tab coexist without
clashing.

---

## Process 3 — Surcharge Analysis ✅

Implements the *Surcharge analysis* procedure, driven by the **Surcharge
Pricing Template** (`Surcharge Pricing Template Feb2026Jul2026.xlsm`).

Not a standalone sidebar entry — it runs as an optional step *inside* Rate
Comparison and DIM Change & MBW, on each of their own **Surcharges** tab (see
*Combined with Surcharge Analysis* under each process above). The Template /
Surcharges / Fuel & totals flow described below is that same step; the
`SurchargeStep` class it's built from (`ui/surcharge_ui.py`) and the
`run()` / `build_into()` functions behind it (`processes/surcharge_analysis.py`)
still support building a standalone surcharge-only workbook programmatically —
the sidebar just no longer exposes that as its own screen.

| Tab | What happens |
| --- | --- |
| **1 · Template** | Upload the refreshed template. The app reads the period, month count, shipment and invoice totals, lists the pricing categories it found, and pulls every surcharge with its list rate, both discounts and its occurrence count. |
| **2 · Surcharges** | Every surcharge, by OpCo and zone band. **List rate, Current disc % and Proposed disc % are all editable**; Occurrences come from the data and are locked. Headline Current / Proposed / Impact update as you type. |
| **3 · Fuel & totals** | Fuel rate and fuel discount per OpCo, transportation cost per OpCo, an override list of which surcharges attract fuel, and a live Total Cost Components preview. |
| **4 · Build** | CHT ID, date range, grouping, annualisation and notes, then the workbook — with the summary and totals shown on screen first. |

### Where the numbers come from

The template carries the same data twice: the working tabs (nine-column
category blocks per surcharge) and a flat `Surcharge Master Data` mirror with
an OpCo column. The app reads the master mirror when it is present and falls
back to walking the working tabs, so a template that has lost the mirror still
parses.

Occurrences come from the template's own occurrence tabs, matched to each
surcharge and zone band. The **Template** tab prints OpCo totals so you can
cross-check them against the template's own `OpCo Summary` — they tie to the
cent.

### The arithmetic

```
Net Rate  = ROUND(List × (1 − Discount), 2)        ← per zone band
Net Spend = Net Rate × Occurrences
Fuel      = (Transportation + fuel-applicable surcharges)
            × (1 − fuel discount) × fuel rate      ← per OpCo
```

`ROUND` here is Excel's `ROUND`, not Python's `round` — half **away from
zero**, applied after collapsing to 15 significant digits. Python's default
banker's rounding puts the total out by several dollars across 69 surcharge
rows; the app uses a `Decimal` implementation of Excel's rule, which is what
took the sample's total to an exact match against the template.

### Which surcharges attract fuel

Auto-matched against the published Express and Ground lists — all AHS, DAS,
Residential, Signature, Oversize and delivery-area families do; the Fuel
Surcharge itself, Declared Value and the Saturday Expedited Processing Fee do
not. The classification for every surcharge is shown on the **Fuel & totals**
tab as a checkbox column, so where your reading of the published list differs
you can override it row by row before building.

### Grouping

The reported summary follows the convention of listing a surcharge
individually only where the discount actually changes **and** occurrences
exist. Everything else is summed into a single **All other surcharges subject
to fuel** line per OpCo, so the summary shows the proposal rather than 69 rows
of noise. Switch it off on the **Build** tab to list every surcharge.

### Not priced per occurrence

Declared Value is charged per \$100 of declared value, not per shipment, so the
template cannot price it from an occurrence count. Those rows carry their rate
and occurrences but leave Cost and Impact **blank** rather than zero — a zero
would read as "no impact" — and the app names them on screen. Their cost has to
come from the Surcharge Detail Template.

### Output workbook

| Tab | Contents |
| --- | --- |
| `Summary` | Notes, excludes, the fuel table, the reported surcharge summary by OpCo with live `SUMIFS`, Total Cost Components (transportation + surcharges + fuel), annualisation and the disclaimer. |
| `Surcharge Detail` | One row per surcharge and zone band. Net rate, cost and impact are formulas over the list rate and discount cells. |
| `Surcharge Rules` | Fuel rate and discounts per OpCo, and the transportation cost fuel is assessed on — change one cell and the whole workbook recalculates. Named `Surcharge Rules` (not plain `Rules`) so it can coexist with DIM Change & MBW's own `Rules` tab when the two are combined. |

```excel
Net rate      =IFERROR(ROUND($E2*(1-$F2),2),"")

Cost          =IFERROR($H2*$J2,"")

Summary line  =SUMIFS('Surcharge Detail'!$K$2:$K$70,
                'Surcharge Detail'!$C$2:$C$70,"Express Residential Delivery",
                'Surcharge Detail'!$A$2:$A$70,"Express")

Fuel          =((C12+SUMIFS('Surcharge Detail'!$K$2:$K$70,
                 'Surcharge Detail'!$A$2:$A$70,"Express",
                 'Surcharge Detail'!$N$2:$N$70,"Y"))
                 *(1-'Surcharge Rules'!D5)*'Surcharge Rules'!C5)
                + …
```

### Combined requests

A request often covers a rate comparison or DIM change **and** surcharges.
Running Surcharge Analysis from *inside* Rate Comparison or DIM Change & MBW
(their own **Surcharges** tab — see *Combined with Surcharge Analysis* under
each) is the normal way to do this now: one workbook, one Summary, and the
transportation cost auto-filled from that analysis's own totals. The
standalone screen here still supports the manual version of the same idea —
the **Fuel & totals** tab's Transportation cost fields take whatever you type
in — for a surcharge-only request, or when pairing against numbers from
outside the app.

### Validation

- OpCo totals tie **exactly** to the template's own `OpCo Summary` tab.
- Sample proposal (+5 pts on the residential and DAS discounts, Express fuel
  29.75%, Ground fuel 27% with a 20% fuel discount, transportation
  \$500k→\$470k Express and \$300k→\$285k Ground, annualised ×2): 69 detail rows
  × 7 derived cells, 20 reported summary lines, 3 OpCo subtotals, the grand
  total and all 9 cost-component rows recalculated in Excel and compared
  against an independent Python recomputation — **0 mismatches**.
- Driven end to end in a browser: List rate, Current disc % and Proposed disc %
  all accept edits and flow through to the downloaded workbook; Occurrences
  refuses them. On-screen totals and the recalculated workbook agree to the
  cent.

---

## Coming next

| Process | Status |
| --- | --- |
| Rate Comparison | ✅ built |
| DIM Change & MBW | ✅ built |
| Surcharge Analysis | ✅ built — embedded in Rate Comparison / DIM Change & MBW, no sidebar entry of its own |
| Zone Change Analysis | queued — new origin ZIP derivation, zone lookup, dual re-rate |
| Multiweight Re-Rating | queued — tags, tier rate tables, cost/lb, Rated/DNR |

Both reuse `core/` as it stands, so each is a new `processes/` +
`ui/` pair plus one registry line.
