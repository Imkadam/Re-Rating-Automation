"""
ER/BDA Manual Re-rating Toolkit
================================

Single entry point for every re-rating process.  Run with::

    streamlit run app.py

Each process lives in its own module under ``processes/`` (calculation) and
``ui/`` (screen), and is wired in through ``core/registry.py``.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.registry import get_processes    # noqa: E402
from ui import theme                       # noqa: E402

st.set_page_config(
    page_title="FedEx ER/BDA Re-rating Toolkit",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded",
)


def main() -> None:
    theme.inject()
    processes = get_processes()

    with st.sidebar:
        theme.brand()

        st.markdown("**Process**")
        choice = st.radio(
            "Process",
            [p.key for p in processes],
            format_func=lambda k: next(
                (p.name if p.status == "ready" else f"{p.name}  ·  soon")
                for p in processes if p.key == k
            ),
            label_visibility="collapsed",
        )
        selected = next(p for p in processes if p.key == choice)

        st.markdown(
            f'<div class="fx-note"><b>{selected.name}</b><br>'
            f'{selected.description}</div>',
            unsafe_allow_html=True,
        )

        theme.chips([
            ("Live formulas", "orange"),
            ("Excel output", "purple"),
        ])
        st.caption(
            "Every calculated cell in the output is a live Excel formula "
            "against the embedded rate sheets, so any number can be traced "
            "back to the rate it came from."
        )

        st.divider()
        if st.button("Reset session", use_container_width=True):
            st.session_state.clear()
            st.rerun()

    selected.render()
    theme.footer(
        "ER/BDA Manual Re-rating · internal analysis tool · "
        "figures are estimates and are not a quotation."
    )


if __name__ == "__main__":
    main()
