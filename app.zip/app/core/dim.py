"""
DIM factor change and Minimum Billable Weight (MBW).

Procedure: "DIM changes and MBW".

Dimensional re-rating
---------------------
The shipment's three dimensions are re-ordered rather than trusted as given::

    L = MAX(Length, Width, Height)
    W = MEDIAN(Length, Width, Height)
    H = MIN(Length, Width, Height)

    New DIM Volume        = L x W x H
    Current DIM Weight    = New DIM Volume / current DIM factor
    Proposed DIM Weight   = New DIM Volume / proposed DIM factor
    Current Rated Weight  = ROUNDUP(MAX(actual weight, Current DIM Weight))
    Proposed Rated Weight = ROUNDUP(MAX(actual weight, Proposed DIM Weight))

Minimum Billable Weight
-----------------------
"This is a Mandatory step when DIM factor changes request comes. When a
shipment qualifies for certain surcharges, the MBW rule activates ... the
shipment's weight is bumped up to a minimum chargeable limit if existing
calculated weights are less than MBW."

Where more than one surcharge applies, "the surcharge with highest amount is
applied for the shipment" - so the rules are evaluated in descending order of
net surcharge cost, not in a fixed order.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

# --------------------------------------------------------------------------
# Surcharge codes
# --------------------------------------------------------------------------
UA = "UA"
OS = "OS"
AHS_WT = "AHS-Wt"
AHS_DIM = "AHS-Dim"


@dataclass
class MBWRule:
    """One MBW-triggering surcharge, as published in the Service Guide."""

    code: str
    label: str
    mbw: float                       # minimum billable weight, lbs
    list_rate: float                 # per-package list rate
    discount: float = 0.0            # proposed-agreement discount
    # thresholds - None means the criterion does not apply to this rule
    max_length: Optional[float] = None        # longest side, inches
    max_second: Optional[float] = None        # second-longest side, inches
    max_length_girth: Optional[float] = None  # L + 2W + 2H, inches
    max_volume: Optional[float] = None        # cubic inches
    max_weight: Optional[float] = None        # actual weight, lbs
    # products the rule can apply to; empty means all products
    products: List[str] = field(default_factory=list)

    @property
    def net_rate(self) -> float:
        return self.list_rate * (1 - self.discount)

    def applies_to_product(self, product: str) -> bool:
        if not self.products:
            return True
        p = (product or "").strip().lower()
        return any(p == x.strip().lower() for x in self.products)

    def triggered(self, length: Optional[float], second: Optional[float],
                  girth: Optional[float], volume: Optional[float],
                  weight: Optional[float]) -> bool:
        """True when any of this rule's criteria is exceeded."""
        checks = (
            (self.max_length, length),
            (self.max_second, second),
            (self.max_length_girth, girth),
            (self.max_volume, volume),
            (self.max_weight, weight),
        )
        for limit, value in checks:
            if limit is not None and value is not None and value > limit:
                return True
        return False


# --------------------------------------------------------------------------
# Service Guide defaults (FY2026 - Service Guide pages 127-128)
# --------------------------------------------------------------------------
# UA applies only to Ground, Home Delivery, Multiweight and Return Manager.
UA_PRODUCTS = ["Ground", "Home Delivery", "Multiweight",
               "Ground Multiweight", "Return Manager"]


def default_rules() -> List[MBWRule]:
    return [
        MBWRule(
            code=UA, label="Unauthorized", mbw=90,
            list_rate=1875.0, discount=0.0,
            max_length=108, max_length_girth=165, max_weight=150,
            products=list(UA_PRODUCTS),
        ),
        MBWRule(
            code=OS, label="Oversize", mbw=90,
            list_rate=255.0, discount=0.5,
            max_length=96, max_length_girth=130, max_volume=17280,
            max_weight=110,
        ),
        MBWRule(
            code=AHS_WT, label="AHS - Weight", mbw=40,
            list_rate=46.0, discount=0.5,
            max_weight=50,
        ),
        MBWRule(
            code=AHS_DIM, label="AHS - Dimension", mbw=40,
            list_rate=29.5, discount=0.5,
            max_length=48, max_second=30, max_length_girth=105,
            max_volume=10368,
        ),
    ]


def by_cost(rules: Sequence[MBWRule]) -> List[MBWRule]:
    """
    Rules in the order they should be tested.

    Procedure: "If a shipment is applicable for multiple surcharges, the
    surcharge with highest amount is applied for the shipment."
    """
    return sorted(rules, key=lambda r: r.net_rate, reverse=True)


# --------------------------------------------------------------------------
# Per-shipment geometry
# --------------------------------------------------------------------------
@dataclass
class Dims:
    """Re-ordered dimensions and everything derived from them."""

    has_dims: bool = False
    length: Optional[float] = None      # L - longest
    width: Optional[float] = None       # W - median
    height: Optional[float] = None      # H - shortest
    volume: Optional[float] = None
    length_girth: Optional[float] = None


def reorder(a, b, c) -> Dims:
    """L = MAX, W = MEDIAN, H = MIN of the three supplied dimensions."""
    vals = [v for v in (a, b, c)
            if isinstance(v, (int, float)) and not isinstance(v, bool)
            and v == v and v > 0]
    if len(vals) < 3:
        return Dims(has_dims=False)
    vals = sorted(float(v) for v in vals)
    h, w, l = vals[0], vals[1], vals[2]
    return Dims(
        has_dims=True, length=l, width=w, height=h,
        volume=l * w * h,
        length_girth=l + 2 * w + 2 * h,
    )


def resolve_surcharge(dims: Dims, actual_weight: Optional[float],
                      product: str, rules: Sequence[MBWRule]
                      ) -> Optional[MBWRule]:
    """The highest-cost MBW surcharge this shipment triggers, if any."""
    for rule in by_cost(rules):
        if not rule.applies_to_product(product):
            continue
        if rule.triggered(dims.length, dims.width, dims.length_girth,
                          dims.volume, actual_weight):
            return rule
    return None


def roundup(value: Optional[float]) -> Optional[float]:
    if value is None:
        return None
    return float(math.ceil(value - 1e-9))


def rated_weight(dims: Dims, actual_weight: Optional[float],
                 fallback_weight: Optional[float], divisor: Optional[float],
                 mbw: float = 0.0) -> Optional[float]:
    """
    Rated weight for one side of the analysis.

    With dimensions:  ROUNDUP(MAX(actual weight, volume / DIM factor))
    Without:          ROUNDUP(rated weight from the data) - procedure: "If in
                      case the Dimension column is present as NA ... replace
                      the value with the actual rated weight by rounding it
                      up."
    Then floored at the Minimum Billable Weight, if one applies.
    """
    if dims.has_dims and divisor:
        dim_wt = dims.volume / float(divisor)
        base = max(actual_weight or 0.0, dim_wt)
    else:
        base = fallback_weight if fallback_weight is not None else actual_weight
    out = roundup(base)
    if out is None:
        return None
    return max(out, float(mbw or 0.0))
