"""
Rate evaluation.

The workbook the analyst downloads carries live Excel formulas, so the app
itself never sees a number - which would leave the on-screen Summary empty
until the file is opened in Excel.

This module resolves the same lookups in Python so the Summary can be shown
before download. Both paths are driven by the *same* :class:`RatePlan`, built
once per shipment, so the preview cannot drift away from what the formulas
compute: if the plan says "envelope row 51, zone column 6", the formula points
there and the evaluator reads there.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .ratesheet import RateBlock, _range_start

# --------------------------------------------------------------------------
MODE_NONE = "none"
MODE_ENVELOPE = "envelope"
MODE_STANDARD = "standard"
MODE_RANGE = "range"            # weight-range / per-pound table x weight
MODE_PER_POUND = "per_pound"    # the derived 'AS' row  x weight


@dataclass
class RatePlan:
    """How one shipment is to be rated - shared by the formula and the value."""

    mode: str = MODE_NONE
    block: Optional[RateBlock] = None
    kind: str = "package"        # envelope | pak | package
    note: str = ""

    @property
    def rated(self) -> bool:
        return self.mode != MODE_NONE and self.block is not None


# --------------------------------------------------------------------------
class SheetGrid:
    """Cell values of one embedded rate-sheet tab, with lookup indexes."""

    def __init__(self, rows: List[tuple]):
        self.rows = rows
        self._weight_rows: Dict[Tuple[int, int], Dict[float, int]] = {}
        self._range_rows: Dict[Tuple[int, int], List[Tuple[float, int]]] = {}

    def cell(self, row: int, col: int):
        if 1 <= row <= len(self.rows):
            r = self.rows[row - 1]
            if 1 <= col <= len(r):
                return r[col - 1]
        return None

    def weight_index(self, first: int, last: int) -> Dict[float, int]:
        """weight value -> row, for an exact-match (VLOOKUP FALSE) section."""
        key = (first, last)
        idx = self._weight_rows.get(key)
        if idx is None:
            idx = {}
            for r in range(first, last + 1):
                v = self.cell(r, 1)
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    idx[float(v)] = r
            self._weight_rows[key] = idx
        return idx

    def range_index(self, first: int, last: int) -> List[Tuple[float, int]]:
        """(start weight, row) ascending, for an approximate-match section."""
        key = (first, last)
        idx = self._range_rows.get(key)
        if idx is None:
            idx = []
            for r in range(first, last + 1):
                a = self.cell(r, 1)
                start = _range_start(a)
                if start is None and isinstance(a, (int, float)) \
                        and not isinstance(a, bool):
                    start = float(a)
                if start is not None:
                    idx.append((float(start), r))
            idx.sort()
            self._range_rows[key] = idx
        return idx


def build_grids(workbook, sheet_names) -> Dict[str, SheetGrid]:
    """Snapshot the embedded rate-sheet tabs so lookups do not re-read cells."""
    grids: Dict[str, SheetGrid] = {}
    for name in sheet_names:
        ws = workbook[name]
        grids[name] = SheetGrid(
            [tuple(r) for r in ws.iter_rows(values_only=True)])
    return grids


# --------------------------------------------------------------------------
def lookup_weight(weight: float) -> float:
    """Mirror of the Lookup Weight formula: =IF(w<=1,1,CEILING(w,1))."""
    if weight is None:
        return 1.0
    return 1.0 if weight <= 1 else float(math.ceil(weight))


def _num(v) -> Optional[float]:
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return None


def evaluate(plan: RatePlan, grids: Dict[str, SheetGrid],
             weight: float, zone: Optional[float]) -> Optional[float]:
    """
    Compute what the plan's Excel formula would compute.

    Returns None where the formula would produce #N/A - which the workbook
    wraps in IFERROR and shows as blank.
    """
    block = plan.block
    if plan.mode == MODE_NONE or block is None or zone is None:
        return None

    grid = grids.get(block.sheet)
    if grid is None:
        return None

    col = block.zones.get(float(zone))
    if col is None:
        return None

    if plan.mode == MODE_ENVELOPE:
        sec = block.sections.get("envelope")
        return None if sec is None else _num(grid.cell(sec.first_row, col))

    if plan.mode == MODE_STANDARD:
        sec = block.sections.get(plan.kind)
        if sec is None:
            return None
        row = grid.weight_index(sec.first_row, sec.last_row).get(
            lookup_weight(weight))
        return None if row is None else _num(grid.cell(row, col))

    if plan.mode == MODE_RANGE:
        sec = block.sections.get("package") or next(
            iter(block.sections.values()), None)
        if sec is None:
            return None
        lw = lookup_weight(weight)
        row = None
        for start, r in grid.range_index(sec.first_row, sec.last_row):
            if start <= lw:
                row = r
            else:
                break
        if row is None:
            return None
        rate = _num(grid.cell(row, col))
        return None if rate is None else rate * lw

    if plan.mode == MODE_PER_POUND:
        sec = block.sections.get("package")
        if sec is None:
            return None
        divisor = block.per_pound_divisor or (sec.max_weight or 150)
        base = _num(grid.cell(sec.last_row, col))
        if base is None or not divisor:
            return None
        return base / float(divisor) * lookup_weight(weight)

    return None
