"""
Output workbook assembly.

The deliverable is a single .xlsx that is fully self-validating: the Current
and Proposed net rate sheets are embedded as tabs, and every rated cost is a
live formula pointing back at them.  Open the file, click a cost cell, and the
formula bar shows the VLOOKUP the analyst would have written by hand.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .config import ALPHA_ZONE_MAP, DISCLAIMER, FMT_MONEY_2DP, FMT_PCT_1DP
from .ratesheet import RateBlock

# --------------------------------------------------------------------------
# styling
# --------------------------------------------------------------------------
HEADER_FILL = PatternFill("solid", fgColor="4D148C")      # FedEx purple
HEADER_FONT = Font(color="FFFFFF", bold=True, size=10)
TITLE_FONT = Font(bold=True, size=12, color="4D148C")
BOLD = Font(bold=True, size=10)
SMALL = Font(size=9, color="595959")
NOTE_FONT = Font(size=9, italic=True, color="404040")
TOTAL_FILL = PatternFill("solid", fgColor="EFE7F7")
RATESHEET_HDR_FILL = PatternFill("solid", fgColor="F2F2F2")
HELPER_FILL = PatternFill("solid", fgColor="FFF2CC")

THIN = Side(style="thin", color="BFBFBF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
TOP_BORDER = Border(top=Side(style="thin", color="4D148C"))


def style_header_row(ws, row: int, first_col: int, last_col: int) -> None:
    for c in range(first_col, last_col + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center",
                                   wrap_text=True)
        cell.border = BOX
    ws.row_dimensions[row].height = 30


def autosize(ws, widths: Dict[int, int]) -> None:
    for col, width in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = width


# --------------------------------------------------------------------------
@dataclass
class EmbeddedSheet:
    """A rate sheet copied into the output workbook."""

    name: str
    helper_col: int                 # column holding range start-weights
    row_count: int
    blocks: List[RateBlock] = None  # re-pointed at their new row numbers
    source: str = ""


# Label written in column A of the inserted per-pound row, and used as the
# VLOOKUP key by the heavyweight formulas - matching the documented worked example.
PER_POUND_LABEL = "AS"


def embed_ratesheet(wb: Workbook, source_ws, target_name: str,
                    blocks: Sequence[RateBlock],
                    max_col: int = 40,
                    add_per_pound_rows: bool = True) -> EmbeddedSheet:
    """
    Copy a rate sheet worksheet into the output workbook, adding the two
    things the procedure tells the analyst to add by hand:

    1. **The per-pound row** ("Heavyweight Shipment Re-Rating"):
       "In both the Current and Proposed Net Rate Sheets, insert an additional
       row immediately below the 150 lb rate row for the applicable service.
       Calculate a Per-Pound Rate for each zone by dividing the 150 lb rate by
       150."  We insert it in exactly that position, label it ``AS`` in column
       A, and populate each zone with a live ``=B1467/150`` formula - so the
       derived rate is visible and checkable on the rate sheet itself, not
       hidden inside the shipment formula.

    2. **The helper column** ("Freight Service Re-Rating"): the
       starting weight of each weight range, used as the approximate-match
       lookup column.  It goes to the right of the data rather than being
       inserted, so no existing column letter moves.

    Because inserting rows moves everything below them, each block's
    coordinates are re-pointed through the same shift and returned on the
    :class:`EmbeddedSheet`.
    """
    ws = wb.create_sheet(target_name)
    import copy as _copy

    # ---- where do the per-pound rows go? --------------------------------
    # one immediately after the last weight row of every standard package table
    insert_after: Dict[int, RateBlock] = {}
    if add_per_pound_rows:
        for b in blocks:
            sec = b.sections.get("package")
            if b.is_per_pound or sec is None or not sec.max_weight:
                continue
            insert_after.setdefault(sec.last_row, b)

    points = sorted(insert_after)

    def shifted(old_row: int) -> int:
        """Row number in the output sheet for a row in the source sheet."""
        return old_row + sum(1 for p in points if p < old_row)

    # ---- copy the sheet, emitting the extra rows as we pass them --------
    last_col = 0
    out_row = 0
    per_pound_rows: Dict[int, int] = {}       # source last_row -> new AS row

    for r_idx, row in enumerate(
        source_ws.iter_rows(min_row=1, max_row=source_ws.max_row,
                            max_col=max_col, values_only=True), start=1
    ):
        out_row += 1
        for c_idx, value in enumerate(row, start=1):
            if value is None:
                continue
            ws.cell(row=out_row, column=c_idx, value=value)
            last_col = max(last_col, c_idx)
        if r_idx in insert_after:
            out_row += 1
            per_pound_rows[r_idx] = out_row

    n_rows = out_row

    # ---- re-point the blocks at their new rows --------------------------
    new_blocks: List[RateBlock] = []
    for b in blocks:
        nb = _copy.deepcopy(b)
        nb.sheet = target_name
        nb.shift(shifted)
        sec = b.sections.get("package")
        if sec is not None and sec.last_row in per_pound_rows:
            nb.per_pound_row = per_pound_rows[sec.last_row]
            nb.per_pound_divisor = float(sec.max_weight or 150)
        new_blocks.append(nb)

    # ---- fill the per-pound rows with live division formulas ------------
    for nb in new_blocks:
        if nb.per_pound_row is None:
            continue
        base = nb.per_pound_row - 1                       # the 150 lb row
        divisor = nb.per_pound_divisor or 150
        label = ws.cell(row=nb.per_pound_row, column=1, value=PER_POUND_LABEL)
        label.font = BOLD
        label.fill = HELPER_FILL
        for c in range(2, nb.last_col + 1):
            col = get_column_letter(c)
            cell = ws.cell(row=nb.per_pound_row, column=c,
                           value=f"={col}{base}/{divisor:g}")
            cell.number_format = "0.0000"
            cell.fill = HELPER_FILL

    # ---- helper column of weight-range start weights --------------------
    helper_col = last_col + 2
    hl = get_column_letter(helper_col)
    head = ws.cell(row=1, column=helper_col, value="Helper: range start wt")
    head.font = BOLD
    head.fill = HELPER_FILL

    from .ratesheet import _range_start          # internal helper

    for nb in new_blocks:
        if not nb.is_per_pound:
            continue
        for sec in nb.sections.values():
            for r in range(sec.first_row, sec.last_row + 1):
                start = _range_start(ws.cell(row=r, column=1).value)
                if start is None:
                    start = ws.cell(row=r, column=1).value
                cell = ws.cell(row=r, column=helper_col, value=start)
                cell.fill = HELPER_FILL

    # ---- light readability pass on the zone header rows -----------------
    for nb in new_blocks:
        for c in range(1, nb.last_col + 1):
            cell = ws.cell(row=nb.header_row, column=c)
            cell.font = BOLD
            cell.fill = RATESHEET_HDR_FILL

    ws.column_dimensions["A"].width = 16
    for c in range(2, last_col + 1):
        ws.column_dimensions[get_column_letter(c)].width = 11
    ws.column_dimensions[hl].width = 20
    ws.freeze_panes = "B1"

    return EmbeddedSheet(name=target_name, helper_col=helper_col,
                         row_count=n_rows, blocks=new_blocks,
                         source=source_ws.title)


# --------------------------------------------------------------------------
def write_zone_map(wb: Workbook, name: str = "Zone Map") -> str:
    """Reference tab backing the zone-normalisation formulas."""
    ws = wb.create_sheet(name)
    ws["A1"] = "Zone code translation"
    ws["A1"].font = TITLE_FONT
    ws["A3"] = "Alpha"
    ws["B3"] = "Numeric"
    ws["C3"] = "Description"
    style_header_row(ws, 3, 1, 3)

    descriptions = {
        "A": "Alaska", "H": "Hawaii", "M": "Military (APO/FPO)",
        "P": "Puerto Rico", "Z": "Other non-contiguous U.S. territories",
    }
    r = 4
    for alpha, num in ALPHA_ZONE_MAP.items():
        ws.cell(row=r, column=1, value=alpha)
        ws.cell(row=r, column=2, value=num)
        ws.cell(row=r, column=3, value=descriptions.get(alpha, ""))
        for c in range(1, 4):
            ws.cell(row=r, column=c).border = BOX
        r += 1
    autosize(ws, {1: 10, 2: 12, 3: 42})
    return f"$A$4:$B${r - 1}"


def write_notes_block(ws, row: int, title: str, lines: Iterable[str],
                      col: int = 2) -> int:
    ws.cell(row=row, column=col, value=title).font = BOLD
    row += 1
    for line in lines:
        c = ws.cell(row=row, column=col, value=line)
        c.font = NOTE_FONT
        row += 1
    return row + 1


def write_disclaimer(ws, row: int, col: int = 2, width_cols: int = 7) -> int:
    ws.cell(row=row, column=col, value="Disclaimer:").font = BOLD
    row += 1
    cell = ws.cell(row=row, column=col, value=DISCLAIMER)
    cell.font = Font(size=9, color="404040")
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    ws.merge_cells(start_row=row, start_column=col,
                   end_row=row + 3, end_column=col + width_cols)
    return row + 5


# --------------------------------------------------------------------------
def write_table(ws, top: int, left: int, headers: Sequence[str],
                rows: Iterable[Sequence], number_formats:
                Optional[Dict[int, str]] = None) -> int:
    """Write a simple header + body table; returns the row after the table."""
    for j, h in enumerate(headers):
        ws.cell(row=top, column=left + j, value=h)
    style_header_row(ws, top, left, left + len(headers) - 1)

    r = top + 1
    for row_vals in rows:
        for j, v in enumerate(row_vals):
            cell = ws.cell(row=r, column=left + j, value=v)
            cell.border = BOX
            if number_formats and j in number_formats:
                cell.number_format = number_formats[j]
        r += 1
    return r


def mark_total_row(ws, row: int, first_col: int, last_col: int) -> None:
    for c in range(first_col, last_col + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = BOLD
        cell.fill = TOTAL_FILL
        cell.border = BOX


def pct_cell(ws, row: int, col: int, formula: str) -> None:
    cell = ws.cell(row=row, column=col, value=formula)
    cell.number_format = FMT_PCT_1DP
    cell.font = BOLD


def money(ws, row: int, col: int, value, fmt: str = FMT_MONEY_2DP):
    cell = ws.cell(row=row, column=col, value=value)
    cell.number_format = fmt
    return cell


def new_workbook() -> Workbook:
    wb = Workbook()
    wb.remove(wb.active)
    return wb
