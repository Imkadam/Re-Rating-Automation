"""
Excel formula builders.

Nothing in the output workbook is a baked-in number: every rated cost is a
live Excel formula pointing at the embedded rate-sheet tabs, so the analyst
can click any cell and see exactly how the rate was found - the same
VLOOKUP / MATCH pattern a human would build by hand.
"""

from __future__ import annotations

from typing import Optional

from openpyxl.utils import get_column_letter, quote_sheetname

from .ratesheet import RateBlock


def a1(col: int, row: int, abs_col: bool = False, abs_row: bool = False) -> str:
    return (
        ("$" if abs_col else "") + get_column_letter(col)
        + ("$" if abs_row else "") + str(row)
    )


def _sheet(name: str) -> str:
    """Sheet reference, quoted only when Excel needs it."""
    return quote_sheetname(name)


# --------------------------------------------------------------------------
# rate lookups
# --------------------------------------------------------------------------
def envelope_rate(block: RateBlock, zone_ref: str) -> Optional[str]:
    """
    Envelope / Letter shipments.

    Procedure: "All Envelope/Letter shipments should be rated using the 1 lb
    Envelope rate, regardless of whether the Rated Weight is greater than or
    less than 1 lb."  The envelope sub-table is a single row, so we pick the
    zone column out of that row with INDEX/MATCH.
    """
    rng = block.section_range("envelope")
    if not rng:
        return None
    sheet = _sheet(block.sheet)
    return (
        f"=INDEX({sheet}!{rng},"
        f"MATCH({zone_ref},{sheet}!{block.header_range()},0))"
    )


def standard_rate(block: RateBlock, weight_ref: str, zone_ref: str,
                  kind: str = "package") -> Optional[str]:
    """
    Standard 1-150 lb lookup - the everyday case.

        =VLOOKUP(<weight>, rates!$A$53:$P$202,
                 MATCH(<zone>, rates!$A$49:$P$49, 0), FALSE)

    Both ranges start at column A so MATCH's position lines up with
    VLOOKUP's column index.
    """
    rng = block.section_range(kind)
    if not rng:
        return None
    sheet = _sheet(block.sheet)
    return (
        f"=VLOOKUP({weight_ref},{sheet}!{rng},"
        f"MATCH({zone_ref},{sheet}!{block.header_range()},0),FALSE)"
    )


def per_pound_rate(block: RateBlock, weight_ref: str, zone_ref: str,
                   helper_col: int, kind: str = "package") -> Optional[str]:
    """
    Heavyweight (>150 lb) and Freight lookups.

    Rates come in weight *ranges* with a per-pound rate, so we
    approximate-match the shipment weight against a helper column of range
    start weights and multiply the result by the rated weight::

        =INDEX(rates!$A$214:$P$219,
               MATCH(<weight>, rates!$R$214:$R$219, 1),
               MATCH(<zone>,   rates!$A$213:$P$213, 0)) * <weight>
    """
    sec = block.sections.get(kind)
    if not sec:
        return None
    sheet = _sheet(block.sheet)
    hcol = get_column_letter(helper_col)
    helper_range = f"${hcol}${sec.first_row}:${hcol}${sec.last_row}"
    return (
        f"=INDEX({sheet}!{block.section_range(kind)},"
        f"MATCH({weight_ref},{sheet}!{helper_range},1),"
        f"MATCH({zone_ref},{sheet}!{block.header_range()},0))"
        f"*{weight_ref}"
    )


PER_POUND_LABEL = "AS"


def per_pound_from_150(block: RateBlock, weight_ref: str, zone_ref: str
                       ) -> Optional[str]:
    """
    Heavyweight rating from the derived per-pound row
    ("Heavyweight Shipment Re-Rating").

    The rate sheet carries an inserted row labelled ``AS`` immediately below
    the 150 lb row, holding ``= 150 lb rate / 150`` for every zone.  This
    reproduces the analyst's formula verbatim::

        =VLOOKUP("AS", Current!$A$4620:$P$4620,
                 MATCH($P10497, Current!$A$4468:$P$4468, 0), FALSE) * M10497

    i.e. Shipment Rate = Per-Pound Rate x Rated Weight.
    """
    rng = block.per_pound_range()
    if not rng:
        return _per_pound_inline(block, weight_ref, zone_ref)
    sheet = _sheet(block.sheet)
    return (
        f'=VLOOKUP("{PER_POUND_LABEL}",{sheet}!{rng},'
        f"MATCH({zone_ref},{sheet}!{block.header_range()},0),FALSE)"
        f"*{weight_ref}"
    )


def _per_pound_inline(block: RateBlock, weight_ref: str, zone_ref: str
                      ) -> Optional[str]:
    """Same rule, computed inline - used when no ``AS`` row was written."""
    sec = block.sections.get("package")
    if not sec:
        return None
    sheet = _sheet(block.sheet)
    row150 = sec.last_row
    divisor = sec.max_weight or 150
    rng = f"${block.col_letter_first}${row150}:${block.col_letter_last}${row150}"
    return (
        f"=INDEX({sheet}!{rng},"
        f"MATCH({zone_ref},{sheet}!{block.header_range()},0))"
        f"/{divisor:g}*{weight_ref}"
    )


# --------------------------------------------------------------------------
# derived columns
# --------------------------------------------------------------------------
def lookup_weight(rated_ref: str) -> str:
    """
    Weight actually used for the rate lookup.

    Sub-pound shipments (0.5 lb letters) are rated at the 1 lb row; anything
    else is rounded up to the next whole pound so it lands on a rate row.
    """
    return f"=IF({rated_ref}<=1,1,CEILING({rated_ref},1))"


def zone_normalised(zone_ref: str, map_sheet: str, map_range: str) -> str:
    """
    Translate alphabetical zones (A/H/M/P/Z) into their numeric equivalents
    using the Zone Map tab, leaving numeric zones untouched.
    """
    sheet = _sheet(map_sheet)
    return (
        f"=IFERROR(VLOOKUP({zone_ref},{sheet}!{map_range},2,FALSE),"
        f"IFERROR(VALUE({zone_ref}),{zone_ref}))"
    )


def impact(proposed_ref: str, current_ref: str) -> str:
    return f"={proposed_ref}-{current_ref}"


def impact_pct(impact_ref: str, current_ref: str) -> str:
    return f"=IFERROR({impact_ref}/{current_ref},0)"


def sumifs(target_sheet: str, value_col: str, key_col: str, key_ref: str,
           first_row: int, last_row: int) -> str:
    """Live roll-up of the detail tab, so the Summary re-calculates itself."""
    sheet = _sheet(target_sheet)
    return (
        f"=SUMIFS({sheet}!${value_col}${first_row}:${value_col}${last_row},"
        f"{sheet}!${key_col}${first_row}:${key_col}${last_row},{key_ref})"
    )


def countifs(target_sheet: str, key_col: str, key_ref: str,
             first_row: int, last_row: int) -> str:
    sheet = _sheet(target_sheet)
    return (
        f"=COUNTIFS({sheet}!${key_col}${first_row}:${key_col}${last_row},"
        f"{key_ref})"
    )


def wrap_iferror(formula: Optional[str], fallback: str = '""') -> Optional[str]:
    """Wrap a built formula so a missing rate shows blank instead of #N/A."""
    if not formula:
        return None
    return f"=IFERROR({formula[1:]},{fallback})"
