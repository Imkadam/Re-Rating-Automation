"""
Net Rate Sheet parser.

A FedEx net rate sheet export is a tall worksheet containing many independent
rate tables.  Each table looks like this::

     40 | FedEx First Overnight                          <- service title
     48 | Weight       Zone(s)
     49 | lbs.   2   3   4  ...  16                      <- ZONE HEADER ROW
     50 | Envelope
     51 |        68.27 75.55 ...                         <- envelope rate row
     52 | Package
     53 | 1      76.22 98.03 ...                         <- first package weight
    ... |
    202 | 150    ...                                     <- last package weight

Heavyweight / Freight tables use weight *ranges* instead ("151 - 299") and hold
per-pound rates::

    213 | lbs.        2     3   ...
    214 | 100 - 150   3.39  4.61 ...

This module finds every such table and describes it as a :class:`RateBlock`
carrying the exact row/column coordinates the Excel formulas need.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from openpyxl.utils import get_column_letter

from .config import RATESHEET_SERVICE_ALIASES

# Markers that appear in column A and open a sub-section of a rate table.
_SECTION_MARKERS = {
    "envelope": "envelope",
    "letter": "envelope",
    "pak": "pak",
    "package": "package",
    "packages": "package",
}

_HEADER_TOKENS = {"lbs.", "lbs", "pounds", "lb."}

_RANGE_RE = re.compile(r"^\s*([\d,]+(?:\.\d+)?)\s*[-–]\s*([\d,]+(?:\.\d+)?)\s*\+?\s*$")
_PLUS_RE = re.compile(r"^\s*([\d,]+(?:\.\d+)?)\s*\+\s*$")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _num(value) -> Optional[float]:
    """Return value as a float, or None when it is not a plain number."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        s = value.strip().replace(",", "")
        if s and re.fullmatch(r"-?\d+(\.\d+)?", s):
            return float(s)
    return None


def _range_start(value) -> Optional[float]:
    """Starting weight of a weight-range label such as '1,000 - 1,999'."""
    if not isinstance(value, str):
        return None
    m = _RANGE_RE.match(value)
    if m:
        return float(m.group(1).replace(",", ""))
    m = _PLUS_RE.match(value)
    if m:
        return float(m.group(1).replace(",", ""))
    return None


def _clean(value) -> str:
    return str(value).strip() if value is not None else ""


def normalise_service(title: str) -> str:
    """Map a rate-sheet block title onto the shipment 'Product Name' wording."""
    low = title.lower()
    for needle, service in RATESHEET_SERVICE_ALIASES:
        if needle in low:
            return service
    return title.strip()


# --------------------------------------------------------------------------
# data model
# --------------------------------------------------------------------------
@dataclass
class RateSection:
    """One sub-table (Envelope / Pak / Package) inside a rate block."""

    kind: str                 # 'envelope' | 'pak' | 'package'
    first_row: int
    last_row: int
    min_weight: Optional[float] = None
    max_weight: Optional[float] = None

    @property
    def row_count(self) -> int:
        return self.last_row - self.first_row + 1


@dataclass
class RateBlock:
    """A single rate table on a net rate sheet."""

    sheet: str
    title: str                        # raw title as printed on the sheet
    service: str                      # normalised Product Name
    header_row: int                   # the 'lbs.' row carrying zone numbers
    first_col: int = 1                # always column A - keeps MATCH aligned
    last_col: int = 1
    zones: Dict[float, int] = field(default_factory=dict)   # zone -> col index
    sections: Dict[str, RateSection] = field(default_factory=dict)
    is_per_pound: bool = False        # heavyweight / freight per-pound table
    weight_starts: List[float] = field(default_factory=list)  # for range tables
    billing_type: str = ""
    earned_discount: Optional[float] = None

    # Populated when the block is embedded in an output workbook: the row
    # inserted immediately below the 150 lb rate row holding the derived
    # per-pound rates ("Heavyweight Shipment Re-Rating").
    per_pound_row: Optional[int] = None
    per_pound_divisor: Optional[float] = None

    # Identity as parsed from the *source* rate sheet. Row numbers move when
    # per-pound rows are inserted during embedding, so these stay fixed and
    # are what match a UI-selected block to its embedded copy.
    source_sheet: str = ""
    source_header_row: Optional[int] = None

    # ---- identity --------------------------------------------------------
    @property
    def uid(self) -> tuple:
        return (self.source_sheet or self.sheet,
                self.source_header_row
                if self.source_header_row is not None else self.header_row)

    # ---- convenience -----------------------------------------------------
    @property
    def label(self) -> str:
        kind = "per-lb" if self.is_per_pound else "standard"
        bt = f" [{self.billing_type}]" if self.billing_type else ""
        return f"{self.service}{bt} - {kind} - row {self.header_row}"

    @property
    def col_letter_first(self) -> str:
        return get_column_letter(self.first_col)

    @property
    def col_letter_last(self) -> str:
        return get_column_letter(self.last_col)

    def header_range(self) -> str:
        """Absolute range of the zone header row, e.g. $A$49:$P$49."""
        return (
            f"${self.col_letter_first}${self.header_row}:"
            f"${self.col_letter_last}${self.header_row}"
        )

    def per_pound_range(self) -> Optional[str]:
        """Absolute range of the inserted per-pound ('AS') row."""
        if self.per_pound_row is None:
            return None
        return (
            f"${self.col_letter_first}${self.per_pound_row}:"
            f"${self.col_letter_last}${self.per_pound_row}"
        )

    def shift(self, mapper) -> None:
        """Re-point every row coordinate through a row-remapping function."""
        self.header_row = mapper(self.header_row)
        for sec in self.sections.values():
            sec.first_row = mapper(sec.first_row)
            sec.last_row = mapper(sec.last_row)

    def section_range(self, kind: str) -> Optional[str]:
        sec = self.sections.get(kind)
        if not sec:
            return None
        return (
            f"${self.col_letter_first}${sec.first_row}:"
            f"${self.col_letter_last}${sec.last_row}"
        )

    def has(self, kind: str) -> bool:
        return kind in self.sections

    def max_weight(self, kind: str = "package") -> Optional[float]:
        sec = self.sections.get(kind)
        return sec.max_weight if sec else None


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------
class RateSheetParser:
    """Scan a worksheet and return every rate table it contains."""

    def __init__(self, worksheet, sheet_name: Optional[str] = None):
        self.ws = worksheet
        self.sheet_name = sheet_name or worksheet.title
        self.rows: List[tuple] = []
        self.max_col = 0

    # -- public ------------------------------------------------------------
    def parse(self) -> List[RateBlock]:
        self._load()
        blocks: List[RateBlock] = []
        for r_idx, row in enumerate(self.rows, start=1):
            first = _clean(row[0]).lower().rstrip(":")
            if first in _HEADER_TOKENS:
                block = self._build_block(r_idx)
                if block and block.sections:
                    blocks.append(block)
        return blocks

    # -- internals ---------------------------------------------------------
    def _load(self) -> None:
        self.rows = [
            tuple(r)
            for r in self.ws.iter_rows(
                min_row=1, max_row=self.ws.max_row, values_only=True
            )
        ]
        self.max_col = max((len(r) for r in self.rows), default=0)

    def _cell(self, row_idx: int, col_idx: int):
        """1-based access that tolerates ragged rows."""
        if 1 <= row_idx <= len(self.rows):
            row = self.rows[row_idx - 1]
            if 1 <= col_idx <= len(row):
                return row[col_idx - 1]
        return None

    # ..................................................................
    def _build_block(self, header_row: int) -> Optional[RateBlock]:
        row = self.rows[header_row - 1]

        # zone columns: numeric cells to the right of the 'lbs.' label
        zones: Dict[float, int] = {}
        last_col = 1
        for c_idx in range(2, len(row) + 1):
            z = _num(row[c_idx - 1])
            if z is not None:
                zones.setdefault(z, c_idx)
                last_col = c_idx
        if not zones:
            return None

        title, billing, discount = self._find_title(header_row)
        block = RateBlock(
            sheet=self.sheet_name,
            title=title,
            service=normalise_service(title),
            header_row=header_row,
            last_col=last_col,
            zones=zones,
            billing_type=billing,
            earned_discount=discount,
            source_sheet=self.sheet_name,
            source_header_row=header_row,
        )
        self._collect_sections(block)
        return block

    def _find_title(self, header_row: int):
        """Walk upwards to the nearest service title above the header row."""
        title = ""
        billing = ""
        discount = None
        skip_prefixes = (
            "net rates", "per-pound", "per pound", "customer name", "effective",
            "created on", "please refer", "package type", "billing type",
            "group id", "account number", "currency",
        )
        for r in range(header_row - 1, max(0, header_row - 40), -1):
            a = _clean(self._cell(r, 1))
            b = self._cell(r, 2)
            if not a:
                continue
            low = a.lower()

            if low.startswith("billing type"):
                if isinstance(b, str):
                    billing = billing or _clean(b).replace("\n", " ")
                continue
            # 'Ground Domestic Single Piece' | 0.25  -> earned discount row
            if _num(b) is not None and _num(b) <= 1:
                if discount is None:
                    discount = _num(b)
                continue
            # sub-section labels of a nearby discount table (Envelope/Pak/Package)
            if low.rstrip(":") in _SECTION_MARKERS:
                continue
            if low in ("weight", "weight range", "zone(s)"):
                continue
            if any(low.startswith(p) for p in skip_prefixes):
                continue
            if len(a) > 90:
                continue
            # a genuine service title
            title = a
            break
        return title, billing, discount

    def _collect_sections(self, block: RateBlock) -> None:
        """Walk down from the header row splitting Envelope / Pak / Package."""
        r = block.header_row + 1
        current_kind: Optional[str] = None
        start: Optional[int] = None
        last_data: Optional[int] = None
        weights: List[float] = []
        blank_run = 0
        n_rows = len(self.rows)

        def close():
            nonlocal current_kind, start, last_data, weights
            if current_kind and start is not None and last_data is not None:
                sec = RateSection(
                    kind=current_kind,
                    first_row=start,
                    last_row=last_data,
                    min_weight=min(weights) if weights else None,
                    max_weight=max(weights) if weights else None,
                )
                if sec.last_row >= sec.first_row:
                    block.sections.setdefault(current_kind, sec)
            current_kind, start, last_data, weights = None, None, None, []

        while r <= n_rows:
            a = self._cell(r, 1)
            b = self._cell(r, 2)
            a_txt = _clean(a).lower().rstrip(":")

            # a new zone header, or a new titled table -> this block is over
            if a_txt in _HEADER_TOKENS:
                break

            if a_txt in _SECTION_MARKERS and _num(b) is None:
                close()
                blank_run = 0
                current_kind = _SECTION_MARKERS[a_txt]
                start = None
                r += 1
                continue

            weight = _num(a)
            rng_start = _range_start(a)
            has_rates = any(_num(self._cell(r, c)) is not None
                            for c in range(2, block.last_col + 1))

            if weight is not None and has_rates:
                blank_run = 0
                if current_kind is None:
                    current_kind = "package"
                if start is None:
                    start = r
                last_data = r
                weights.append(weight)
            elif rng_start is not None and has_rates:
                blank_run = 0
                block.is_per_pound = True
                if current_kind is None:
                    current_kind = "package"
                if start is None:
                    start = r
                last_data = r
                weights.append(rng_start)
                block.weight_starts.append(rng_start)
            elif a in (None, "") and has_rates and current_kind == "envelope":
                # the envelope rate row carries no weight label
                blank_run = 0
                if start is None:
                    start = r
                last_data = r
            elif a in (None, "") and not has_rates:
                blank_run += 1
                if blank_run >= 3:
                    break
            else:
                # a stray label (e.g. 'Net rates highlighted...') ends the table
                if current_kind and start is not None:
                    break
                blank_run = 0
            r += 1

        blank_run = 0
        close()

        # remember, per section, the weight range that was seen
        for kind, sec in block.sections.items():
            if kind == "envelope":
                sec.min_weight = sec.max_weight = 1.0


@dataclass
class RateSheetInfo:
    """Sheet-level facts an analyst reads off the top of a rate sheet."""

    sheet: str
    effective_date: Optional[object] = None
    effective_year: Optional[int] = None
    customer: str = ""
    # Services the sheet explicitly punts to list rates, e.g.
    # "Please refer to list rates for this service."
    list_rate_services: List[str] = field(default_factory=list)


_EFFECTIVE_RE = re.compile(
    r"effective\s+(?:as\s+of\s+)?(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})", re.I)
_YEAR_RE = re.compile(r"(20\d{2})")
_MONTHS = {m.lower(): i for i, m in enumerate(
    ["January", "February", "March", "April", "May", "June", "July",
     "August", "September", "October", "November", "December"], start=1)}


def read_sheet_info(worksheet, sheet_name: Optional[str] = None) -> RateSheetInfo:
    """Pull the effective date, customer and list-rate notices off a sheet."""
    import datetime as _dt

    parser = RateSheetParser(worksheet, sheet_name)
    parser._load()
    name = sheet_name or worksheet.title
    info = RateSheetInfo(sheet=name)

    for r_idx, row in enumerate(parser.rows, start=1):
        for c_idx, value in enumerate(row, start=1):
            if not isinstance(value, str):
                if (info.effective_date is None
                        and isinstance(value, _dt.datetime)
                        and c_idx > 1
                        and isinstance(row[0], str)
                        and "effective" in row[0].lower()):
                    info.effective_date = value
                    info.effective_year = value.year
                continue

            low = value.lower()
            if "effective" in low and info.effective_date is None:
                m = _EFFECTIVE_RE.search(value)
                if m:
                    month = _MONTHS.get(m.group(2).lower())
                    if month:
                        info.effective_date = _dt.datetime(
                            int(m.group(3)), month, int(m.group(1)))
                        info.effective_year = int(m.group(3))
                elif _YEAR_RE.search(value):
                    info.effective_year = int(_YEAR_RE.search(value).group(1))
            if "refer to list rates" in low:
                title, _, _ = parser._find_title(r_idx)
                svc = normalise_service(title) if title else ""
                if svc and svc not in info.list_rate_services:
                    info.list_rate_services.append(svc)
            if low.startswith("customer name") and not info.customer:
                for v in row[1:]:
                    if isinstance(v, str) and v.strip():
                        info.customer = v.strip()
                        break
    return info


def parse_workbook(workbook, sheet_names: Optional[List[str]] = None
                   ) -> List[RateBlock]:
    """Parse every (or the named) worksheet of an open rate-sheet workbook."""
    blocks: List[RateBlock] = []
    names = sheet_names or workbook.sheetnames
    for name in names:
        blocks.extend(RateSheetParser(workbook[name], name).parse())
    return blocks


def index_blocks(blocks: List[RateBlock]) -> Dict[str, List[RateBlock]]:
    """Group blocks by normalised service name, standard tables first."""
    out: Dict[str, List[RateBlock]] = {}
    for b in blocks:
        out.setdefault(b.service, []).append(b)
    for lst in out.values():
        lst.sort(key=lambda b: (b.is_per_pound, b.header_row))
    return out
