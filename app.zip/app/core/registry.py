"""
Process registry.

Every re-rating process registers itself here.  app.py reads this list to
build the sidebar, so adding a new process means adding one entry - no changes
to the Streamlit shell.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List


@dataclass
class Process:
    key: str
    name: str
    description: str
    render: Callable[[], None]
    status: str = "ready"          # 'ready' | 'planned'


def _load() -> List[Process]:
    from ui import dim_mbw_ui, rate_comparison_ui

    return [
        Process(
            key="rate_comparison",
            name="Rate Comparison",
            description=(
                "Cleanse shipment data, rate every shipment against the "
                "Current and Proposed Net Rate Sheets, and build the Summary."
            ),
            render=rate_comparison_ui.render,
        ),
        Process(
            key="dim_mbw",
            name="DIM Change & MBW",
            description=(
                "Recalculate L/W/H, DIM volume and rated weights for a new DIM "
                "factor, then apply UA / OS / AHS minimum billable weights."
            ),
            render=dim_mbw_ui.render,
        ),
        # Surcharge Analysis is no longer a standalone sidebar entry - it
        # runs as an optional step inside Rate Comparison and DIM Change &
        # MBW's own "Surcharges" tab (see ui/surcharge_ui.py::SurchargeStep).
        Process(
            key="zone_change",
            name="Zone Change Analysis",
            description=(
                "Derive new origin ZIPs, look up the new zones and re-rate "
                "both zone sets side by side."
            ),
            render=_planned("Zone Change Analysis"),
            status="planned",
        ),
        Process(
            key="multiweight",
            name="Multiweight Re-Rating",
            description=(
                "Build shipment tags, MWT tier rate tables, cost per lb and "
                "the Rated / DNR flags."
            ),
            render=_planned("Multiweight Re-Rating"),
            status="planned",
        ),
    ]


def _planned(name: str):
    def render() -> None:
        import streamlit as st

        st.header(name)
        st.info(
            f"**{name}** is next in the build queue. The Rate Comparison "
            "module is live - its cleansing, rate-sheet parser and formula "
            "builders are shared, so this process plugs straight into them."
        )
    return render


PROCESSES: List[Process] = []


def get_processes() -> List[Process]:
    global PROCESSES
    if not PROCESSES:
        PROCESSES = _load()
    return PROCESSES
