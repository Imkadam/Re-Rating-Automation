"""
Shipment Data loading and cleansing (procedure steps 1-3).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd

from .config import (
    ALPHA_ZONE_MAP,
    COL,
    DEFAULT_EXCLUDED_PRODUCT_KEYWORDS,
    NON_US_DOMESTIC_ZONES,
    RETAIN_COLUMNS,
)


# --------------------------------------------------------------------------
@dataclass
class CleanseOptions:
    excluded_products: List[str] = field(default_factory=list)
    drop_zero_freight: bool = True
    drop_non_us_zones: bool = True
    drop_multi_piece: bool = True
    drop_non_us_origin: bool = True
    drop_non_us_dest: bool = True
    drop_over_150: bool = False       # heavyweight handled separately
    max_weight: float = 150.0


@dataclass
class CleanseReport:
    """Row counts removed by each rule - shown in the UI and in Summary notes."""

    starting_rows: int = 0
    removed: Dict[str, int] = field(default_factory=dict)
    final_rows: int = 0

    def note_lines(self) -> List[str]:
        lines = [f"Rows extracted: {self.starting_rows:,}"]
        for rule, n in self.removed.items():
            if n:
                lines.append(f"Excluded - {rule}: {n:,} rows")
        lines.append(f"Rows rated: {self.final_rows:,}")
        return lines


# --------------------------------------------------------------------------
def load_shipment_data(path_or_buffer, sheet_name: str = "Shipment Data"
                       ) -> pd.DataFrame:
    """Read the Shipment Detail Template extract into a DataFrame."""
    df = pd.read_excel(path_or_buffer, sheet_name=sheet_name)
    df.columns = [str(c).strip() for c in df.columns]
    return df


def list_sheets(path_or_buffer) -> List[str]:
    return pd.ExcelFile(path_or_buffer).sheet_names


# --------------------------------------------------------------------------
def _as_text(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip()


def normalise_zone(value) -> Optional[float]:
    """
    Procedure step 4: "standardize the Zone values ... by replacing any
    alphabetical zone codes with their corresponding numeric zone values".
    """
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip().upper()
    if not s:
        return None
    if s in ALPHA_ZONE_MAP:
        return float(ALPHA_ZONE_MAP[s])
    # forms like '17 (A)' or '9(H)'
    for letter, num in ALPHA_ZONE_MAP.items():
        if s.endswith(f"({letter})") or s == letter:
            return float(num)
    digits = "".join(ch for ch in s if ch.isdigit() or ch == ".")
    try:
        return float(digits) if digits else None
    except ValueError:
        return None


def default_excluded_products(df: pd.DataFrame) -> List[str]:
    """Pre-tick the products normally excluded."""
    if COL["product"] not in df.columns:
        return []
    products = sorted(_as_text(df[COL["product"]]).dropna().unique())
    out = []
    for p in products:
        low = p.lower()
        if any(k.lower() in low for k in DEFAULT_EXCLUDED_PRODUCT_KEYWORDS):
            out.append(p)
    return out


# --------------------------------------------------------------------------
def cleanse(df: pd.DataFrame, opts: CleanseOptions
            ) -> tuple[pd.DataFrame, CleanseReport]:
    """Apply procedure step 2 - 'Cleanse Shipment Data'."""
    rep = CleanseReport(starting_rows=len(df))
    out = df.copy()

    def drop(mask: pd.Series, label: str) -> None:
        nonlocal out
        n = int(mask.sum())
        rep.removed[label] = rep.removed.get(label, 0) + n
        if n:
            out = out.loc[~mask].copy()

    if opts.excluded_products and COL["product"] in out.columns:
        mask = _as_text(out[COL["product"]]).isin(opts.excluded_products)
        drop(mask, "Product Name not under review")

    if opts.drop_zero_freight and COL["list_freight"] in out.columns:
        v = pd.to_numeric(out[COL["list_freight"]], errors="coerce")
        drop(v.isna() | (v == 0), "USD List Freight Charge is $0 or blank")

    if opts.drop_non_us_zones and COL["zone"] in out.columns:
        z = out[COL["zone"]].map(normalise_zone)
        drop(z.isna() | z.isin(NON_US_DOMESTIC_ZONES),
             "Non-US Domestic zone (e.g. Zone 51, Zone 00)")

    if opts.drop_multi_piece and COL["pieces"] in out.columns:
        p = pd.to_numeric(out[COL["pieces"]], errors="coerce")
        drop(p > 1, "Pieces greater than 1")

    if opts.drop_non_us_origin and COL["origin_region"] in out.columns:
        drop(_as_text(out[COL["origin_region"]]).str.upper() != "US",
             "Origin Region is not US")

    if opts.drop_non_us_dest and COL["dest_region"] in out.columns:
        drop(_as_text(out[COL["dest_region"]]).str.upper() != "US",
             "Destination Region is not US")

    if opts.drop_over_150 and COL["rated_weight"] in out.columns:
        w = pd.to_numeric(out[COL["rated_weight"]], errors="coerce")
        drop(w > opts.max_weight,
             f"Rated weight greater than {opts.max_weight:g} lbs")

    rep.final_rows = len(out)
    return out.reset_index(drop=True), rep


def retain_columns(df: pd.DataFrame,
                   extra: Optional[List[str]] = None) -> pd.DataFrame:
    """Procedure step 3 - keep only the columns the analysis needs."""
    wanted = list(RETAIN_COLUMNS) + list(extra or [])
    present = [c for c in wanted if c in df.columns]
    return df[present].copy()


def add_normalised_zone(df: pd.DataFrame,
                        target: str = "Zone (Numeric)") -> pd.DataFrame:
    out = df.copy()
    if COL["zone"] in out.columns:
        out[target] = out[COL["zone"]].map(normalise_zone)
    return out


def date_range_label(df: pd.DataFrame) -> str:
    """'Mar 2025 - Mar 2026' style label for the top of the Summary tab."""
    for col in (COL["ship_date"], COL["invoice_date"]):
        if col in df.columns:
            s = pd.to_datetime(df[col], errors="coerce").dropna()
            if not s.empty:
                return f"{s.min():%b %Y} - {s.max():%b %Y}"
    return ""
