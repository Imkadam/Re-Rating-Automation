"""
Process 1 - Rate Comparison  ("Rate comparison")

Takes an extracted Shipment Detail dataset plus Current and Proposed Net Rate
Sheets, and produces a workbook where every Current Cost / Proposed Cost cell
is a live Excel formula against the embedded rate-sheet tabs.

Output tabs
-----------
Summary          date range, notes, service-level table, impact %, disclaimer
Rate Detail      one row per shipment with the live rate formulas
Shipment Data    the cleansed dataset (retained columns only)
current_rates    embedded Current Net Rate Sheet   (+ AS rows, helper column)
proposed_rates   embedded Proposed Net Rate Sheet  (+ AS rows, helper column)
list_rates       embedded List Rate Sheet, when one is supplied
Zone Map         alpha -> numeric zone reference
"""

from __future__ import annotations

from dataclasses import dataclass, field
from io import BytesIO
from typing import Dict, List, Optional, Sequence, Tuple

import openpyxl
import pandas as pd
from openpyxl.utils import get_column_letter

from core import formulas as F
from core.evaluate import (
    MODE_ENVELOPE,
    MODE_NONE,
    MODE_PER_POUND,
    MODE_RANGE,
    MODE_STANDARD,
    RatePlan,
    SheetGrid,
    build_grids,
    evaluate,
)
from core.config import (
    COL,
    ENVELOPE_PACKAGE_TYPES,
    FALLBACK_PROPOSED_TO_CURRENT,
    FMT_INT,
    FMT_MONEY,
    FMT_MONEY_2DP,
    FMT_PCT_1DP,
    LIST_FALLBACK_BLANK,
    LIST_FALLBACK_CURRENT,
    LIST_FALLBACK_LABELS,
    LIST_FALLBACK_NOTES,
    MISSING_EXCLUDE,
    MISSING_LEAVE_BLANK,
    MISSING_LIST_RATES,
    MISSING_STRATEGY_LABELS,
    MISSING_STRATEGY_NOTES,
    MISSING_USE_CURRENT,
    PAK_MAX_WEIGHT,
    PAK_PACKAGE_TYPES,
    PRODUCT_TO_RATESHEET_SERVICE,
    STANDARD_MAX_WEIGHT,
    SUMMARY_SERVICE_ORDER,
)
from core.excel_writer import (
    BOLD,
    BOX,
    TITLE_FONT,
    autosize,
    embed_ratesheet,
    mark_total_row,
    new_workbook,
    style_header_row,
    write_disclaimer,
    write_notes_block,
    write_zone_map,
)
from core.ratesheet import (
    RateBlock,
    RateSheetInfo,
    RateSheetParser,
    index_blocks,
    read_sheet_info,
)
from core.shipment import (
    CleanseOptions,
    CleanseReport,
    add_normalised_zone,
    cleanse,
    date_range_label,
    retain_columns,
)
from processes import surcharge_analysis as SA

PROCESS_NAME = "Rate Comparison"
PROCESS_DESCRIPTION = (
    "Cleanse shipment data, rate every shipment against the Current and "
    "Proposed Net Rate Sheets with live VLOOKUP/MATCH formulas, and build the "
    "Summary tab with impact and disclaimer."
)

DETAIL_SHEET = "Rate Detail"
CURRENT_SHEET = "current_rates"
PROPOSED_SHEET = "proposed_rates"
LIST_SHEET = "list_rates"
DATA_SHEET = "Shipment Data"
ZONE_SHEET = "Zone Map"


# ==========================================================================
# Heavyweight strategies ("Heavyweight Shipment Re-Rating")
# ==========================================================================
HEAVY_AUTO = "auto"        # heavyweight table when present, else the AS row
HEAVY_PER_LB = "per_lb"    # always 150 lb rate / 150 x rated weight
HEAVY_TABLE = "table"      # always the heavyweight / per-lb table

HEAVY_METHOD_LABELS = {
    HEAVY_AUTO: "Auto — Express heavyweight table when present, otherwise "
                "the derived per-pound (AS) row",
    HEAVY_PER_LB: "Always the derived per-pound row (150 lb rate ÷ 150 × "
                  "rated weight)",
    HEAVY_TABLE: "Always the heavyweight rate table (approximate match on "
                 "rated weight and zone)",
}


# ==========================================================================
# configuration objects
# ==========================================================================
@dataclass
class ServiceMapping:
    """Which rate-sheet block rates a given shipment Product Name."""

    product: str
    current_block: Optional[RateBlock] = None
    proposed_block: Optional[RateBlock] = None
    current_heavy: Optional[RateBlock] = None
    proposed_heavy: Optional[RateBlock] = None
    note: str = ""
    # True when the Proposed rate sheet carries no table for this service.
    proposed_missing: bool = False
    # How that gap is filled - one of the MISSING_* constants.
    missing_strategy: str = ""
    # Where the Proposed rate actually comes from:
    # 'proposed' | 'current' | 'list' | 'none'
    proposed_source: str = "proposed"


@dataclass
class RateComparisonConfig:
    cleanse: CleanseOptions = field(default_factory=CleanseOptions)
    mappings: Dict[str, ServiceMapping] = field(default_factory=dict)
    analysis_notes: List[str] = field(default_factory=list)
    date_range: str = ""
    cht_id: str = ""
    fuel_express: Optional[float] = None
    fuel_ground: Optional[float] = None
    include_shipment_data: bool = True

    # heavyweight
    heavy_method: str = HEAVY_AUTO
    heavy_threshold: float = STANDARD_MAX_WEIGHT
    write_per_pound_rows: bool = True

    # services missing from the Proposed sheet: product -> MISSING_* strategy
    missing_proposed: Dict[str, str] = field(default_factory=dict)
    # when using List Rates, also rate the Current side from them
    list_rates_for_current: Dict[str, bool] = field(default_factory=dict)
    # product -> LIST_FALLBACK_*, used when the List Rate Sheet has no table
    # for that service
    list_fallback: Dict[str, str] = field(default_factory=dict)


# ==========================================================================
# rate-sheet loading
# ==========================================================================
def load_ratesheet_blocks(path_or_buffer,
                          sheet_names: Optional[List[str]] = None
                          ) -> Tuple[openpyxl.Workbook, List[RateBlock]]:
    """Open a net rate sheet workbook and detect every rate table in it."""
    wb = openpyxl.load_workbook(path_or_buffer, data_only=True)
    names = sheet_names or wb.sheetnames
    blocks: List[RateBlock] = []
    for name in names:
        blocks.extend(RateSheetParser(wb[name], name).parse())
    return wb, blocks


def load_ratesheet_info(wb: openpyxl.Workbook,
                        sheet_names: Optional[List[str]] = None
                        ) -> RateSheetInfo:
    """Effective date, customer and list-rate notices for a rate sheet."""
    names = sheet_names or wb.sheetnames
    merged = RateSheetInfo(sheet=names[0] if names else "")
    for name in names:
        info = read_sheet_info(wb[name], name)
        if merged.effective_date is None:
            merged.effective_date = info.effective_date
            merged.effective_year = info.effective_year
        if not merged.customer:
            merged.customer = info.customer
        for svc in info.list_rate_services:
            if svc not in merged.list_rate_services:
                merged.list_rate_services.append(svc)
    return merged


# ==========================================================================
# service -> rate table mapping
# ==========================================================================
def pick_block(idx: Dict[str, List[RateBlock]], product: str, heavy: bool
               ) -> Optional[RateBlock]:
    """
    Find the rate table for a Product Name.

    Preference order: exact service match, then the alias in
    PRODUCT_TO_RATESHEET_SERVICE (e.g. Multiweight -> Ground single piece),
    then a service whose name contains the product name.
    """
    candidates: List[RateBlock] = []
    for key in (product, PRODUCT_TO_RATESHEET_SERVICE.get(product, "")):
        if key and key in idx:
            candidates = idx[key]
            break
    if not candidates:
        low = product.lower()
        for svc, blocks in idx.items():
            if svc.lower() == low or low in svc.lower():
                candidates = blocks
                break
    if not candidates:
        return None
    wanted = [b for b in candidates if b.is_per_pound == heavy]
    return wanted[0] if wanted else None


def default_missing_strategy(product: str,
                             current_year: Optional[int],
                             proposed_year: Optional[int],
                             list_available: bool,
                             current_available: bool) -> str:
    """
    The documented decision for a service missing from the Proposed sheet.

    First Overnight (FO) Shipments:
      * "If Proposed Rates are unavailable and both Net Rate Sheets are from
         the same year, use the Current Rates as the Proposed Rates."
      * "If the Current and Proposed Net Rate Sheets are from different years,
         use FO List Rates to rate the shipments."

    Anything the rule does not cover is left blank rather than guessed, so a
    missing table can never quietly become a fabricated saving.
    """
    if product not in FALLBACK_PROPOSED_TO_CURRENT:
        return MISSING_LEAVE_BLANK
    if current_year and proposed_year and current_year != proposed_year:
        return MISSING_LIST_RATES if list_available else MISSING_LEAVE_BLANK
    return MISSING_USE_CURRENT if current_available else MISSING_LEAVE_BLANK


def build_default_mappings(products: Sequence[str],
                           current_blocks: List[RateBlock],
                           proposed_blocks: List[RateBlock],
                           list_blocks: Optional[List[RateBlock]] = None,
                           current_year: Optional[int] = None,
                           proposed_year: Optional[int] = None
                           ) -> Dict[str, ServiceMapping]:
    """Work out, for every Product Name in the data, which rate table to use."""
    cur_idx = index_blocks(current_blocks)
    pro_idx = index_blocks(proposed_blocks)
    lst_idx = index_blocks(list_blocks or [])

    mappings: Dict[str, ServiceMapping] = {}
    for product in products:
        m = ServiceMapping(product=product)
        m.current_block = pick_block(cur_idx, product, heavy=False)
        m.proposed_block = pick_block(pro_idx, product, heavy=False)
        m.current_heavy = pick_block(cur_idx, product, heavy=True)
        m.proposed_heavy = pick_block(pro_idx, product, heavy=True)

        if m.proposed_block is None:
            m.proposed_missing = True
            m.missing_strategy = default_missing_strategy(
                product, current_year, proposed_year,
                list_available=pick_block(lst_idx, product, False) is not None,
                current_available=m.current_block is not None,
            )
        mappings[product] = m
    return mappings


def apply_missing_strategies(mappings: Dict[str, ServiceMapping],
                             strategies: Optional[Dict[str, str]] = None,
                             list_blocks: Optional[List[RateBlock]] = None,
                             list_for_current: Optional[Dict[str, bool]] = None,
                             list_fallback: Optional[Dict[str, str]] = None
                             ) -> Tuple[Dict[str, ServiceMapping], List[str]]:
    """
    Fill the Proposed side for services the Proposed rate sheet does not cover.

    Returns the mappings and the products to exclude from the analysis.
    """
    lst_idx = index_blocks(list_blocks or [])
    strategies = strategies or {}
    list_for_current = list_for_current or {}
    excluded: List[str] = []

    for product, m in mappings.items():
        if not m.proposed_missing:
            m.proposed_source = "proposed"
            continue

        strategy = strategies.get(
            product, m.missing_strategy or MISSING_LEAVE_BLANK)
        m.missing_strategy = strategy
        m.note = MISSING_STRATEGY_NOTES.get(strategy, "")

        if strategy == MISSING_USE_CURRENT:
            if m.current_block is None:
                m.proposed_block = None
                m.proposed_source = "none"
                m.note = ("Proposed rates unavailable and no Current table "
                          "either - left unrated")
            else:
                m.proposed_block = m.current_block
                m.proposed_heavy = m.proposed_heavy or m.current_heavy
                m.proposed_source = "current"

        elif strategy == MISSING_LIST_RATES:
            lb = pick_block(lst_idx, product, heavy=False)
            lh = pick_block(lst_idx, product, heavy=True)
            if lb is not None:
                m.proposed_block = lb
                m.proposed_heavy = lh
                m.proposed_source = "list"
                if list_for_current.get(product):
                    m.current_block = lb
                    m.current_heavy = lh
                    m.note += " (List Rates applied to the Current side too)"
            else:
                # The List Rate Sheet does not cover this service. Fall back to
                # the Current rates when asked to, otherwise leave it blank -
                # never silently substitute something else.
                fb = (list_fallback or {}).get(product, LIST_FALLBACK_CURRENT)
                if fb == LIST_FALLBACK_CURRENT and m.current_block is not None:
                    m.proposed_block = m.current_block
                    m.proposed_heavy = m.proposed_heavy or m.current_heavy
                    m.proposed_source = "current"
                    m.note = LIST_FALLBACK_NOTES[LIST_FALLBACK_CURRENT]
                else:
                    m.proposed_block = None
                    m.proposed_source = "none"
                    m.note = LIST_FALLBACK_NOTES[LIST_FALLBACK_BLANK]

        elif strategy == MISSING_EXCLUDE:
            excluded.append(product)
            m.proposed_source = "none"

        else:                                     # MISSING_LEAVE_BLANK
            m.proposed_block = None
            m.proposed_source = "none"

    return mappings, excluded


# ==========================================================================
# section selection
# ==========================================================================
def section_for(package_type: str, weight: float, block: RateBlock) -> str:
    """
    Pick the Envelope / Pak / Package sub-table for one shipment.

    Special handling:
      * Envelope/Letter -> always the 1 lb Envelope rate.
      * Pak over 2 lbs   -> Customer Packaging rates.
      * Pak rates absent -> Customer Packaging rates.
    """
    pt = (package_type or "").strip().lower()
    if pt in ENVELOPE_PACKAGE_TYPES or "letter" in pt or "envelope" in pt:
        return "envelope" if block.has("envelope") else "package"
    if pt in PAK_PACKAGE_TYPES or pt.endswith(" pak"):
        if block.has("pak") and (weight or 0) <= PAK_MAX_WEIGHT:
            return "pak"
        return "package"
    return "package"


def plan_rate(block: Optional[RateBlock], heavy: Optional[RateBlock],
              package_type: str, weight: float,
              method: str = HEAVY_AUTO,
              threshold: float = STANDARD_MAX_WEIGHT) -> RatePlan:
    """
    Decide how one shipment is rated - once, for both the Excel formula and
    the on-screen value.

    Procedure, "Heavyweight Shipment Re-Rating (Packages > 150 lbs)":

      * insert a per-pound row below the 150 lb row, ``Per-Pound Rate =
        150 lbs Rate / 150``, and ``Shipment Rate = Per-Pound Rate x Rated
        Weight``;
      * "For Express Heavyweight shipments, locate the heavyweight rate table
        which is generally placed below the standard rate table of specific
        service. Use an approximate match lookup on the Rated Weight and Zone."
    """
    if block is None:
        # Freight services only ever have a weight-range / per-pound table.
        if heavy is not None:
            return RatePlan(MODE_RANGE, heavy, "package",
                            "Freight weight-range per-lb rate x rated weight")
        return RatePlan(MODE_NONE, None, "package", "no rate table")

    kind = section_for(package_type, weight, block)

    if kind == "envelope":
        return RatePlan(MODE_ENVELOPE, block, kind, "Envelope 1 lb rate")

    if weight is not None and weight > threshold:
        return _plan_heavyweight(block, heavy, method)

    if block.is_per_pound:
        return RatePlan(MODE_RANGE, block, "package",
                        "Freight weight-range per-lb rate x rated weight")

    return RatePlan(MODE_STANDARD, block, kind, f"{kind.title()} rate")


def _plan_heavyweight(block: Optional[RateBlock], heavy: Optional[RateBlock],
                      method: str) -> RatePlan:
    def from_table() -> Optional[RatePlan]:
        if heavy is None:
            return None
        return RatePlan(
            MODE_RANGE, heavy, "package",
            "Heavyweight table, approx match on weight & zone x rated weight")

    def from_per_lb() -> Optional[RatePlan]:
        if block is None or "package" not in block.sections:
            return None
        sec = block.sections["package"]
        divisor = sec.max_weight or 150
        tag = "AS row" if block.per_pound_row else "inline"
        return RatePlan(
            MODE_PER_POUND, block, "package",
            f"Heavyweight per-pound ({tag}: {divisor:g} lb rate / "
            f"{divisor:g}) x rated weight")

    order = (from_per_lb, from_table) if method == HEAVY_PER_LB \
        else (from_table, from_per_lb)
    for builder in order:
        plan = builder()
        if plan is not None:
            return plan
    return RatePlan(MODE_NONE, None, "package", "no heavyweight rate available")


def formula_for(plan: RatePlan, helper_for, weight_ref: str, zone_ref: str
                ) -> Optional[str]:
    """Render the plan as the Excel formula the analyst would have written."""
    block = plan.block
    if block is None or plan.mode == MODE_NONE:
        return None
    if plan.mode == MODE_ENVELOPE:
        return F.envelope_rate(block, zone_ref)
    if plan.mode == MODE_STANDARD:
        return F.standard_rate(block, weight_ref, zone_ref, plan.kind)
    if plan.mode == MODE_RANGE:
        return F.per_pound_rate(block, weight_ref, zone_ref, helper_for(block))
    if plan.mode == MODE_PER_POUND:
        return F.per_pound_from_150(block, weight_ref, zone_ref)
    return None


# ==========================================================================
# main entry point
# ==========================================================================
def run(shipment_df: pd.DataFrame,
        current_wb: openpyxl.Workbook, current_blocks: List[RateBlock],
        proposed_wb: openpyxl.Workbook, proposed_blocks: List[RateBlock],
        config: RateComparisonConfig,
        list_wb: Optional[openpyxl.Workbook] = None,
        list_blocks: Optional[List[RateBlock]] = None,
        surcharge_df: Optional[pd.DataFrame] = None,
        surcharge_config: Optional[SA.SurchargeConfig] = None,
        ) -> Tuple[BytesIO, CleanseReport, pd.DataFrame, Optional[pd.DataFrame]]:
    """
    Run the rate comparison and return (workbook bytes, cleanse report, the
    rated detail frame used to build it, the surcharge summary frame).

    When `surcharge_df` / `surcharge_config` are given, a Surcharge Analysis
    step is appended onto this same workbook — its own Detail and Rules
    tabs, and its Summary section folded directly into this Summary tab,
    right after the rate impact table. Its Transportation cost is auto-filled
    from this analysis's own OpCo cost totals unless the config already sets
    it. The last element of the return tuple is the surcharge summary table
    (``None`` when no surcharge step was included) for the on-screen preview.
    """
    wb = new_workbook()

    # --- tabs, created up front so formulas can point at them -------------
    summary_ws = wb.create_sheet("Summary")
    detail_ws = wb.create_sheet(DETAIL_SHEET)
    data_ws = wb.create_sheet(DATA_SHEET) if config.include_shipment_data else None
    zone_range = write_zone_map(wb, ZONE_SHEET)

    # Embedding inserts the per-pound ("AS") rows, so it also hands back the
    # blocks re-pointed at their new row numbers.
    cur_sheets, cur_blocks = _embed(wb, current_wb, current_blocks,
                                    CURRENT_SHEET, config.write_per_pound_rows)
    pro_sheets, pro_blocks = _embed(wb, proposed_wb, proposed_blocks,
                                    PROPOSED_SHEET, config.write_per_pound_rows)
    lst_blocks: List[RateBlock] = []
    if list_wb is not None and list_blocks:
        _, lst_blocks = _embed(wb, list_wb, list_blocks, LIST_SHEET,
                               config.write_per_pound_rows)

    # helper column, resolved by the sheet a block actually lives on
    helper_by_sheet: Dict[str, int] = {}
    for sheets in (cur_sheets, pro_sheets):
        for name, emb in sheets.items():
            helper_by_sheet[name] = emb.helper_col
    for name in wb.sheetnames:
        helper_by_sheet.setdefault(name, 20)

    def helper_for(block: RateBlock) -> int:
        return helper_by_sheet.get(block.sheet, 20)

    # --- service mapping --------------------------------------------------
    products_all = sorted(
        shipment_df[COL["product"]].astype(str).str.strip().unique()
    ) if COL["product"] in shipment_df.columns else []

    mappings = config.mappings or build_default_mappings(
        products_all, cur_blocks, pro_blocks, lst_blocks)
    mappings = _rebind_mappings(mappings, cur_blocks, pro_blocks, lst_blocks)
    mappings, excluded = apply_missing_strategies(
        mappings, config.missing_proposed, lst_blocks,
        config.list_rates_for_current, config.list_fallback)

    # --- cleanse (services excluded above drop out here) ------------------
    opts = config.cleanse
    if excluded:
        opts = CleanseOptions(**{**opts.__dict__})
        opts.excluded_products = list(
            dict.fromkeys(list(opts.excluded_products) + excluded))

    clean_df, report = cleanse(shipment_df, opts)
    clean_df = retain_columns(clean_df)
    clean_df = add_normalised_zone(clean_df)

    date_range = config.date_range or date_range_label(clean_df)

    # Values for the on-screen Summary, read from the tabs the formulas point
    # at, so preview and workbook cannot disagree.
    grids = build_grids(wb, [n for n in wb.sheetnames
                             if n.startswith((CURRENT_SHEET, PROPOSED_SHEET,
                                              LIST_SHEET))])

    detail = _write_detail(
        detail_ws, clean_df, mappings, helper_for, zone_range, grids,
        heavy_method=config.heavy_method,
        heavy_threshold=config.heavy_threshold,
    )

    if data_ws is not None:
        _write_shipment_data(data_ws, clean_df)

    end_row = _write_summary(summary_ws, detail, report, mappings, config,
                             date_range)

    surcharge_reported = None
    if surcharge_df is not None and surcharge_config is not None \
            and not surcharge_df.empty:
        totals = opco_cost_totals(detail["frame"])
        end_row, surcharge_reported = SA.build_into(
            wb, summary_ws, end_row, surcharge_df, surcharge_config, totals)

    write_disclaimer(summary_ws, end_row)

    wb.move_sheet("Summary", offset=-wb.sheetnames.index("Summary"))

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf, report, detail["frame"], surcharge_reported


# --------------------------------------------------------------------------
def _embed(wb, source_wb, blocks: List[RateBlock], base_name: str,
           per_pound: bool = True):
    """
    Copy every worksheet that holds blocks into the output workbook.

    Returns ``(sheets, blocks)`` where the blocks have been re-pointed at the
    row numbers they occupy after the per-pound rows were inserted.
    """
    by_sheet: Dict[str, List[RateBlock]] = {}
    for b in blocks:
        by_sheet.setdefault(b.sheet, []).append(b)

    out: Dict[str, object] = {}
    rebound: List[RateBlock] = []
    first = True
    for sheet_name, sheet_blocks in by_sheet.items():
        target = base_name if first else f"{base_name}_{sheet_name}"[:31]
        emb = embed_ratesheet(wb, source_wb[sheet_name], target, sheet_blocks,
                              add_per_pound_rows=per_pound)
        out[target] = emb
        rebound.extend(emb.blocks or [])
        first = False
    if not out:
        ws = wb.create_sheet(base_name)
        ws["A1"] = "No rate tables detected on this rate sheet."
        from core.excel_writer import EmbeddedSheet
        out[base_name] = EmbeddedSheet(base_name, 20, 1, [], base_name)
    return out, rebound


def _rebind_mappings(mappings: Dict[str, ServiceMapping],
                     cur_blocks: List[RateBlock],
                     pro_blocks: List[RateBlock],
                     lst_blocks: Optional[List[RateBlock]] = None
                     ) -> Dict[str, ServiceMapping]:
    """
    Swap any pre-selected blocks for their embedded equivalents.

    The UI hands back blocks parsed from the *source* workbook, whose row
    numbers shift once the per-pound rows are inserted. Blocks are matched on
    their stable source identity, never guessed - an unmatched block stays
    None so the shipment is reported as unrated rather than being silently
    rated against the wrong table.

    Each side is matched against its **own** pool. A block's identity is its
    source worksheet name plus header row, and two different rate sheets are
    quite capable of both being called "Sheet1" with a table at the same row -
    so a single merged pool would let a Proposed block resolve to the Current
    sheet's table of the same name.
    """
    def finder(pool):
        def find(block):
            if block is None:
                return None
            for b in pool:
                if b.uid == block.uid:
                    return b
            return None
        return find

    find_cur = finder(list(cur_blocks))
    find_pro = finder(list(pro_blocks) + list(lst_blocks or []))

    out: Dict[str, ServiceMapping] = {}
    for k, m in mappings.items():
        out[k] = ServiceMapping(
            product=m.product,
            current_block=find_cur(m.current_block),
            proposed_block=find_pro(m.proposed_block),
            current_heavy=find_cur(m.current_heavy),
            proposed_heavy=find_pro(m.proposed_heavy),
            note=m.note,
            proposed_missing=m.proposed_missing,
            missing_strategy=m.missing_strategy,
            proposed_source=m.proposed_source,
        )
    return out


# --------------------------------------------------------------------------
DETAIL_HEADERS = [
    "ID", "Tracking Number", "Product Name", "Package Type", "Pay Type",
    "Pieces", "Shipments", "Rated Weight (Lbs)", "Zone", "Zone (Numeric)",
    "Lookup Weight", "Current Cost", "Proposed Cost", "Impact",
    "Current Method", "Proposed Method", "Proposed Rate Source",
]
DCOL = {name: i + 1 for i, name in enumerate(DETAIL_HEADERS)}

PROPOSED_SOURCE_LABELS = {
    "proposed": "Proposed rate sheet",
    "current": "Current rates used as Proposed",
    "list": "List rates",
    "none": "not rated",
}


def _write_detail(ws, df: pd.DataFrame, mappings: Dict[str, ServiceMapping],
                  helper_for, zone_range: str,
                  grids: Optional[Dict[str, SheetGrid]] = None,
                  heavy_method: str = HEAVY_AUTO,
                  heavy_threshold: float = STANDARD_MAX_WEIGHT) -> dict:
    """Write the per-shipment tab, every cost cell a live formula."""
    for j, h in enumerate(DETAIL_HEADERS, start=1):
        ws.cell(row=1, column=j, value=h)
    style_header_row(ws, 1, 1, len(DETAIL_HEADERS))
    ws.freeze_panes = "C2"

    def get(row, key):
        return row.get(COL[key]) if COL[key] in df.columns else None

    records = []
    r = 2
    for i, (_, row) in enumerate(df.iterrows(), start=1):
        product = str(get(row, "product") or "").strip()
        pkg = str(get(row, "package_type") or "").strip()
        weight = pd.to_numeric(get(row, "rated_weight"), errors="coerce")
        weight = float(weight) if pd.notna(weight) else 0.0
        zone_raw = get(row, "zone")
        zone_num = row.get("Zone (Numeric)")

        w_ref = f"${get_column_letter(DCOL['Lookup Weight'])}{r}"
        z_ref = f"${get_column_letter(DCOL['Zone (Numeric)'])}{r}"

        m = mappings.get(product) or ServiceMapping(product=product)
        cur_plan = plan_rate(m.current_block, m.current_heavy, pkg, weight,
                             heavy_method, heavy_threshold)
        pro_plan = plan_rate(m.proposed_block, m.proposed_heavy, pkg, weight,
                             heavy_method, heavy_threshold)
        cur_f = formula_for(cur_plan, helper_for, w_ref, z_ref)
        pro_f = formula_for(pro_plan, helper_for, w_ref, z_ref)
        cur_method, pro_method = cur_plan.note, pro_plan.note

        zf = float(zone_num) if pd.notna(zone_num) else None
        cur_val = evaluate(cur_plan, grids, weight, zf) if grids else None
        pro_val = evaluate(pro_plan, grids, weight, zf) if grids else None

        ws.cell(row=r, column=DCOL["ID"], value=i)
        ws.cell(row=r, column=DCOL["Tracking Number"],
                value=str(get(row, "tracking") or ""))
        ws.cell(row=r, column=DCOL["Product Name"], value=product)
        ws.cell(row=r, column=DCOL["Package Type"], value=pkg)
        ws.cell(row=r, column=DCOL["Pay Type"],
                value=str(get(row, "pay_type") or ""))
        ws.cell(row=r, column=DCOL["Pieces"], value=_f(get(row, "pieces"), 1))
        ws.cell(row=r, column=DCOL["Shipments"],
                value=_f(get(row, "shipments"), 1))
        ws.cell(row=r, column=DCOL["Rated Weight (Lbs)"], value=weight)
        ws.cell(row=r, column=DCOL["Zone"],
                value=zone_raw if zone_raw is not None else "")
        ws.cell(row=r, column=DCOL["Zone (Numeric)"],
                value=float(zone_num) if pd.notna(zone_num) else None)

        # Lookup Weight stays a formula so the rounding rule is visible.
        ws.cell(row=r, column=DCOL["Lookup Weight"],
                value=F.lookup_weight(
                    f"${get_column_letter(DCOL['Rated Weight (Lbs)'])}{r}"))

        c1 = ws.cell(row=r, column=DCOL["Current Cost"],
                     value=F.wrap_iferror(cur_f) if cur_f else None)
        c2 = ws.cell(row=r, column=DCOL["Proposed Cost"],
                     value=F.wrap_iferror(pro_f) if pro_f else None)
        c1.number_format = FMT_MONEY_2DP
        c2.number_format = FMT_MONEY_2DP

        imp = ws.cell(
            row=r, column=DCOL["Impact"],
            value=f"=IFERROR({get_column_letter(DCOL['Proposed Cost'])}{r}"
                  f"-{get_column_letter(DCOL['Current Cost'])}{r},\"\")")
        imp.number_format = FMT_MONEY_2DP

        ws.cell(row=r, column=DCOL["Current Method"], value=cur_method)
        ws.cell(row=r, column=DCOL["Proposed Method"], value=pro_method)
        ws.cell(row=r, column=DCOL["Proposed Rate Source"],
                value=PROPOSED_SOURCE_LABELS.get(m.proposed_source,
                                                 m.proposed_source))

        records.append({
            "ID": i, "Product Name": product, "Package Type": pkg,
            "OpCo": str(get(row, "opco") or "").strip(),
            "Rated Weight (Lbs)": weight, "Zone": zone_num, "Row": r,
            "Current Method": cur_method, "Proposed Method": pro_method,
            "Proposed Rate Source": m.proposed_source,
            "Heavyweight": weight > heavy_threshold,
            "Rated": bool(cur_f and pro_f),
            "Shipments": _f(get(row, "shipments"), 1),
            "Current Cost": cur_val,
            "Proposed Cost": pro_val,
        })
        r += 1

    autosize(ws, {1: 6, 2: 18, 3: 20, 4: 20, 5: 18, 6: 8, 7: 10, 8: 16,
                  9: 8, 10: 13, 11: 14, 12: 14, 13: 14, 14: 12, 15: 34,
                  16: 34, 17: 28})
    ws.auto_filter.ref = f"A1:{get_column_letter(len(DETAIL_HEADERS))}{r - 1}"

    return {
        "sheet": ws.title,
        "first_row": 2,
        "last_row": max(r - 1, 2),
        "frame": pd.DataFrame(records),
    }


def _f(value, default=0.0) -> float:
    v = pd.to_numeric(value, errors="coerce")
    return float(v) if pd.notna(v) else float(default)


# --------------------------------------------------------------------------
def _write_shipment_data(ws, df: pd.DataFrame) -> None:
    cols = list(df.columns)
    for j, c in enumerate(cols, start=1):
        ws.cell(row=1, column=j, value=str(c))
    style_header_row(ws, 1, 1, len(cols))
    for i, (_, row) in enumerate(df.iterrows(), start=2):
        for j, c in enumerate(cols, start=1):
            v = row[c]
            if pd.isna(v):
                continue
            ws.cell(row=i, column=j,
                    value=v.to_pydatetime() if isinstance(v, pd.Timestamp) else v)
    ws.freeze_panes = "A2"
    autosize(ws, {j: 16 for j in range(1, len(cols) + 1)})
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{len(df) + 1}"


# --------------------------------------------------------------------------
def summary_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """
    The Summary tab's service table, as a DataFrame.

    Built from the same rated detail the workbook's SUMIFS formulas roll up, so
    the on-screen Summary and the downloaded one show the same figures.
    """
    if frame is None or frame.empty:
        return pd.DataFrame()

    present = list(frame["Product Name"].dropna().unique())
    ordered = [s for s in SUMMARY_SERVICE_ORDER if s in present]
    ordered += [s for s in sorted(present) if s not in ordered]

    rows = []
    for svc in ordered:
        g = frame[frame["Product Name"] == svc]
        cur = g["Current Cost"].sum(min_count=1)
        pro = g["Proposed Cost"].sum(min_count=1)
        cur = 0.0 if pd.isna(cur) else float(cur)
        pro = 0.0 if pd.isna(pro) else float(pro)
        rows.append({
            "Service": svc,
            "Shipments": float(g["Shipments"].sum()),
            "Rated Wt": float(g["Rated Weight (Lbs)"].sum()),
            "Current Cost": cur,
            "Proposed Cost": pro,
            "Impact": pro - cur,
            "Impact %": (pro - cur) / cur if cur else 0.0,
        })

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    total = {
        "Service": "Total",
        "Shipments": out["Shipments"].sum(),
        "Rated Wt": out["Rated Wt"].sum(),
        "Current Cost": out["Current Cost"].sum(),
        "Proposed Cost": out["Proposed Cost"].sum(),
        "Impact": out["Impact"].sum(),
    }
    total["Impact %"] = (total["Impact"] / total["Current Cost"]
                         if total["Current Cost"] else 0.0)
    return pd.concat([out, pd.DataFrame([total])], ignore_index=True)


def opco_cost_totals(frame: pd.DataFrame) -> Dict[str, Tuple[float, float]]:
    """
    Current / Proposed cost summed by OpCo, from the already-rated detail
    frame — used to auto-fill a Surcharge Analysis step's Transportation
    cost when it is appended onto this workbook, so fuel is assessed on the
    real net rate cost without the analyst re-typing it.
    """
    if frame is None or frame.empty or "OpCo" not in frame.columns:
        return {}
    out: Dict[str, Tuple[float, float]] = {}
    for opco, g in frame.groupby("OpCo"):
        opco = str(opco).strip()
        if not opco:
            continue
        cur = g["Current Cost"].sum(min_count=1)
        pro = g["Proposed Cost"].sum(min_count=1)
        out[opco] = (0.0 if pd.isna(cur) else float(cur),
                    0.0 if pd.isna(pro) else float(pro))
    return out


def _write_summary(ws, detail: dict, report: CleanseReport,
                   mappings: Dict[str, ServiceMapping],
                   config: RateComparisonConfig, date_range: str) -> int:
    """Procedure steps 5-10: pivot, summary table, notes, disclaimer, formats."""
    frame: pd.DataFrame = detail["frame"]
    dsheet = detail["sheet"]
    first, last = detail["first_row"], detail["last_row"]

    ws["B1"] = "Rate Comparison Summary"
    ws["B1"].font = TITLE_FONT

    r = 3
    if date_range:
        ws.cell(row=r, column=2,
                value=f"Shipment data date range: {date_range}").font = BOLD
        r += 1
    if config.cht_id:
        ws.cell(row=r, column=2,
                value=f"CHT / Group ID: {config.cht_id}").font = BOLD
        r += 1
    r += 1

    r = write_notes_block(ws, r, "Notes:", report.note_lines())

    extra_notes = list(config.analysis_notes)

    if not frame.empty and "Heavyweight" in frame.columns:
        n_heavy = int(frame["Heavyweight"].sum())
        if n_heavy:
            extra_notes.append(
                f"{n_heavy:,} shipments over {config.heavy_threshold:g} lbs "
                f"rated as heavyweight — "
                f"{HEAVY_METHOD_LABELS.get(config.heavy_method, config.heavy_method)}")
            if config.write_per_pound_rows:
                extra_notes.append(
                    'Per-pound rates are the "AS" row inserted immediately '
                    "below the 150 lb row on each rate sheet tab "
                    "(= 150 lb rate ÷ 150), as per the procedure.")

    for m in mappings.values():
        if m.proposed_missing and m.note:
            extra_notes.append(f"{m.product}: {m.note}")

    frame.attrs["notes"] = list(report.note_lines())
    frame.attrs["assumptions"] = list(extra_notes)
    frame.attrs["date_range"] = date_range
    frame.attrs["cht_id"] = config.cht_id

    if extra_notes:
        r = write_notes_block(ws, r, "Assumptions & adjustments:", extra_notes)

    # ---- service table ---------------------------------------------------
    ws.cell(row=r, column=2, value="*** ESTIMATED Net Rate Cost ***").font = BOLD
    r += 1
    header_row = r
    headers = ["Service", "Shipments", "Rated Wt", "Current Cost",
               "Proposed Cost", "Impact", "Impact %"]
    for j, h in enumerate(headers):
        ws.cell(row=header_row, column=2 + j, value=h)
    style_header_row(ws, header_row, 2, 2 + len(headers) - 1)

    services_present = list(frame["Product Name"].dropna().unique()) \
        if not frame.empty else []
    ordered = [s for s in SUMMARY_SERVICE_ORDER if s in services_present]
    ordered += [s for s in sorted(services_present) if s not in ordered]

    body_first = header_row + 1
    r = body_first
    ship_col = get_column_letter(DCOL["Shipments"])
    wt_col = get_column_letter(DCOL["Rated Weight (Lbs)"])
    cur_col = get_column_letter(DCOL["Current Cost"])
    pro_col = get_column_letter(DCOL["Proposed Cost"])
    key_col = get_column_letter(DCOL["Product Name"])

    for svc in ordered:
        key_ref = f"$B{r}"
        ws.cell(row=r, column=2, value=svc)
        ws.cell(row=r, column=3,
                value=F.sumifs(dsheet, ship_col, key_col, key_ref, first, last)
                ).number_format = FMT_INT
        ws.cell(row=r, column=4,
                value=F.sumifs(dsheet, wt_col, key_col, key_ref, first, last)
                ).number_format = FMT_INT
        ws.cell(row=r, column=5,
                value=F.sumifs(dsheet, cur_col, key_col, key_ref, first, last)
                ).number_format = FMT_MONEY
        ws.cell(row=r, column=6,
                value=F.sumifs(dsheet, pro_col, key_col, key_ref, first, last)
                ).number_format = FMT_MONEY
        ws.cell(row=r, column=7, value=f"=F{r}-E{r}").number_format = FMT_MONEY
        ws.cell(row=r, column=8,
                value=f"=IFERROR(G{r}/E{r},0)").number_format = FMT_PCT_1DP
        for c in range(2, 9):
            ws.cell(row=r, column=c).border = BOX
        r += 1

    body_last = r - 1
    total_row = r
    ws.cell(row=total_row, column=2, value="Total")
    for col in ("C", "D", "E", "F", "G"):
        cell = ws.cell(row=total_row, column=ord(col) - 64,
                       value=f"=SUM({col}{body_first}:{col}{body_last})")
        cell.number_format = FMT_INT if col in ("C", "D") else FMT_MONEY
    ws.cell(row=total_row, column=8,
            value=f"=IFERROR(G{total_row}/E{total_row},0)"
            ).number_format = FMT_PCT_1DP
    mark_total_row(ws, total_row, 2, 8)

    r = total_row + 2

    if config.fuel_express is not None or config.fuel_ground is not None:
        ws.cell(row=r, column=2,
                value="Fuel surcharge (applied to net rate cost)").font = BOLD
        r += 1
        ws.cell(row=r, column=2, value="Express fuel rate")
        ws.cell(row=r, column=3,
                value=config.fuel_express or 0.0).number_format = FMT_PCT_1DP
        r += 1
        ws.cell(row=r, column=2, value="Ground fuel rate")
        ws.cell(row=r, column=3,
                value=config.fuel_ground or 0.0).number_format = FMT_PCT_1DP
        r += 2

    autosize(ws, {2: 30, 3: 12, 4: 14, 5: 16, 6: 16, 7: 14, 8: 11})
    return r
    ws.sheet_view.showGridLines = False
