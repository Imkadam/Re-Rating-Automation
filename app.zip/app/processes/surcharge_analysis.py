"""
Process 3 - Surcharge Analysis

Turns a refreshed Surcharge Pricing Template into the reported surcharge
summary: occurrences and cost per surcharge at the current and proposed
discounts, the fuel calculation, and the total cost impact.

Every figure in the output workbook is a live Excel formula over the detail
tab, so an analyst can change a list rate or a discount in the file and watch
the summary move - the same way the app's own editor behaves.

Output tabs
-----------
Summary            notes, fuel table, surcharge summary, totals, disclaimer
Surcharge Detail   every surcharge row, with the rate and spend formulas
Rules              fuel rates and discounts, fuel applicability per surcharge
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from io import BytesIO
from typing import Dict, List, Optional, Tuple

import pandas as pd
from openpyxl.utils import get_column_letter

from core import surcharge as S
from core.config import FMT_INT, FMT_MONEY, FMT_MONEY_2DP, FMT_PCT_1DP
from core.excel_writer import (
    BOLD,
    BOX,
    HELPER_FILL,
    TITLE_FONT,
    TOTAL_FILL,
    autosize,
    mark_total_row,
    new_workbook,
    style_header_row,
    write_disclaimer,
    write_notes_block,
)

PROCESS_NAME = "Surcharge Analysis"

DETAIL_SHEET = "Surcharge Detail"
# Named "Surcharge Rules" (rather than the plain "Rules" DIM Change & MBW
# uses) so the two can share one workbook when Surcharge Analysis is
# appended onto that process's output.
RULES_SHEET = "Surcharge Rules"


# ==========================================================================
@dataclass
class FuelSetting:
    opco: str
    rate: float = 0.0
    discount_current: float = 0.0
    discount_proposed: float = 0.0


@dataclass
class SurchargeConfig:
    analysis_notes: List[str] = field(default_factory=list)
    date_range: str = ""
    cht_id: str = ""
    category: str = "Category 1"

    group_unchanged: bool = True
    include_fuel: bool = True
    fuel: Dict[str, FuelSetting] = field(default_factory=dict)

    # Net rate (transportation) cost per OpCo, when the request also covers a
    # rate comparison or DIM change. Fuel is assessed on transportation plus
    # the fuel-applicable surcharges, so it needs this base.
    transport_current: Dict[str, float] = field(default_factory=dict)
    transport_proposed: Dict[str, float] = field(default_factory=dict)

    annualise: bool = False
    months_covered: Optional[int] = None
    annual_multiplier: Optional[float] = None

    excludes: List[str] = field(default_factory=list)
    surcharge_excludes: List[str] = field(default_factory=list)


# ==========================================================================
DETAIL_HEADERS = [
    "OpCo", "Category", "Surcharge", "Zone", "List rate",
    "Current discount", "Proposed discount",
    "Current net rate", "Proposed net rate", "Occurrences",
    "Current cost", "Proposed cost", "Impact",
    "Fuel applies", "Priced",
]
D = {h: i + 1 for i, h in enumerate(DETAIL_HEADERS)}


def _write_detail(ws, df: pd.DataFrame) -> dict:
    """One row per surcharge, with the template's arithmetic as formulas."""
    for j, h in enumerate(DETAIL_HEADERS, start=1):
        ws.cell(row=1, column=j, value=h)
    style_header_row(ws, 1, 1, len(DETAIL_HEADERS))
    ws.freeze_panes = "D2"

    def L(name: str) -> str:
        return get_column_letter(D[name])

    r = 2
    for _, row in df.iterrows():
        priced = bool(row.get("Priced", True))
        ws.cell(row=r, column=D["OpCo"], value=row["OpCo"])
        ws.cell(row=r, column=D["Category"], value=row.get("Category", ""))
        ws.cell(row=r, column=D["Surcharge"], value=row["Surcharge"])
        ws.cell(row=r, column=D["Zone"], value=row.get("Zone", ""))
        ws.cell(row=r, column=D["List rate"],
                value=_f(row["List"])).number_format = FMT_MONEY_2DP
        ws.cell(row=r, column=D["Current discount"],
                value=_f(row["Discount 1"]) or 0).number_format = FMT_PCT_1DP
        ws.cell(row=r, column=D["Proposed discount"],
                value=_f(row["Discount 2"]) or 0).number_format = FMT_PCT_1DP
        ws.cell(row=r, column=D["Occurrences"],
                value=_f(row["Occurrences"]) or 0).number_format = FMT_INT

        # ROUND(List x (1 - Discount), 2) - the template's own formula
        for disc, out in (("Current discount", "Current net rate"),
                          ("Proposed discount", "Proposed net rate")):
            ws.cell(row=r, column=D[out],
                    value=f"=IFERROR(ROUND(${L('List rate')}{r}"
                          f"*(1-${L(disc)}{r}),2),\"\")"
                    ).number_format = FMT_MONEY_2DP

        # Net rate x occurrences, blank where the template cannot price it
        for rate, out in (("Current net rate", "Current cost"),
                          ("Proposed net rate", "Proposed cost")):
            ws.cell(
                row=r, column=D[out],
                value=(f"=IFERROR(${L(rate)}{r}*${L('Occurrences')}{r},\"\")"
                       if priced else None)
            ).number_format = FMT_MONEY_2DP

        # Blank - not zero - where the template cannot price the surcharge,
        # so an unpriced line never reads as "no impact".
        ws.cell(
            row=r, column=D["Impact"],
            value=(f"=IFERROR(${L('Proposed cost')}{r}"
                   f"-${L('Current cost')}{r},\"\")" if priced else None)
        ).number_format = FMT_MONEY_2DP
        ws.cell(row=r, column=D["Fuel applies"],
                value="Y" if row.get("Fuel applies") else "N")
        ws.cell(row=r, column=D["Priced"], value="Y" if priced else "N")
        r += 1

    autosize(ws, {D["OpCo"]: 12, D["Category"]: 28, D["Surcharge"]: 40,
                  D["Zone"]: 12, D["List rate"]: 12,
                  D["Current discount"]: 16, D["Proposed discount"]: 17,
                  D["Current net rate"]: 15, D["Proposed net rate"]: 16,
                  D["Occurrences"]: 13, D["Current cost"]: 14,
                  D["Proposed cost"]: 14, D["Impact"]: 13,
                  D["Fuel applies"]: 12, D["Priced"]: 9})
    ws.auto_filter.ref = f"A1:{get_column_letter(len(DETAIL_HEADERS))}{r - 1}"
    return {"sheet": ws.title, "first": 2, "last": max(r - 1, 2)}


def _f(v) -> Optional[float]:
    x = pd.to_numeric(v, errors="coerce")
    return float(x) if pd.notna(x) else None


def _num_or_formula(v):
    """Transportation cost cells accept either a flat number (the manual
    case) or an Excel formula string (auto-filled from the paired Rate
    Comparison / DIM Change workbook) — pass either straight through."""
    if isinstance(v, str) and v.startswith("="):
        return v
    return float(v or 0.0)


# ==========================================================================
def _write_rules(ws, config: SurchargeConfig, opcos: List[str]) -> dict:
    ws["B1"] = "Fuel rates & rules"
    ws["B1"].font = TITLE_FONT
    ws["B2"] = ("Change a fuel rate or discount here and the Summary "
                "recalculates.")
    ws["B2"].font = BOLD

    for j, h in enumerate(["OpCo", "Fuel rate", "Current discount",
                           "Proposed discount"]):
        ws.cell(row=4, column=2 + j, value=h)
    style_header_row(ws, 4, 2, 5)

    rows: Dict[str, int] = {}
    r = 5
    for opco in opcos:
        fs = config.fuel.get(opco, FuelSetting(opco))
        rows[opco] = r
        ws.cell(row=r, column=2, value=opco)
        ws.cell(row=r, column=3, value=float(fs.rate)).number_format = FMT_PCT_1DP
        ws.cell(row=r, column=4,
                value=float(fs.discount_current)).number_format = FMT_PCT_1DP
        ws.cell(row=r, column=5,
                value=float(fs.discount_proposed)).number_format = FMT_PCT_1DP
        for c in range(2, 6):
            ws.cell(row=r, column=c).border = BOX
        r += 1

    r += 1
    ws.cell(row=r, column=2, value="Transportation (net rate) cost").font = BOLD
    ws.cell(row=r + 1, column=2,
            value="Fuel is assessed on transportation plus the "
                  "fuel-applicable surcharges.").font = BOLD
    head = r + 2
    for j, h in enumerate(["OpCo", "Current", "Proposed"]):
        ws.cell(row=head, column=2 + j, value=h)
    style_header_row(ws, head, 2, 4)

    trans: Dict[str, int] = {}
    r = head + 1
    for opco in opcos:
        trans[opco] = r
        ws.cell(row=r, column=2, value=opco)
        ws.cell(row=r, column=3,
                value=_num_or_formula(config.transport_current.get(opco, 0.0))
                ).number_format = FMT_MONEY_2DP
        ws.cell(row=r, column=4,
                value=_num_or_formula(config.transport_proposed.get(opco, 0.0))
                ).number_format = FMT_MONEY_2DP
        for c in (2, 3, 4):
            ws.cell(row=r, column=c).fill = HELPER_FILL
            ws.cell(row=r, column=c).border = BOX
        r += 1

    autosize(ws, {2: 22, 3: 18, 4: 18, 5: 18})
    ws.sheet_view.showGridLines = False
    return {"fuel": rows, "transport": trans}


def _detected_opcos(data: pd.DataFrame) -> List[str]:
    opcos = [o for o in ["Express", "Ground", "Ground Economy",
                         "Express Freight", "FDX"]
             if o in set(data["OpCo"])]
    opcos += [o for o in sorted(set(data["OpCo"])) if o not in opcos and o]
    return opcos


def _match_transport(opcos: List[str],
                     parent_totals: Dict[str, Tuple[float, float]],
                     side: int) -> Dict[str, float]:
    """Match this template's OpCo names against the paired analysis's OpCo
    totals (exact match, else a case-insensitive substring match — e.g. the
    shipment data's "Ground" against the template's "Ground Economy" would
    NOT match since neither contains the other as a full word boundary isn't
    checked, so prefer exact names where they can be arranged to agree)."""
    out: Dict[str, float] = {}
    for opco in opcos:
        v = parent_totals.get(opco)
        if v is None:
            lo = opco.lower()
            for k, val in parent_totals.items():
                if lo in k.lower() or k.lower() in lo:
                    v = val
                    break
        if v is not None:
            out[opco] = v[side]
    return out


# ==========================================================================
def run(df: pd.DataFrame, config: SurchargeConfig
        ) -> Tuple[BytesIO, pd.DataFrame]:
    """Build the standalone surcharge workbook. `df` is the edited surcharge
    table."""
    wb = new_workbook()
    summary_ws = wb.create_sheet("Summary")
    _, reported = build_into(wb, summary_ws, 1, df, config, standalone=True)

    wb.move_sheet("Summary", offset=-wb.sheetnames.index("Summary"))
    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf, reported


def build_into(wb, summary_ws, start_row: int, df: pd.DataFrame,
               config: SurchargeConfig,
               parent_totals: Optional[Dict[str, Tuple[float, float]]] = None,
               standalone: bool = False) -> Tuple[int, pd.DataFrame]:
    """
    Write the Surcharge Detail + Surcharge Rules tabs into an existing
    workbook, and the surcharge Summary section directly onto `summary_ws`
    starting at `start_row` — so it can be appended after a Rate Comparison
    or DIM Change & MBW analysis's own Summary content, in the same workbook.

    `parent_totals`, when given, is the paired analysis's Current/Proposed
    cost by OpCo (see ``rate_comparison.opco_cost_totals``) — used to
    auto-fill the Transportation cost the fuel calculation is assessed on,
    whenever the caller hasn't already set it explicitly.

    Returns ``(next_free_row, reported)`` — the row below everything just
    written, and the surcharge summary table for the on-screen preview.
    """
    data = S.add_fuel_flag(S.recalculate(df))
    detail_ws = wb.create_sheet(DETAIL_SHEET)
    rules_ws = wb.create_sheet(RULES_SHEET)

    detail = _write_detail(detail_ws, data)
    opcos = _detected_opcos(data)

    if parent_totals and not config.transport_current \
            and not config.transport_proposed:
        config = replace(
            config,
            transport_current=_match_transport(opcos, parent_totals, 0),
            transport_proposed=_match_transport(opcos, parent_totals, 1))

    refs = _write_rules(rules_ws, config, opcos)
    return _write_summary(summary_ws, data, detail, refs, config, opcos,
                          start_row=start_row, standalone=standalone)


# --------------------------------------------------------------------------
def _write_summary(ws, data: pd.DataFrame, detail: dict, refs: dict,
                   config: SurchargeConfig, opcos: List[str],
                   start_row: int = 1, standalone: bool = True
                   ) -> Tuple[int, pd.DataFrame]:
    dsheet = detail["sheet"]
    first, last = detail["first"], detail["last"]

    def dcol(name: str) -> str:
        return get_column_letter(D[name])

    def sumifs(value: str, *criteria) -> str:
        parts = [f"'{dsheet}'!${dcol(value)}${first}:${dcol(value)}${last}"]
        for col, crit in criteria:
            parts.append(f"'{dsheet}'!${dcol(col)}${first}:${dcol(col)}${last}")
            parts.append(crit)
        return "=SUMIFS(" + ",".join(parts) + ")"

    if standalone:
        ws["B1"] = "Surcharge Analysis"
        ws["B1"].font = TITLE_FONT
        r = 3
    else:
        ws.cell(row=start_row, column=2, value="Surcharge Analysis").font = \
            TITLE_FONT
        r = start_row + 2

    if standalone:
        if config.date_range:
            ws.cell(row=r, column=2,
                    value=f"Based on US Domestic shipment characteristics "
                          f"{config.date_range}").font = BOLD
            r += 1
        if config.cht_id:
            ws.cell(row=r, column=2,
                    value=f"CHT / Group ID: {config.cht_id}").font = BOLD
            r += 1
    r += 1

    notes = ["Focus: review of surcharges",
             "Only surcharges with discounts and occurrences are shown "
             "individually"]
    if not config.include_fuel:
        notes.append("Fuel is NOT included in these calculations")
    notes += list(config.analysis_notes)
    r = write_notes_block(ws, r, "Notes:", notes)

    if config.excludes:
        r = write_notes_block(ws, r, "Excludes:", config.excludes)
    if config.surcharge_excludes:
        r = write_notes_block(ws, r, "Surcharges exclude:",
                              config.surcharge_excludes)

    # ---- fuel table ------------------------------------------------------
    if config.include_fuel:
        ws.cell(row=r, column=2, value="Fuel applied").font = BOLD
        r += 1
        for j, h in enumerate(["OpCo", "Fuel rate", "Current discount",
                               "Proposed discount"]):
            ws.cell(row=r, column=2 + j, value=h)
        style_header_row(ws, r, 2, 5)
        r += 1
        for opco in opcos:
            fr = refs["fuel"].get(opco)
            if fr is None:
                continue
            ws.cell(row=r, column=2, value=opco)
            for j, c in enumerate("CDE"):
                ws.cell(row=r, column=3 + j,
                        value=f"={RULES_SHEET}!{c}{fr}"
                        ).number_format = FMT_PCT_1DP
            for c in range(2, 6):
                ws.cell(row=r, column=c).border = BOX
            r += 1
        r += 1

    # ---- surcharge table -------------------------------------------------
    ws.cell(row=r, column=2,
            value="*** ESTIMATED Surcharges ***").font = BOLD
    r += 1
    band = r
    ws.cell(row=band, column=5, value="Current")
    ws.cell(row=band, column=7, value="Proposed")
    ws.cell(row=band, column=9, value="Impact")
    ws.merge_cells(start_row=band, start_column=5, end_row=band, end_column=6)
    ws.merge_cells(start_row=band, start_column=7, end_row=band, end_column=8)
    style_header_row(ws, band, 2, 9)

    head = band + 1
    for j, h in enumerate(["OpCo / Surcharge", "Occurrences", "List cost",
                           "Discount", "Cost", "Discount", "Cost", "Cost"]):
        ws.cell(row=head, column=2 + j, value=h)
    style_header_row(ws, head, 2, 9)

    reported = S.summary_rows(data, config.group_unchanged)
    opco_rows: Dict[str, int] = {}
    r = head + 1

    for opco in opcos:
        part = reported[reported["OpCo"] == opco]
        if part.empty:
            continue
        opco_rows[opco] = r
        ws.cell(row=r, column=2, value=opco).font = BOLD
        for c in range(2, 10):
            ws.cell(row=r, column=c).fill = TOTAL_FILL
            ws.cell(row=r, column=c).border = BOX
        subtotal_row = r
        r += 1
        first_item = r

        for _, item in part.iterrows():
            name = item["Surcharge"]
            ws.cell(row=r, column=2, value=f"    {name}")
            if name == S.GROUPED_LABEL:
                # a roll-up of everything with no discount change
                ws.cell(row=r, column=3,
                        value=_f(item["Occurrences"]) or 0
                        ).number_format = FMT_INT
                ws.cell(row=r, column=4, value="various")
                ws.cell(row=r, column=6,
                        value=_f(item["Net Spend 1"]) or 0
                        ).number_format = FMT_MONEY
                ws.cell(row=r, column=8,
                        value=_f(item["Net Spend 2"]) or 0
                        ).number_format = FMT_MONEY
            else:
                crit = f'"{name}"'
                oc = f'"{opco}"'
                ws.cell(row=r, column=3,
                        value=sumifs("Occurrences", ("Surcharge", crit),
                                     ("OpCo", oc))).number_format = FMT_INT
                lst = item["List"]
                ws.cell(row=r, column=4,
                        value=lst if isinstance(lst, str)
                        else _f(lst)).number_format = FMT_MONEY_2DP
                ws.cell(row=r, column=5,
                        value=_f(item["Discount 1"]) or 0
                        ).number_format = FMT_PCT_1DP
                ws.cell(row=r, column=6,
                        value=sumifs("Current cost", ("Surcharge", crit),
                                     ("OpCo", oc))).number_format = FMT_MONEY
                ws.cell(row=r, column=7,
                        value=_f(item["Discount 2"]) or 0
                        ).number_format = FMT_PCT_1DP
                ws.cell(row=r, column=8,
                        value=sumifs("Proposed cost", ("Surcharge", crit),
                                     ("OpCo", oc))).number_format = FMT_MONEY
            ws.cell(row=r, column=9,
                    value=f"=H{r}-F{r}").number_format = FMT_MONEY
            for c in range(2, 10):
                ws.cell(row=r, column=c).border = BOX
            r += 1

        last_item = r - 1
        for col in ("C", "F", "H", "I"):
            ws.cell(row=subtotal_row, column=ord(col) - 64,
                    value=f"=SUM({col}{first_item}:{col}{last_item})"
                    ).number_format = (FMT_INT if col == "C" else FMT_MONEY)
        mark_total_row(ws, subtotal_row, 2, 9)

    total_row = r
    ws.cell(row=total_row, column=2, value="Total")
    sub = list(opco_rows.values())
    for col in ("C", "F", "H", "I"):
        refs_list = ",".join(f"{col}{x}" for x in sub) or "0"
        ws.cell(row=total_row, column=ord(col) - 64,
                value=f"=SUM({refs_list})"
                ).number_format = (FMT_INT if col == "C" else FMT_MONEY)
    mark_total_row(ws, total_row, 2, 9)
    ws.cell(row=total_row + 1, column=9,
            value=f"=IFERROR(I{total_row}/F{total_row},0)"
            ).number_format = FMT_PCT_1DP
    ws.cell(row=total_row + 1, column=9).font = BOLD

    r = total_row + 3

    # ---- all cost components --------------------------------------------
    if config.include_fuel:
        r = _write_totals(ws, r, data, detail, refs, config, opcos,
                          opco_rows, total_row, sumifs, dcol)

    end_row = write_disclaimer(ws, r + 1) if standalone else r + 1
    autosize(ws, {2: 38, 3: 13, 4: 12, 5: 11, 6: 15, 7: 11, 8: 15, 9: 14})
    ws.sheet_view.showGridLines = False
    return end_row, reported


def _write_totals(ws, r: int, data: pd.DataFrame, detail: dict, refs: dict,
                  config: SurchargeConfig, opcos: List[str],
                  opco_rows: Dict[str, int], surcharge_total_row: int,
                  sumifs, dcol) -> int:
    """Transportation + surcharges + fuel = total all cost components."""
    ws.cell(row=r, column=2,
            value="*** ESTIMATED Total Cost Components ***").font = BOLD
    r += 1
    head = r
    for j, h in enumerate(["Component", "Current", "Proposed", "Impact"]):
        ws.cell(row=head, column=2 + j, value=h)
    style_header_row(ws, head, 2, 5)
    r += 1

    first_component = r
    trans_rows: Dict[str, int] = {}
    for opco in opcos:
        tr = refs["transport"].get(opco)
        if tr is None:
            continue
        trans_rows[opco] = r
        ws.cell(row=r, column=2, value=f"Transportation - {opco}")
        ws.cell(row=r, column=3,
                value=f"={RULES_SHEET}!C{tr}").number_format = FMT_MONEY
        ws.cell(row=r, column=4,
                value=f"={RULES_SHEET}!D{tr}").number_format = FMT_MONEY
        ws.cell(row=r, column=5, value=f"=D{r}-C{r}").number_format = FMT_MONEY
        for c in range(2, 6):
            ws.cell(row=r, column=c).border = BOX
        r += 1

    sur_rows: Dict[str, int] = {}
    for opco, src in opco_rows.items():
        sur_rows[opco] = r
        ws.cell(row=r, column=2, value=f"Surcharges - {opco}")
        ws.cell(row=r, column=3, value=f"=F{src}").number_format = FMT_MONEY
        ws.cell(row=r, column=4, value=f"=H{src}").number_format = FMT_MONEY
        ws.cell(row=r, column=5, value=f"=D{r}-C{r}").number_format = FMT_MONEY
        for c in range(2, 6):
            ws.cell(row=r, column=c).border = BOX
        r += 1

    # ---- fuel -------------------------------------------------------------
    # (transportation + fuel-applicable surcharges) x (1 - discount) x rate
    fuel_row = r
    ws.cell(row=r, column=2, value="Fuel").font = BOLD
    for side, col, disc_col in (("Current cost", 3, "D"),
                                ("Proposed cost", 4, "E")):
        terms = []
        for opco in opcos:
            fr = refs["fuel"].get(opco)
            if fr is None:
                continue
            base = []
            tr = trans_rows.get(opco)
            if tr is not None:
                base.append(f"{get_column_letter(col)}{tr}")
            base.append(sumifs(side, ("OpCo", f'"{opco}"'),
                               ("Fuel applies", '"Y"'))[1:])
            terms.append(
                f"(({'+'.join(base)})*(1-{RULES_SHEET}!{disc_col}{fr})"
                f"*{RULES_SHEET}!C{fr})")
        ws.cell(row=r, column=col,
                value="=" + ("+".join(terms) if terms else "0")
                ).number_format = FMT_MONEY
    ws.cell(row=r, column=5, value=f"=D{r}-C{r}").number_format = FMT_MONEY
    for c in range(2, 6):
        ws.cell(row=r, column=c).border = BOX
    r += 1

    total = r
    ws.cell(row=total, column=2, value="Total all cost components")
    for col in ("C", "D", "E"):
        ws.cell(row=total, column=ord(col) - 64,
                value=f"=SUM({col}{first_component}:{col}{fuel_row})"
                ).number_format = FMT_MONEY
    mark_total_row(ws, total, 2, 5)
    ws.cell(row=total + 1, column=5,
            value=f"=IFERROR(E{total}/C{total},0)").number_format = FMT_PCT_1DP
    ws.cell(row=total + 1, column=5).font = BOLD
    r = total + 2

    if config.annualise:
        mult = config.annual_multiplier
        if mult is None and config.months_covered:
            mult = 12 / config.months_covered
        mult = mult or 1.0
        r += 1
        ws.cell(row=r, column=2,
                value=f"Total all cost components (annualised x{mult:g})"
                ).font = BOLD
        for col in ("C", "D", "E"):
            ws.cell(row=r, column=ord(col) - 64,
                    value=f"={col}{total}*{mult:g}").number_format = FMT_MONEY
        mark_total_row(ws, r, 2, 5)
        ws.cell(row=r + 1, column=5,
                value=f"=IFERROR(E{r}/C{r},0)").number_format = FMT_PCT_1DP
        r += 2

    return r + 1


# ==========================================================================
def preview_totals(df: pd.DataFrame, config: SurchargeConfig) -> pd.DataFrame:
    """The Total Cost Components table, computed in Python for the screen."""
    data = S.add_fuel_flag(S.recalculate(df))
    rows = []
    fuel_c = fuel_p = 0.0
    for opco in sorted(set(data["OpCo"])):
        if not opco:
            continue
        part = data[data["OpCo"] == opco]
        c = pd.to_numeric(part["Net Spend 1"], errors="coerce").sum()
        p = pd.to_numeric(part["Net Spend 2"], errors="coerce").sum()
        tc = float(config.transport_current.get(opco, 0.0))
        tp = float(config.transport_proposed.get(opco, 0.0))
        if tc or tp:
            rows.append({"Component": f"Transportation - {opco}",
                         "Current": tc, "Proposed": tp, "Impact": tp - tc})
        rows.append({"Component": f"Surcharges - {opco}",
                     "Current": c, "Proposed": p, "Impact": p - c})

        if config.include_fuel:
            fs = config.fuel.get(opco)
            if fs:
                fp = part[part["Fuel applies"].astype(bool)]
                fc_base = pd.to_numeric(fp["Net Spend 1"],
                                        errors="coerce").sum()
                fp_base = pd.to_numeric(fp["Net Spend 2"],
                                        errors="coerce").sum()
                fuel_c += S.fuel_cost(tc, fc_base, fs.rate,
                                      fs.discount_current)
                fuel_p += S.fuel_cost(tp, fp_base, fs.rate,
                                      fs.discount_proposed)

    if config.include_fuel:
        rows.append({"Component": "Fuel", "Current": fuel_c,
                     "Proposed": fuel_p, "Impact": fuel_p - fuel_c})

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    total = {"Component": "Total all cost components",
             "Current": out["Current"].sum(),
             "Proposed": out["Proposed"].sum(),
             "Impact": out["Impact"].sum()}
    out = pd.concat([out, pd.DataFrame([total])], ignore_index=True)

    if config.annualise:
        mult = config.annual_multiplier
        if mult is None and config.months_covered:
            mult = 12 / config.months_covered
        mult = mult or 1.0
        out = pd.concat([out, pd.DataFrame([{
            "Component": f"Total all cost components (annualised ×{mult:g})",
            "Current": total["Current"] * mult,
            "Proposed": total["Proposed"] * mult,
            "Impact": total["Impact"] * mult,
        }])], ignore_index=True)
    return out
