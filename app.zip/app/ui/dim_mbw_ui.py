"""Streamlit UI for the DIM Change & MBW process."""

from __future__ import annotations

from typing import Dict, List

import pandas as pd
import streamlit as st

from core import dim as D
from core.config import COL, DISCLAIMER
from core.ratesheet import RateBlock
from core.shipment import (
    CleanseOptions,
    default_excluded_products,
    list_sheets as excel_sheet_names,
    load_shipment_data,
)
from processes import dim_mbw as dm
from processes import rate_comparison as rc
from ui import theme
from ui.surcharge_ui import SurchargeStep

STATE = "dm"
SURCHARGE_NS = "dm_sc"


def _s(key: str, default=None):
    # Double underscore keeps stored values out of the widget-key
    # namespace (widgets use "<state>_<name>"), because Streamlit
    # refuses a write to a key a widget already owns.
    return st.session_state.get(f"{STATE}__{key}", default)


def _set(key: str, value) -> None:
    st.session_state[f"{STATE}__{key}"] = value


# --------------------------------------------------------------------------
def render() -> None:
    theme.masthead(
        "DIM Change & MBW",
        "Recalculate rated weights under a new DIM factor, apply the minimum "
        "billable weight rules, and re-rate both sides.",
    )

    t1, t2, t3, t4, t5 = st.tabs([
        "1 · Inputs", "2 · DIM factors", "3 · MBW rules", "4 · Surcharges",
        "5 · Build",
    ])
    with t1:
        _inputs()
    with t2:
        _factors()
    with t3:
        _rules()
    with t4:
        _surcharges()
    with t5:
        _build()


# --------------------------------------------------------------------------
def _inputs() -> None:
    theme.section("Shipment data", "must carry Length, Width and Height")

    f = st.file_uploader("Shipment Detail extract (.xlsx / .xlsm)",
                         type=["xlsx", "xlsm"], key="dm_ship_file")
    if f is not None:
        sheets = excel_sheet_names(f)
        idx = sheets.index("Shipment Data") if "Shipment Data" in sheets else 0
        sheet = st.selectbox("Worksheet holding the shipment rows", sheets,
                             index=idx, key="dm_ship_sheet")
        if st.button("Load shipment data", type="primary"):
            with st.spinner("Reading shipment data…"):
                df = load_shipment_data(f, sheet)
            _set("df", df)
            _set("excluded", default_excluded_products(df))
            _set("mappings", None)
            st.success(f"Loaded {len(df):,} rows × {len(df.columns)} columns.")

    df = _s("df")
    if df is not None:
        dims_present = 0
        if all(COL[k] in df.columns for k in ("length", "width", "height")):
            dims_present = int(
                df[[COL["length"], COL["width"], COL["height"]]]
                .notna().all(axis=1).sum())
        c1, c2, c3 = st.columns(3)
        c1.metric("Rows", f"{len(df):,}")
        c2.metric("With dimensions", f"{dims_present:,}")
        c3.metric("Without", f"{len(df) - dims_present:,}")
        if dims_present == 0:
            st.error(
                "No rows carry Length / Width / Height — a DIM analysis needs "
                "dimensions. Check the extract."
            )
        elif dims_present < len(df):
            theme.note(
                "Rows without dimensions keep their existing rated weight, "
                "rounded up — procedure: <i>“If in case the Dimension column is "
                "present as NA … replace the value with the actual rated "
                "weight by rounding it up.”</i>"
            )
        st.dataframe(df.head(15), use_container_width=True, height=220)

    theme.section("Net rate sheets")
    theme.note(
        "A pure DIM change re-rates both sides on the <b>same</b> rate sheet — "
        "only the weight moves. Upload a Proposed sheet as well only when the "
        "rates are changing too."
    )
    c1, c2 = st.columns(2)
    with c1:
        cur = st.file_uploader("Current Net Rate Sheet",
                               type=["xlsx", "xlsm"], key="dm_cur_file")
        cur_sheets = _sheet_picker(cur, "cur")
    with c2:
        pro = st.file_uploader("Proposed Net Rate Sheet (optional)",
                               type=["xlsx", "xlsm"], key="dm_pro_file")
        pro_sheets = _sheet_picker(pro, "pro")
    same = st.checkbox("Use the Current rate sheet for both sides", value=True,
                       disabled=pro is not None,
                       help="Untick and upload a Proposed sheet when the rates "
                            "change as well as the DIM factor.")

    theme.section("Cleansing")
    products = sorted(df[COL["product"]].astype(str).str.strip().unique()) \
        if df is not None and COL["product"] in df.columns else []
    excluded = st.multiselect("Product Names to exclude", products,
                              default=_s("excluded", []), key="dm_excluded")
    cc1, cc2 = st.columns(2)
    with cc1:
        zero = st.checkbox("USD List Freight Charge is $0 or blank", True,
                           key="dm_zero")
        zones = st.checkbox("Non-US Domestic zones (51, 00)", True, key="dm_z")
    with cc2:
        origin = st.checkbox("Origin Region is not US", True, key="dm_o")
        dest = st.checkbox("Destination Region is not US", True, key="dm_d")
    _set("opts", CleanseOptions(
        excluded_products=excluded, drop_zero_freight=zero,
        drop_non_us_zones=zones, drop_multi_piece=False,
        drop_non_us_origin=origin, drop_non_us_dest=dest,
        drop_over_150=False))

    if st.button("Parse rate sheets", disabled=cur is None):
        with st.spinner("Detecting rate tables…"):
            cur_wb, cur_blocks = rc.load_ratesheet_blocks(cur, cur_sheets)
            if pro is not None and not same:
                pro_wb, pro_blocks = rc.load_ratesheet_blocks(pro, pro_sheets)
            else:
                pro_wb, pro_blocks = cur_wb, cur_blocks
        for k, v in (("cur_wb", cur_wb), ("cur_blocks", cur_blocks),
                     ("pro_wb", pro_wb), ("pro_blocks", pro_blocks),
                     ("same_sheet", pro is None or same),
                     ("mappings", None)):
            _set(k, v)
        st.success(
            f"Detected {len(cur_blocks)} rate tables"
            + ("  ·  the same sheet rates both sides."
               if (pro is None or same) else
               f"  ·  {len(pro_blocks)} on the Proposed sheet."))

    if _s("cur_blocks"):
        with st.expander(f"Rate tables detected ({len(_s('cur_blocks'))})"):
            st.dataframe(pd.DataFrame([
                {"Service": b.service, "Billing type": b.billing_type,
                 "Table": "per-lb / range" if b.is_per_pound else "standard",
                 "Header row": b.header_row}
                for b in _s("cur_blocks")]), use_container_width=True)


def _sheet_picker(file, key: str):
    if file is None:
        return None
    try:
        names = excel_sheet_names(file)
    except Exception:
        return None
    if len(names) <= 1:
        return names
    return st.multiselect("Worksheets to scan", names, default=names,
                          key=f"dm_{key}_sheets") or names


# --------------------------------------------------------------------------
def _factors() -> None:
    df = _s("df")
    if df is None:
        st.info("Load the shipment data on the **Inputs** tab first.")
        return

    theme.section("DIM factors", "procedure — DIM Change Analysis")
    theme.rule(
        "New DIM Volume = <b>L × W × H</b> where L = MAX, W = MEDIAN, "
        "H = MIN of the three dimensions.<br>"
        "Current DIM Weight = Volume ÷ current factor &nbsp;·&nbsp; "
        "Proposed DIM Weight = Volume ÷ proposed factor<br>"
        "Rated Weight = <b>ROUNDUP(MAX(actual weight, DIM weight))</b>, then "
        "floored at the MBW where one applies."
    )

    opcos = sorted(df[COL["opco"]].astype(str).str.strip().unique()) \
        if COL["opco"] in df.columns else []

    existing = None
    if COL["dim_divisor"] in df.columns:
        vals = pd.to_numeric(df[COL["dim_divisor"]], errors="coerce")
        vals = vals[vals > 1]
        if not vals.empty:
            existing = float(vals.mode().iloc[0])
            st.caption(
                f"The extract's own DIM Divisor column is mostly "
                f"**{existing:g}** — shown for reference; the factors below "
                "are what the analysis uses."
            )

    c1, c2 = st.columns(2)
    with c1:
        dcur = st.number_input("Default current DIM factor", 1.0, 1000.0,
                               float(existing or 139.0), 1.0, key="dm_dcur")
    with c2:
        dpro = st.number_input("Default proposed DIM factor", 1.0, 1000.0,
                               175.0, 1.0, key="dm_dpro")

    cur_map: Dict[str, float] = {}
    pro_map: Dict[str, float] = {}
    if opcos:
        st.markdown("**Per-OpCo override**")
        for opco in opcos:
            o1, o2, o3 = st.columns([2, 1, 1])
            o1.markdown(f"<div style='padding-top:.55rem'>{opco}</div>",
                        unsafe_allow_html=True)
            cur_map[opco] = o2.number_input(
                f"Current — {opco}", 1.0, 1000.0, float(dcur), 1.0,
                key=f"dm_c_{opco}", label_visibility="collapsed")
            pro_map[opco] = o3.number_input(
                f"Proposed — {opco}", 1.0, 1000.0, float(dpro), 1.0,
                key=f"dm_p_{opco}", label_visibility="collapsed")

    _set("dcur", dcur)
    _set("dpro", dpro)
    _set("cur_map", cur_map)
    _set("pro_map", pro_map)

    if abs(dcur - dpro) < 1e-9 and not any(
            abs(cur_map.get(o, dcur) - pro_map.get(o, dpro)) > 1e-9
            for o in opcos):
        st.warning(
            "Current and proposed DIM factors are identical — every weight "
            "impact will be zero."
        )


# --------------------------------------------------------------------------
def _rules() -> None:
    theme.section("Minimum Billable Weight",
                  "procedure — mandatory when a DIM factor changes")
    theme.rule(
        "“When a shipment qualifies for certain surcharges, the MBW rule "
        "activates … the shipment's weight is bumped up to a minimum "
        "chargeable limit if existing calculated weights are less than MBW.”"
        "<br>Where more than one applies, <b>the surcharge with the highest "
        "amount wins</b> — so the rules are tested in descending net-rate "
        "order, not a fixed order."
    )

    apply_mbw = st.checkbox("Apply MBW logic", True, key="dm_apply_mbw")
    _set("apply_mbw", apply_mbw)
    if not apply_mbw:
        st.warning(
            "MBW is a mandatory step for a DIM change request — leave this on "
            "unless you are deliberately isolating the DIM effect."
        )

    rules: List[D.MBWRule] = []
    for base in D.default_rules():
        with st.expander(
            f"**{base.code}** — {base.label}   ·   MBW {base.mbw:g} lbs",
            expanded=False,
        ):
            c1, c2, c3 = st.columns(3)
            mbw = c1.number_input("MBW (lbs)", 0.0, 1000.0, float(base.mbw),
                                  1.0, key=f"dm_mbw_{base.code}")
            listr = c2.number_input("List rate ($)", 0.0, 100000.0,
                                    float(base.list_rate), 0.5,
                                    key=f"dm_lr_{base.code}")
            disc = c3.number_input("Discount %", 0.0, 100.0,
                                   float(base.discount * 100), 1.0,
                                   key=f"dm_ds_{base.code}")
            st.caption(f"Net rate ${listr * (1 - disc / 100):,.2f} — decides "
                       "which surcharge wins when several apply.")

            t = st.columns(5)
            def _th(i, label, value, key):
                if value is None:
                    t[i].markdown(
                        f"<div style='color:#6B6675;font-size:.78rem;"
                        f"padding-top:.4rem'>{label}<br><b>n/a</b></div>",
                        unsafe_allow_html=True)
                    return None
                return t[i].number_input(label, 0.0, 1e7, float(value), 1.0,
                                         key=key)

            ml = _th(0, "Longest side (in)", base.max_length,
                     f"dm_l_{base.code}")
            ms = _th(1, "2nd longest (in)", base.max_second,
                     f"dm_s_{base.code}")
            mg = _th(2, "L + girth (in)", base.max_length_girth,
                     f"dm_g_{base.code}")
            mv = _th(3, "Cubic volume (in³)", base.max_volume,
                     f"dm_v_{base.code}")
            mw = _th(4, "Actual weight (lbs)", base.max_weight,
                     f"dm_w_{base.code}")

            products = base.products
            if base.products:
                products = st.multiselect(
                    "Applies only to these products", D.UA_PRODUCTS,
                    default=base.products, key=f"dm_pr_{base.code}")

            rules.append(D.MBWRule(
                code=base.code, label=base.label, mbw=mbw, list_rate=listr,
                discount=disc / 100, max_length=ml, max_second=ms,
                max_length_girth=mg, max_volume=mv, max_weight=mw,
                products=products))

    _set("rules", rules)

    order = D.by_cost(rules)
    st.markdown("**Test order** (highest net rate first)")
    st.dataframe(pd.DataFrame([
        {"#": i + 1, "Code": r.code, "Surcharge": r.label,
         "MBW (lbs)": f"{r.mbw:g}", "Net rate": f"${r.net_rate:,.2f}",
         "Applies to": ", ".join(r.products) if r.products else "all products"}
        for i, r in enumerate(order)]),
        use_container_width=True, hide_index=True)


# --------------------------------------------------------------------------
def _surcharges() -> None:
    theme.section(
        "Surcharge Analysis",
        "optional — append it onto this same workbook, post DIM change")
    theme.note(
        "Read a Surcharge Pricing Template here and it is added as its own "
        "Detail / Rules tabs, with its summary folded straight into this "
        "workbook's <b>Summary</b> tab, right after the weight/cost impact "
        "table — one file, one number for both."
    )

    include = st.checkbox(
        "Include surcharge analysis in this workbook", value=_s("sc_on", False),
        key="dm_sc_on")
    _set("sc_on", include)
    if not include:
        return

    step = SurchargeStep(SURCHARGE_NS)
    st1, st2, st3 = st.tabs(
        ["Template", "Surcharges", "Fuel & totals"])
    with st1:
        step.render_template()
    with st2:
        step.render_editor()
    with st3:
        detail = _s("detail")
        if detail is None:
            st.caption(
                "Build the DIM change once (on the **Build** tab) and come "
                "back here — the transportation cost below will pre-fill "
                "from that result."
            )
        prefill = rc.opco_cost_totals(detail) if detail is not None else None
        step.render_fuel(parent_totals=prefill)


def _surcharge_inputs():
    """The surcharge df/config for the Build step, if the step is enabled
    and has a template loaded."""
    if not _s("sc_on"):
        return None, None
    step = SurchargeStep(SURCHARGE_NS)
    data = step.current()
    if data is None:
        return None, None
    step.render_build_details(standalone=False)
    return step.apply_fuel_flags(data), step.config()


# --------------------------------------------------------------------------
def _build() -> None:
    df = _s("df")
    if df is None or not _s("cur_blocks"):
        st.info("Complete the **Inputs** tab first.")
        return

    theme.section("Summary tab details")
    c1, c2 = st.columns(2)
    with c1:
        cht = st.text_input("CHT / Group ID", value=_group_id(df), key="dm_cht")
    with c2:
        date_range = st.text_input(
            "Date range (blank = derive from the data)", "", key="dm_dr")

    notes = st.text_area(
        "Additional notes / assumptions (one per line)",
        "Focus: impact analysis for the proposed DIM factor\n"
        "Limited to US Domestic services\n"
        "All shipments rated at Single Piece OB rates",
        key="dm_notes")
    include_data = st.checkbox("Include the cleansed Shipment Data tab", True,
                               key="dm_incl")

    surcharge_df, surcharge_cfg = _surcharge_inputs()
    if surcharge_df is not None:
        theme.note(
            "Surcharge Analysis will be appended onto this workbook — see the "
            "**Surcharges** tab to change the template or its settings."
        )

    if st.button("Build workbook", type="primary", key="dm_build"):
        cfg = dm.DimConfig(
            cleanse=_s("opts") or CleanseOptions(),
            current_divisors=_s("cur_map") or {},
            proposed_divisors=_s("pro_map") or {},
            default_current_divisor=float(_s("dcur", 139.0)),
            default_proposed_divisor=float(_s("dpro", 175.0)),
            rules=_s("rules") or D.default_rules(),
            apply_mbw=bool(_s("apply_mbw", True)),
            analysis_notes=[n for n in notes.splitlines() if n.strip()],
            date_range=date_range.strip(),
            cht_id=cht.strip(),
            include_shipment_data=include_data,
            same_ratesheet=bool(_s("same_sheet", True)),
        )
        with st.spinner("Recalculating weights and writing formulas…"):
            buf, report, detail, surcharge_reported = dm.run(
                df, _s("cur_wb"), _s("cur_blocks"),
                _s("pro_wb"), _s("pro_blocks"), cfg,
                surcharge_df, surcharge_cfg)
        _set("output", buf.getvalue())
        _set("detail", detail)
        _set("surcharge_reported", surcharge_reported)
        msg = f"Processed {report.final_rows:,} shipments."
        if surcharge_reported is not None:
            msg += f" Surcharge Analysis appended ({len(surcharge_reported)} lines)."
        st.success(msg)

    out = _s("output")
    if not out:
        return
    detail = _s("detail")

    if detail is not None and not detail.empty:
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Shipments", f"{len(detail):,}")
        m2.metric("With dimensions", f"{int(detail['Has DIM'].sum()):,}")
        m3.metric("MBW applied", f"{int((detail['Surcharge'] != '').sum()):,}")
        wt = detail["Proposed Rated Weight"].sum() - \
            detail["Current Rated Weight"].sum()
        m4.metric("Weight impact", f"{wt:,.0f} lbs")

        sc = detail[detail["Surcharge"] != ""]
        if not sc.empty:
            theme.section("Minimum billable weight applied")
            st.dataframe(
                sc.groupby("Surcharge").agg(
                    Shipments=("ID", "count"),
                    MBW=("MBW (lbs)", "max")).reset_index(),
                use_container_width=True, hide_index=True)

        _summary_preview(detail)

    surcharge_reported = _s("surcharge_reported")
    if surcharge_reported is not None and not surcharge_reported.empty:
        theme.section(
            "Surcharge summary",
            "folded into the same Summary tab, right after the table above")
        SurchargeStep(SURCHARGE_NS).render_summary()

    st.download_button(
        "⬇  Download DIM change workbook", data=out,
        file_name="DIM Change Analysis.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        key="dm_dl")
    st.caption(
        "The DIM factors, MBW values and every Service Guide threshold live on "
        "the **Rules** tab — change one there and the whole workbook "
        "recalculates in Excel."
    )


def _money(v) -> str:
    if v is None or pd.isna(v):
        return "—"
    return f"-${abs(v):,.0f}" if v < 0 else f"${v:,.0f}"


def _summary_preview(detail: pd.DataFrame) -> None:
    sf = dm.summary_frame(detail)
    if sf.empty:
        return
    theme.section("Summary tab", "exactly what the workbook's Summary shows")

    total = sf.iloc[-1]
    k1, k2, k3 = st.columns(3)
    k1.metric("Current cost", _money(total["Current Cost"]))
    k2.metric("Proposed cost", _money(total["Proposed Cost"]))
    cost_pct = (total["Cost Impact"] / total["Current Cost"]
                if total["Current Cost"] else 0)
    k3.metric("Cost impact", _money(total["Cost Impact"]),
              delta=f"{cost_pct:.1%}", delta_color="inverse")

    body = sf.copy()
    for c in ("Shipments", "Current Rated Wt", "Proposed Rated Wt",
              "Weight Impact"):
        body[c] = body[c].map(lambda v: f"{v:,.0f}")
    for c in ("Current Cost", "Proposed Cost", "Cost Impact"):
        body[c] = body[c].map(_money)

    def _bold_total(row):
        last = row.name == len(body) - 1
        return ["font-weight:700;background-color:#EFE7F7" if last else ""
                for _ in row]

    st.dataframe(body.style.apply(_bold_total, axis=1),
                 use_container_width=True, hide_index=True)

    notes = list(detail.attrs.get("notes", []))
    assumptions = list(detail.attrs.get("assumptions", []))
    if notes or assumptions:
        with st.expander("Notes, assumptions & disclaimer"):
            for title, items in (("Notes:", notes),
                                 ("Assumptions & adjustments:", assumptions)):
                if items:
                    st.markdown(f"**{title}**")
                    for n in items:
                        st.markdown(f"- {n}")
            st.markdown("**Disclaimer:**")
            st.caption(DISCLAIMER)


def _group_id(df: pd.DataFrame) -> str:
    col = COL["payer_group_id"]
    if col in df.columns:
        vals = df[col].dropna().unique()
        if len(vals):
            v = vals[0]
            return str(int(v)) if isinstance(v, float) and v.is_integer() else str(v)
    return ""
