"""Streamlit UI for the Rate Comparison process."""

from __future__ import annotations

from typing import Dict, List

import pandas as pd
import streamlit as st

from core.config import (
    COL,
    DISCLAIMER,
    LIST_FALLBACK_BLANK,
    LIST_FALLBACK_CURRENT,
    LIST_FALLBACK_LABELS,
    MISSING_EXCLUDE,
    MISSING_LEAVE_BLANK,
    MISSING_LIST_RATES,
    MISSING_STRATEGY_LABELS,
    MISSING_USE_CURRENT,
)
from core.ratesheet import RateBlock
from core.shipment import (
    CleanseOptions,
    default_excluded_products,
    list_sheets as excel_sheet_names,
    load_shipment_data,
)
from processes import rate_comparison as rc
from ui import theme
from ui.surcharge_ui import SurchargeStep

STATE = "rc"
SURCHARGE_NS = "rc_sc"


def _s(key: str, default=None):
    # Double underscore keeps stored values out of the widget-key
    # namespace (widgets use "<state>_<name>"), because Streamlit
    # refuses a write to a key a widget already owns.
    return st.session_state.get(f"{STATE}__{key}", default)


def _set(key: str, value) -> None:
    st.session_state[f"{STATE}__{key}"] = value


# --------------------------------------------------------------------------
def render() -> None:
    theme.masthead(
        "Rate Comparison",
        "Cleanse the shipment data, rate every shipment against the Current "
        "and Proposed Net Rate Sheets, and build the Summary tab.",
    )

    t1, t2, t3, t4, t5, t6 = st.tabs([
        "1 · Inputs", "2 · Cleanse", "3 · Rate sheet mapping",
        "4 · Missing rates", "5 · Surcharges", "6 · Build",
    ])
    with t1:
        _inputs()
    with t2:
        _cleanse()
    with t3:
        _mapping()
    with t4:
        _missing()
    with t5:
        _surcharges()
    with t6:
        _build()


# --------------------------------------------------------------------------
def _inputs() -> None:
    theme.section("Shipment data", "from the Shipment Detail Template")

    ship_file = st.file_uploader(
        "Shipment Detail extract (.xlsx / .xlsm)",
        type=["xlsx", "xlsm"], key="rc_ship_file",
    )
    if ship_file is not None:
        sheets = excel_sheet_names(ship_file)
        idx = sheets.index("Shipment Data") if "Shipment Data" in sheets else 0
        sheet = st.selectbox("Worksheet holding the shipment rows", sheets,
                             index=idx, key="rc_ship_sheet")
        if st.button("Load shipment data", type="primary"):
            with st.spinner("Reading shipment data…"):
                df = load_shipment_data(ship_file, sheet)
            _set("df", df)
            _set("excluded", default_excluded_products(df))
            _set("mappings", None)
            st.success(f"Loaded {len(df):,} rows × {len(df.columns)} columns.")

    df = _s("df")
    if df is not None:
        c1, c2, c3 = st.columns(3)
        c1.metric("Rows", f"{len(df):,}")
        if COL["product"] in df.columns:
            c2.metric("Services", df[COL['product']].nunique())
        if COL["zone"] in df.columns:
            c3.metric("Zones", df[COL['zone']].nunique())
        st.dataframe(df.head(20), use_container_width=True, height=240)
        missing = [c for c in (COL["product"], COL["zone"],
                               COL["rated_weight"], COL["package_type"])
                   if c not in df.columns]
        if missing:
            st.error("Missing required columns: " + ", ".join(missing))

    theme.section("Net rate sheets", "raw FedEx ratesheet exports")
    c1, c2 = st.columns(2)
    with c1:
        cur_file = st.file_uploader("Current Net Rate Sheet",
                                    type=["xlsx", "xlsm"], key="rc_cur_file")
        cur_sheets = _sheet_picker(cur_file, "cur")
    with c2:
        pro_file = st.file_uploader("Proposed Net Rate Sheet",
                                    type=["xlsx", "xlsm"], key="rc_pro_file")
        pro_sheets = _sheet_picker(pro_file, "pro")

    with st.expander("Optional — List Rate Sheet", expanded=False):
        theme.rule(
            "Procedure, First Overnight: <i>“If the Current and Proposed Net "
            "Rate Sheets are from different years, use FO List Rates to rate "
            "the shipments.”</i> Upload the list rate sheet here to make that "
            "option available on the <b>Missing rates</b> tab."
        )
        list_file = st.file_uploader("List Rate Sheet",
                                     type=["xlsx", "xlsm"], key="rc_list_file")
        list_sheet_names = _sheet_picker(list_file, "list")

    if st.button("Parse rate sheets", disabled=not (cur_file and pro_file)):
        with st.spinner("Detecting rate tables…"):
            cur_wb, cur_blocks = rc.load_ratesheet_blocks(cur_file, cur_sheets)
            pro_wb, pro_blocks = rc.load_ratesheet_blocks(pro_file, pro_sheets)
            cur_info = rc.load_ratesheet_info(cur_wb, cur_sheets)
            pro_info = rc.load_ratesheet_info(pro_wb, pro_sheets)
            lst_wb = lst_blocks = None
            if list_file is not None:
                lst_wb, lst_blocks = rc.load_ratesheet_blocks(
                    list_file, list_sheet_names)
        for k, v in (("cur_wb", cur_wb), ("cur_blocks", cur_blocks),
                     ("pro_wb", pro_wb), ("pro_blocks", pro_blocks),
                     ("cur_info", cur_info), ("pro_info", pro_info),
                     ("lst_wb", lst_wb), ("lst_blocks", lst_blocks),
                     ("mappings", None), ("missing", None)):
            _set(k, v)
        st.success(
            f"Detected {len(cur_blocks)} Current and {len(pro_blocks)} "
            "Proposed rate tables."
            + (f" {len(lst_blocks)} List Rate tables."
               if lst_blocks else "")
        )

    _sheet_facts()

    for label, key in (("Current", "cur_blocks"), ("Proposed", "pro_blocks"),
                       ("List", "lst_blocks")):
        blocks = _s(key)
        if blocks:
            with st.expander(f"{label} rate tables detected ({len(blocks)})"):
                st.dataframe(_blocks_frame(blocks), use_container_width=True)


def _sheet_picker(file, key: str):
    """
    Which worksheets of a rate sheet workbook to scan.

    A raw FedEx export is usually one sheet, but a working file can hold
    several - so let the analyst narrow it rather than parsing everything.
    """
    if file is None:
        return None
    try:
        names = excel_sheet_names(file)
    except Exception:
        return None
    if len(names) <= 1:
        return names
    return st.multiselect(
        "Worksheets to scan", names, default=names, key=f"rc_{key}_sheets",
        help="Only these worksheets are searched for rate tables.",
    ) or names


def _sheet_facts() -> None:
    """Effective dates and any 'refer to list rates' notices."""
    cur_info, pro_info = _s("cur_info"), _s("pro_info")
    if not cur_info or not pro_info:
        return

    theme.section("Rate sheet details", "read off the sheets themselves")
    c1, c2 = st.columns(2)
    for col, label, info in ((c1, "Current", cur_info),
                             (c2, "Proposed", pro_info)):
        with col:
            eff = (info.effective_date.strftime("%d %b %Y")
                   if info.effective_date else "not stated")
            st.markdown(
                f'<div class="fx-card"><b>{label} rate sheet</b><br>'
                f'<span style="color:#6B6675;font-size:.84rem">'
                f'Customer: {info.customer or "—"}<br>'
                f'Effective: {eff}</span></div>',
                unsafe_allow_html=True,
            )

    cy, py = cur_info.effective_year, pro_info.effective_year
    if cy and py and cy == py:
        theme.rule(
            f"Both sheets are from <b>{cy}</b>. For a service missing from the "
            "Proposed sheet, the procedure says to use the <b>Current rates as "
            "the Proposed rates</b> — that is the default on the "
            "<b>Missing rates</b> tab."
        )
    elif cy and py:
        theme.rule(
            f"The sheets are from <b>different years</b> (Current {cy}, "
            f"Proposed {py}). For a service missing from the Proposed sheet, "
            "the procedure says to use <b>List Rates</b> — upload a list rate "
            "sheet on this tab to enable that option."
        )

    if pro_info.list_rate_services:
        st.info(
            "The Proposed rate sheet says *“Please refer to list rates for "
            "this service”* for: **"
            + ", ".join(pro_info.list_rate_services) + "**."
        )


def _index(blocks: List[RateBlock]):
    from core.ratesheet import index_blocks
    return index_blocks(blocks)


def _blocks_frame(blocks: List[RateBlock]) -> pd.DataFrame:
    return pd.DataFrame([
        {
            "Service": b.service,
            "Title": b.title,
            "Billing type": b.billing_type,
            "Table": "per-lb / range" if b.is_per_pound else "standard",
            "Header row": b.header_row,
            "Zones": ", ".join(str(int(z)) for z in sorted(b.zones)),
            "Sections": ", ".join(
                f"{k} {v.first_row}-{v.last_row}" for k, v in b.sections.items()
            ),
        }
        for b in blocks
    ])


# --------------------------------------------------------------------------
def _cleanse() -> None:
    df = _s("df")
    if df is None:
        st.info("Load the shipment data on the **Inputs** tab first.")
        return

    theme.section("Exclusion rules", "procedure step 2 — Cleanse Shipment Data")

    products = sorted(df[COL["product"]].astype(str).str.strip().unique()) \
        if COL["product"] in df.columns else []
    excluded = st.multiselect(
        "Product Names to exclude (services not under review)",
        products, default=_s("excluded", []), key="rc_excluded",
    )

    c1, c2 = st.columns(2)
    with c1:
        zero = st.checkbox("USD List Freight Charge is $0 or blank", True)
        zones = st.checkbox("Non-US Domestic zones (51, 00)", True)
        pieces = st.checkbox("Pieces greater than 1", True)
    with c2:
        origin = st.checkbox("Origin Region is not US", True)
        dest = st.checkbox("Destination Region is not US", True)
        heavy = st.checkbox(
            "Rated weight greater than 150 lbs", False,
            help="Leave off to rate heavyweight shipments with the "
                 "per-pound rules on the Build tab.")

    opts = CleanseOptions(
        excluded_products=excluded, drop_zero_freight=zero,
        drop_non_us_zones=zones, drop_multi_piece=pieces,
        drop_non_us_origin=origin, drop_non_us_dest=dest,
        drop_over_150=heavy,
    )
    _set("opts", opts)

    if st.button("Preview cleansing"):
        from core.shipment import cleanse
        clean, report = cleanse(df, opts)
        _set("preview_report", report)

    rep = _s("preview_report")
    if rep:
        c1, c2 = st.columns([1, 2])
        with c1:
            st.metric("Rows retained", f"{rep.final_rows:,}",
                      delta=f"-{rep.starting_rows - rep.final_rows:,}")
        with c2:
            st.dataframe(
                pd.DataFrame([{"Rule": k, "Rows removed": v}
                              for k, v in rep.removed.items()]),
                use_container_width=True, hide_index=True,
            )


# --------------------------------------------------------------------------
def _products() -> List[str]:
    df = _s("df")
    if df is None:
        return []
    products = sorted(df[COL["product"]].astype(str).str.strip().unique())
    opts = _s("opts")
    excluded = set(opts.excluded_products) if opts else set()
    return [p for p in products if p not in excluded]


def _ensure_mappings() -> Dict[str, rc.ServiceMapping]:
    if _s("mappings") is None:
        cur_info, pro_info = _s("cur_info"), _s("pro_info")
        _set("mappings", rc.build_default_mappings(
            _products(), _s("cur_blocks") or [], _s("pro_blocks") or [],
            _s("lst_blocks") or [],
            cur_info.effective_year if cur_info else None,
            pro_info.effective_year if pro_info else None,
        ))
    return _s("mappings")


def _mapping() -> None:
    if _s("df") is None or not _s("cur_blocks") or not _s("pro_blocks"):
        st.info("Load the shipment data and parse both rate sheets first.")
        return

    mappings = _ensure_mappings()
    theme.section("Which rate table rates each service?",
                  "auto-detected — override where the agreement differs")

    cur_blocks, pro_blocks = _s("cur_blocks"), _s("pro_blocks")
    cur_opts = ["— none —"] + [b.label for b in cur_blocks]
    pro_opts = ["— none —"] + [b.label for b in pro_blocks]
    cur_by = {b.label: b for b in cur_blocks}
    pro_by = {b.label: b for b in pro_blocks}

    for product in _products():
        m = mappings.get(product) or rc.ServiceMapping(product=product)
        if m.proposed_missing:
            head = f"**{product}**  ·  no Proposed table — see *Missing rates*"
        else:
            head = (f"**{product}**  ·  "
                    f"{m.current_block.label if m.current_block else 'no current table'}")
        with st.expander(head, expanded=m.current_block is None):
            c1, c2 = st.columns(2)
            with c1:
                cur = st.selectbox(
                    "Current — standard table", cur_opts,
                    index=cur_opts.index(m.current_block.label)
                    if m.current_block and m.current_block.label in cur_opts else 0,
                    key=f"rc_cur_{product}")
                curh = st.selectbox(
                    "Current — heavyweight / per-lb table", cur_opts,
                    index=cur_opts.index(m.current_heavy.label)
                    if m.current_heavy and m.current_heavy.label in cur_opts else 0,
                    key=f"rc_curh_{product}")
            with c2:
                pro = st.selectbox(
                    "Proposed — standard table", pro_opts,
                    index=pro_opts.index(m.proposed_block.label)
                    if m.proposed_block and m.proposed_block.label in pro_opts else 0,
                    key=f"rc_pro_{product}")
                proh = st.selectbox(
                    "Proposed — heavyweight / per-lb table", pro_opts,
                    index=pro_opts.index(m.proposed_heavy.label)
                    if m.proposed_heavy and m.proposed_heavy.label in pro_opts else 0,
                    key=f"rc_proh_{product}")

            picked_pro = pro_by.get(pro)
            mappings[product] = rc.ServiceMapping(
                product=product,
                current_block=cur_by.get(cur),
                proposed_block=picked_pro,
                current_heavy=cur_by.get(curh),
                proposed_heavy=pro_by.get(proh),
                proposed_missing=picked_pro is None,
                missing_strategy=m.missing_strategy,
            )
    _set("mappings", mappings)


# --------------------------------------------------------------------------
def _missing() -> None:
    """Services with no table on the Proposed rate sheet."""
    if _s("df") is None or not _s("cur_blocks") or not _s("pro_blocks"):
        st.info("Load the shipment data and parse both rate sheets first.")
        return

    mappings = _ensure_mappings()
    missing = [p for p, m in mappings.items() if m.proposed_missing]

    theme.section("Services missing from the Proposed rate sheet",
                  "procedure — First Overnight (FO) Shipments")
    theme.rule(
        "<i>“If Proposed Rates are unavailable and both Net Rate Sheets are "
        "from the same year, use the Current Rates as the Proposed Rates. "
        "If the Current and Proposed Net Rate Sheets are from different "
        "years, use FO List Rates to rate the shipments.”</i>"
    )

    if not missing:
        st.success(
            "Every service in the shipment data has a table on the Proposed "
            "rate sheet — nothing to decide here."
        )
        return

    cur_info, pro_info = _s("cur_info"), _s("pro_info")
    cy = cur_info.effective_year if cur_info else None
    py = pro_info.effective_year if pro_info else None
    have_list = bool(_s("lst_blocks"))

    if cy and py:
        same = cy == py
        theme.note(
            f"Current sheet <b>{cy}</b> · Proposed sheet <b>{py}</b> — "
            + ("<b>same year</b>, so the procedure points at "
               "<i>Current rates as Proposed</i>."
               if same else
               "<b>different years</b>, so the procedure points at "
               "<i>List Rates</i>.")
        )
    if not have_list:
        st.caption(
            "No List Rate Sheet uploaded — that option is disabled. Add one on "
            "the **Inputs** tab to enable it."
        )

    strategies: Dict[str, str] = dict(_s("missing") or {})
    list_for_current: Dict[str, bool] = dict(_s("missing_cur") or {})
    list_fallback: Dict[str, str] = dict(_s("missing_fb") or {})

    # bulk setter - handy when several services are missing at once
    if len(missing) > 1:
        b1, b2 = st.columns([3, 1])
        with b1:
            bulk = st.selectbox(
                "Set every service below to…",
                ["— leave as they are —", MISSING_USE_CURRENT,
                 MISSING_LIST_RATES, MISSING_EXCLUDE, MISSING_LEAVE_BLANK],
                format_func=lambda k: (k if k.startswith("—")
                                       else MISSING_STRATEGY_LABELS[k]),
                key="rc_missing_bulk",
            )
        with b2:
            st.markdown("<div style='height:1.75rem'></div>",
                        unsafe_allow_html=True)
            if st.button("Apply to all", use_container_width=True):
                if not bulk.startswith("—"):
                    for p in missing:
                        st.session_state.pop(f"rc_missing_{p}", None)
                        strategies[p] = bulk
                    _set("missing", strategies)
                    st.rerun()

    options = [MISSING_USE_CURRENT, MISSING_LIST_RATES,
               MISSING_EXCLUDE, MISSING_LEAVE_BLANK]

    for product in missing:
        m = mappings[product]
        default = strategies.get(product, m.missing_strategy
                                 or MISSING_LEAVE_BLANK)
        with st.container():
            st.markdown(
                f'<div class="fx-card"><b>{product}</b> — no table on the '
                f'Proposed rate sheet</div>', unsafe_allow_html=True)

            usable = [o for o in options
                      if not (o == MISSING_LIST_RATES and not have_list)
                      and not (o == MISSING_USE_CURRENT
                               and m.current_block is None)]
            if default not in usable:
                default = MISSING_LEAVE_BLANK

            choice = st.radio(
                f"How should {product} be rated?",
                usable,
                index=usable.index(default),
                format_func=lambda k: MISSING_STRATEGY_LABELS[k],
                key=f"rc_missing_{product}",
            )
            strategies[product] = choice

            if choice == MISSING_LIST_RATES:
                on_list = rc.pick_block(
                    _index(_s("lst_blocks") or []), product, False) is not None
                if on_list:
                    st.caption(
                        "✓ The List Rate Sheet has a table for this service.")
                else:
                    st.caption(
                        "⚠ The List Rate Sheet has **no** table for this "
                        "service — the fallback below decides what happens.")

                fb_options = [LIST_FALLBACK_CURRENT, LIST_FALLBACK_BLANK]
                if m.current_block is None:
                    fb_options = [LIST_FALLBACK_BLANK]
                fb_default = list_fallback.get(product, LIST_FALLBACK_CURRENT)
                if fb_default not in fb_options:
                    fb_default = fb_options[0]
                list_fallback[product] = st.selectbox(
                    "If the List Rate Sheet has no table for this service",
                    fb_options,
                    index=fb_options.index(fb_default),
                    format_func=lambda k: LIST_FALLBACK_LABELS[k],
                    key=f"rc_missing_fb_{product}",
                    help="A List Rate Sheet rarely covers every service, so "
                         "each product can fall back independently.",
                )
                list_for_current[product] = st.checkbox(
                    "Also rate the Current side from the List Rate Sheet",
                    value=list_for_current.get(product, False),
                    key=f"rc_missing_cur_{product}",
                    help="Use when neither sheet carries net rates for this "
                         "service and both sides should be on list rates.",
                    disabled=not on_list,
                )
            if choice == MISSING_USE_CURRENT:
                st.caption(
                    "Current and Proposed will be identical for this service, "
                    "so its impact will be $0. The substitution is recorded in "
                    "the Summary notes and in the *Proposed Rate Source* "
                    "column of the Rate Detail tab."
                )
            st.markdown("")

    _set("missing", strategies)
    _set("missing_cur", list_for_current)
    _set("missing_fb", list_fallback)


# --------------------------------------------------------------------------
def _surcharges() -> None:
    theme.section(
        "Surcharge Analysis",
        "optional — append it onto this same workbook, post rate comparison")
    theme.note(
        "Read a Surcharge Pricing Template here and it is added as its own "
        "Detail / Rules tabs, with its summary folded straight into this "
        "workbook's <b>Summary</b> tab, right after the rate impact table — "
        "one file, one number for both."
    )

    include = st.checkbox(
        "Include surcharge analysis in this workbook", value=_s("sc_on", False),
        key="rc_sc_on")
    _set("sc_on", include)
    if not include:
        return

    step = SurchargeStep(SURCHARGE_NS)
    st1, st2, st3 = st.tabs(
        ["Template", "Surcharges", "Fuel & totals"])
    with st1:
        step.render_template()
    with st2:
        step.render_editor()
    with st3:
        detail = _s("detail")
        if detail is None:
            st.caption(
                "Build the rate comparison once (on the **Build** tab) and "
                "come back here — the transportation cost below will "
                "pre-fill from that result."
            )
        prefill = rc.opco_cost_totals(detail) if detail is not None else None
        step.render_fuel(parent_totals=prefill)


def _surcharge_inputs():
    """The surcharge df/config for the Build step, if the step is enabled
    and has a template loaded."""
    if not _s("sc_on"):
        return None, None
    step = SurchargeStep(SURCHARGE_NS)
    data = step.current()
    if data is None:
        return None, None
    step.render_build_details(standalone=False)
    return step.apply_fuel_flags(data), step.config()


# --------------------------------------------------------------------------
def _build() -> None:
    if _s("df") is None or not _s("cur_blocks") or not _s("pro_blocks"):
        st.info("Complete the **Inputs** tab first.")
        return

    theme.section("Summary tab details")
    c1, c2 = st.columns(2)
    with c1:
        cht = st.text_input("CHT / Group ID", value=_default_group_id(_s("df")))
        date_range = st.text_input(
            "Shipment data date range (blank = derive from the data)", "")
    with c2:
        fuel_x = st.number_input("Express fuel rate %", 0.0, 100.0, 0.0, 0.25)
        fuel_g = st.number_input("Ground fuel rate %", 0.0, 100.0, 0.0, 0.25)

    theme.section("Heavyweight shipments", "procedure — packages over 150 lbs")
    theme.rule(
        "A per-pound row is inserted immediately below the 150 lb row on each "
        "rate sheet (<code>= 150 lb rate ÷ 150</code>, labelled <b>AS</b>), and "
        "<b>Shipment Rate = Per-Pound Rate × Rated Weight</b>. Express services "
        "with their own heavyweight table use an approximate match on rated "
        "weight and zone instead."
    )

    dropped = bool(_s("opts") and _s("opts").drop_over_150)
    if dropped:
        st.warning(
            "Heavyweight rows are currently **excluded** on the Cleanse tab. "
            "Untick *“Rated weight greater than 150 lbs”* there to rate them."
        )

    h1, h2 = st.columns([3, 2])
    with h1:
        heavy_method = st.radio(
            "Heavyweight rating method",
            [rc.HEAVY_AUTO, rc.HEAVY_TABLE, rc.HEAVY_PER_LB],
            format_func=lambda k: rc.HEAVY_METHOD_LABELS[k],
            disabled=dropped)
    with h2:
        threshold = st.number_input(
            "Heavyweight threshold (lbs)", 1.0, 5000.0, 150.0, 1.0,
            disabled=dropped)
        write_as = st.checkbox(
            'Insert the per-pound "AS" rows into the rate sheet tabs', True,
            disabled=dropped)

    theme.section("Output")
    notes = st.text_area(
        "Additional notes / assumptions (one per line)",
        "Shipments having rated weight >150 are excluded from this analysis"
        if dropped else "")
    include_data = st.checkbox("Include the cleansed Shipment Data tab", True)

    surcharge_df, surcharge_cfg = _surcharge_inputs()
    if surcharge_df is not None:
        theme.note(
            "Surcharge Analysis will be appended onto this workbook — see the "
            "**Surcharges** tab to change the template or its settings."
        )

    if st.button("Build workbook", type="primary"):
        cfg = rc.RateComparisonConfig(
            cleanse=_s("opts") or CleanseOptions(),
            mappings=_ensure_mappings(),
            analysis_notes=[n for n in notes.splitlines() if n.strip()],
            date_range=date_range.strip(),
            cht_id=cht.strip(),
            fuel_express=(fuel_x / 100) if fuel_x else None,
            fuel_ground=(fuel_g / 100) if fuel_g else None,
            include_shipment_data=include_data,
            heavy_method=heavy_method,
            heavy_threshold=float(threshold),
            write_per_pound_rows=bool(write_as),
            missing_proposed=_s("missing") or {},
            list_rates_for_current=_s("missing_cur") or {},
            list_fallback=_s("missing_fb") or {},
        )
        with st.spinner("Rating shipments and writing formulas…"):
            buf, report, detail, surcharge_reported = rc.run(
                _s("df"), _s("cur_wb"), _s("cur_blocks"),
                _s("pro_wb"), _s("pro_blocks"), cfg,
                _s("lst_wb"), _s("lst_blocks"),
                surcharge_df, surcharge_cfg,
            )
        _set("output", buf.getvalue())
        _set("report", report)
        _set("detail", detail)
        _set("surcharge_reported", surcharge_reported)
        msg = f"Rated {report.final_rows:,} shipments."
        if surcharge_reported is not None:
            msg += f" Surcharge Analysis appended ({len(surcharge_reported)} lines)."
        st.success(msg)

    out = _s("output")
    if not out:
        return

    detail = _s("detail")
    if detail is not None and not detail.empty:
        m1, m2, m3 = st.columns(3)
        m1.metric("Shipments rated", f"{int(detail['Rated'].sum()):,}")
        m2.metric("Heavyweight", f"{int(detail.get('Heavyweight', pd.Series(dtype=bool)).sum()):,}")
        m3.metric("Services", detail["Product Name"].nunique())

        unrated = int((~detail["Rated"]).sum())
        if unrated:
            st.warning(
                f"{unrated:,} shipments were left unrated on one side. Check "
                "the **Missing rates** and **Rate sheet mapping** tabs."
            )
        borrowed = detail[detail["Proposed Rate Source"].isin(
            ["current", "list"])]
        if not borrowed.empty:
            st.info(
                "Proposed rates were substituted for: "
                + ", ".join(
                    f"**{p}** ({rc.PROPOSED_SOURCE_LABELS[s]})"
                    for (p, s) in borrowed[["Product Name",
                                            "Proposed Rate Source"]]
                    .drop_duplicates().itertuples(index=False)
                )
            )
        st.dataframe(
            detail.groupby(["Product Name", "Current Method"])
                  .size().rename("Shipments").reset_index(),
            use_container_width=True, hide_index=True,
        )

    _summary_preview(detail)

    surcharge_reported = _s("surcharge_reported")
    if surcharge_reported is not None and not surcharge_reported.empty:
        theme.section(
            "Surcharge summary",
            "folded into the same Summary tab, right after the table above")
        SurchargeStep(SURCHARGE_NS).render_summary()

    st.download_button(
        "⬇  Download rate comparison workbook",
        data=out, file_name="Rate Comparison.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    st.caption(
        "Every Current Cost / Proposed Cost cell is a live VLOOKUP/MATCH "
        "against the embedded rate-sheet tabs — click any cell in Excel to "
        "verify it."
    )


# --------------------------------------------------------------------------
def _money(v) -> str:
    if v is None or pd.isna(v):
        return "—"
    return f"-${abs(v):,.0f}" if v < 0 else f"${v:,.0f}"


def _summary_preview(detail: pd.DataFrame) -> None:
    """The Summary tab, on screen, before the workbook is downloaded."""
    if detail is None or detail.empty:
        return
    sf = rc.summary_frame(detail)
    if sf.empty:
        return

    theme.section("Summary tab", "exactly what the workbook's Summary shows")

    meta = []
    if detail.attrs.get("date_range"):
        meta.append(f"Shipment data date range: <b>{detail.attrs['date_range']}</b>")
    if detail.attrs.get("cht_id"):
        meta.append(f"CHT / Group ID: <b>{detail.attrs['cht_id']}</b>")
    if meta:
        theme.note(" &nbsp;·&nbsp; ".join(meta))

    total = sf.iloc[-1]
    k1, k2, k3 = st.columns(3)
    k1.metric("Current cost", _money(total["Current Cost"]))
    k2.metric("Proposed cost", _money(total["Proposed Cost"]))
    k3.metric("Impact", _money(total["Impact"]),
              delta=f"{total['Impact %']:.1%}", delta_color="inverse")

    body = sf.copy()
    body["Shipments"] = body["Shipments"].map(lambda v: f"{v:,.0f}")
    body["Rated Wt"] = body["Rated Wt"].map(lambda v: f"{v:,.0f}")
    for c in ("Current Cost", "Proposed Cost", "Impact"):
        body[c] = body[c].map(_money)
    body["Impact %"] = sf["Impact %"].map(lambda v: f"{v:.1%}")

    def _bold_total(row):
        last = row.name == len(body) - 1
        return ["font-weight:700;background-color:#EFE7F7" if last else ""
                for _ in row]

    st.dataframe(body.style.apply(_bold_total, axis=1),
                 use_container_width=True, hide_index=True)

    notes = list(detail.attrs.get("notes", []))
    assumptions = list(detail.attrs.get("assumptions", []))
    if notes or assumptions:
        with st.expander("Notes, assumptions & disclaimer", expanded=False):
            if notes:
                st.markdown("**Notes:**")
                for n in notes:
                    st.markdown(f"- {n}")
            if assumptions:
                st.markdown("**Assumptions & adjustments:**")
                for n in assumptions:
                    st.markdown(f"- {n}")
            st.markdown("**Disclaimer:**")
            st.caption(DISCLAIMER)

    st.caption(
        "These figures come from the same rate-sheet cells the workbook's "
        "formulas point at, so the Summary tab in the download shows the same "
        "numbers once Excel recalculates."
    )


def _default_group_id(df: pd.DataFrame) -> str:
    col = COL["payer_group_id"]
    if df is not None and col in df.columns:
        vals = df[col].dropna().unique()
        if len(vals):
            v = vals[0]
            return str(int(v)) if isinstance(v, float) and v.is_integer() else str(v)
    return ""
