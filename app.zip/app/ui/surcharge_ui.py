"""
Streamlit UI for the Surcharge Analysis process.

``SurchargeStep`` is the reusable building block — a namespaced Template /
Surcharges / Fuel & totals sub-flow. Two instances (different ``ns``) keep
independent session state and widget keys, so the same flow can be embedded
inside Rate Comparison's and DIM Change & MBW's own tabs, letting those
processes append the surcharge workbook and fold its Summary section into
their own. ``render()`` below is the thin wrapper that turns it into the
standalone Surcharge Analysis process screen.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import openpyxl
import pandas as pd
import streamlit as st

from core import surcharge as S
from processes import surcharge_analysis as SA
from ui import theme

EDITABLE = ["List", "Discount 1 %", "Discount 2 %"]


class SurchargeStep:
    """A namespaced Template / Surcharges / Fuel sub-flow."""

    def __init__(self, ns: str):
        self.ns = ns

    def _s(self, key: str, default=None):
        return st.session_state.get(f"{self.ns}__{key}", default)

    def _set(self, key: str, value) -> None:
        st.session_state[f"{self.ns}__{key}"] = value

    def _k(self, name: str) -> str:
        return f"{self.ns}_{name}"

    # ----------------------------------------------------------------
    def has_data(self) -> bool:
        df = self._s("df")
        return df is not None and not df.empty

    # ----------------------------------------------------------------
    def render_template(self) -> None:
        theme.section("Surcharge Pricing Template",
                      "the Discount Comparison workbook, refreshed")

        f = st.file_uploader("Surcharge Pricing Template (.xlsm / .xlsx)",
                             type=["xlsm", "xlsx"], key=self._k("file"))
        if f is None:
            theme.note(
                "The template must have been <b>refreshed</b> against Teradata — "
                "an unrefreshed copy carries zero occurrences and zero discounts, "
                "and there is nothing to analyse."
            )
            return

        if st.button("Read template", type="primary", key=self._k("read")):
            with st.spinner("Reading surcharge data…"):
                wb = openpyxl.load_workbook(f, data_only=True)
                info = S.read_info(wb)
                cats = S.available_categories(wb)
            self._set("wb", wb)
            self._set("info", info)
            self._set("cats", cats)
            self._set("df", None)
            self._set("edits", None)
            st.success("Template read.")

        info = self._s("info")
        if info is None:
            return

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Period", info.period_label or "—")
        c2.metric("Months", info.months or "—")
        c3.metric("Shipments", f"{info.shipments:,}" if info.shipments else "—")
        c4.metric("Invoiced", f"${info.invoiced:,.0f}" if info.invoiced else "—")

        cats = self._s("cats", ["Category 1"])
        cat = st.selectbox(
            "Pricing Category", cats,
            index=0, key=self._k("cat"),
            help="Which pricing category to read. The account's own category is "
                 "normally Category 1.")

        if st.button("Load surcharges", key=self._k("load")):
            with st.spinner("Parsing…"):
                df = S.parse(self._s("wb"), cat)
                df = S.with_occurrences(df)
            self._set("df", df)
            self._set("edits", None)
            self._set("category", cat)
            st.success(f"{len(df)} surcharge rows with occurrences.")

        df = self._s("df")
        if df is not None and not df.empty:
            tot = S.opco_totals(df)
            st.dataframe(
                tot.assign(**{
                    "Occurrences": tot["Occurrences"].map(lambda v: f"{v:,.0f}"),
                    "Net Spend 1": tot["Net Spend 1"].map(lambda v: f"${v:,.2f}"),
                    "Net Spend 2": tot["Net Spend 2"].map(lambda v: f"${v:,.2f}"),
                    "Impact": tot["Impact"].map(lambda v: f"${v:,.2f}"),
                }),
                use_container_width=True, hide_index=True)
            theme.note(
                "Cross-check these against the template's own <b>OpCo Summary</b> "
                "tab — they should match to the cent."
            )
            if float(tot.iloc[-1]["Impact"]) == 0:
                st.info(
                    "Discount 1 and Discount 2 are identical in this template, so "
                    "the impact is zero. Set the proposed discounts on the "
                    "**Surcharges** tab to model the proposal."
                )

    # ----------------------------------------------------------------
    def render_editor(self) -> None:
        df = self._s("df")
        if df is None or df.empty:
            st.info("Load a template on the **Template** tab first.")
            return

        theme.section("Occurrences and rates", "edit any List or Discount")
        theme.rule(
            "<b>Net Rate = ROUND(List × (1 − Discount), 2)</b> &nbsp;·&nbsp; "
            "<b>Net Spend = Net Rate × Occurrences</b><br>"
            "The same arithmetic the template uses, so an edited rate behaves "
            "exactly as it would there. Occurrences come from the data and are "
            "not editable."
        )

        base = self._s("edits")
        if base is None:
            base = _prepare(df)

        opcos = sorted(x for x in base["OpCo"].dropna().unique() if str(x).strip())
        c1, c2 = st.columns([2, 1])
        with c1:
            pick = st.multiselect("Operating companies", opcos, default=opcos,
                                  key=self._k("opco"))
        with c2:
            zoned = st.checkbox("Show zone detail", value=True, key=self._k("zoned"),
                                help="Zone-based surcharges carry a different "
                                     "list rate per zone band.")

        view = base[base["OpCo"].isin(pick)] if pick else base
        if not zoned:
            st.caption("Rolled up to one row per surcharge — switch zone detail "
                       "back on to edit individual zone bands.")
            st.dataframe(S.by_surcharge(_apply(base)), use_container_width=True,
                        hide_index=True)
            return

        cols = ["OpCo", "Surcharge", "Zone", "Occurrences", "List",
                "Discount 1 %", "Discount 2 %"]
        edited = st.data_editor(
            view[cols],
            key=self._k("editor"),
            use_container_width=True,
            hide_index=True,
            num_rows="fixed",
            column_config={
                "OpCo": st.column_config.TextColumn("OpCo", disabled=True,
                                                    width="small"),
                "Surcharge": st.column_config.TextColumn("Surcharge",
                                                         disabled=True,
                                                         width="large"),
                "Zone": st.column_config.TextColumn("Zone", disabled=True,
                                                    width="small"),
                "Occurrences": st.column_config.NumberColumn(
                    "Occurrences", disabled=True, format="%d"),
                "List": st.column_config.NumberColumn(
                    "List rate ($)", min_value=0.0, step=0.05, format="%.2f",
                    help="The published list rate — edit to model a rate change."),
                "Discount 1 %": st.column_config.NumberColumn(
                    "Current disc %", min_value=0.0, max_value=100.0, step=1.0,
                    format="%.2f"),
                "Discount 2 %": st.column_config.NumberColumn(
                    "Proposed disc %", min_value=0.0, max_value=100.0, step=1.0,
                    format="%.2f"),
            },
            height=460,
        )

        merged = base.copy()
        merged.loc[edited.index, ["List", "Discount 1 %", "Discount 2 %"]] = \
            edited[["List", "Discount 1 %", "Discount 2 %"]]
        self._set("edits", merged)

        result = _apply(merged)
        self._set("result", result)

        changed = _changes(df, result)
        b1, b2 = st.columns([1, 3])
        with b1:
            if st.button("Reset to template", use_container_width=True,
                        key=self._k("reset")):
                self._set("edits", None)
                self._set("result", None)
                st.rerun()
        with b2:
            if changed:
                st.caption(f"**{changed}** row(s) edited away from the template.")

        theme.section("Effect of your edits")
        tot = S.opco_totals(result)
        total = tot.iloc[-1]
        k1, k2, k3 = st.columns(3)
        k1.metric("Current cost", f"${total['Net Spend 1']:,.0f}")
        k2.metric("Proposed cost", f"${total['Net Spend 2']:,.0f}")
        pct = (total["Impact"] / total["Net Spend 1"]
               if total["Net Spend 1"] else 0)
        k3.metric("Impact", f"${total['Impact']:,.0f}",
                  delta=f"{pct:.1%}", delta_color="inverse")

    # ----------------------------------------------------------------
    def current(self) -> Optional[pd.DataFrame]:
        """The table as it stands, including any edits."""
        r = self._s("result")
        if r is not None:
            return r
        df = self._s("df")
        return S.recalculate(df) if df is not None and not df.empty else None

    # ----------------------------------------------------------------
    def render_fuel(self, parent_totals:
                    Optional[Dict[str, Tuple[float, float]]] = None) -> None:
        """
        `parent_totals`, when given, is the paired Rate Comparison / DIM
        Change analysis's Current/Proposed cost by OpCo — used only to
        pre-fill the Transportation cost inputs below; the analyst can
        still edit every figure.
        """
        data = self.current()
        if data is None:
            st.info("Load a template on the **Template** tab first.")
            return
        data = S.add_fuel_flag(data)

        theme.section("Fuel", "assessed on the net package rate plus surcharges")
        theme.rule(
            "<b>Fuel = (Transportation + fuel-applicable surcharges) × "
            "(1 − fuel discount) × fuel rate</b>, per operating company.<br>"
            "Which surcharges attract fuel comes from the published Express and "
            "Ground lists — auto-matched below, and overridable."
        )

        include = st.checkbox("Include fuel in the analysis", True,
                              key=self._k("incfuel"))
        self._set("include_fuel", include)

        opcos = [o for o in ["Express", "Ground", "Ground Economy",
                             "Express Freight", "FDX"]
                 if o in set(data["OpCo"])]
        opcos += [o for o in sorted(set(data["OpCo"]))
                  if o and o not in opcos]

        fuel: dict = {}
        if include:
            st.markdown("**Fuel rates and discounts**")
            h = st.columns([2, 1, 1, 1])
            for col, label in zip(h, ["OpCo", "Fuel rate %",
                                      "Current disc %", "Proposed disc %"]):
                col.caption(label)
            for opco in opcos:
                c = st.columns([2, 1, 1, 1])
                c[0].markdown(f"<div style='padding-top:.5rem'>{opco}</div>",
                              unsafe_allow_html=True)
                rate = c[1].number_input(f"rate {opco}", 0.0, 100.0, 0.0, 0.25,
                                         key=self._k(f"fr_{opco}"),
                                         label_visibility="collapsed")
                dc = c[2].number_input(f"dc {opco}", 0.0, 100.0, 0.0, 1.0,
                                       key=self._k(f"fdc_{opco}"),
                                       label_visibility="collapsed")
                dp = c[3].number_input(f"dp {opco}", 0.0, 100.0, 0.0, 1.0,
                                       key=self._k(f"fdp_{opco}"),
                                       label_visibility="collapsed")
                fuel[opco] = SA.FuelSetting(opco, rate / 100, dc / 100, dp / 100)
        self._set("fuel", fuel)

        theme.section("Transportation cost",
                      "the net rate cost fuel is assessed on")
        if parent_totals:
            theme.note(
                "Pre-filled from this workbook's own Current / Proposed cost by "
                "OpCo — override any figure below if it doesn't match."
            )
        else:
            theme.note(
                "Leave at zero for a surcharge-only request. When the same request "
                "also covers a rate comparison or DIM change, enter that analysis's "
                "net rate cost here so fuel and the total are complete."
            )
        tc: dict = {}
        tp: dict = {}
        h = st.columns([2, 1, 1])
        for col, label in zip(h, ["OpCo", "Current cost $", "Proposed cost $"]):
            col.caption(label)
        for opco in opcos:
            c = st.columns([2, 1, 1])
            c[0].markdown(f"<div style='padding-top:.5rem'>{opco}</div>",
                          unsafe_allow_html=True)
            match = _match_opco(opco, parent_totals) if parent_totals else None
            dtc = float(match[0]) if match else 0.0
            dtp = float(match[1]) if match else 0.0
            tc[opco] = c[1].number_input(f"tc {opco}", 0.0, 1e12, dtc, 100.0,
                                         key=self._k(f"tc_{opco}"),
                                         label_visibility="collapsed")
            tp[opco] = c[2].number_input(f"tp {opco}", 0.0, 1e12, dtp, 100.0,
                                         key=self._k(f"tp_{opco}"),
                                         label_visibility="collapsed")
        self._set("transport_c", tc)
        self._set("transport_p", tp)

        with st.expander("Which surcharges attract fuel"):
            flags = data[["OpCo", "Surcharge", "Fuel applies"]].drop_duplicates(
                subset=["OpCo", "Surcharge"]).reset_index(drop=True)
            edited = st.data_editor(
                flags, key=self._k("fuelflags"), use_container_width=True,
                hide_index=True, num_rows="fixed",
                column_config={
                    "OpCo": st.column_config.TextColumn(disabled=True,
                                                        width="small"),
                    "Surcharge": st.column_config.TextColumn(disabled=True,
                                                             width="large"),
                    "Fuel applies": st.column_config.CheckboxColumn(
                        "Fuel applies",
                        help="Override the auto-match where your reading of the "
                             "published list differs."),
                })
            self._set("fuel_flags", edited)

        self.render_totals_preview()

    # ----------------------------------------------------------------
    def config(self) -> SA.SurchargeConfig:
        info = self._s("info")
        months = info.months if info else None
        return SA.SurchargeConfig(
            analysis_notes=[n for n in (self._s("notes") or "").splitlines()
                            if n.strip()],
            date_range=self._s("date_range") or (info.period_label if info else ""),
            cht_id=self._s("cht_id") or "",
            category=self._s("category", "Category 1"),
            group_unchanged=bool(self._s("group_unchanged", True)),
            include_fuel=bool(self._s("include_fuel", True)),
            fuel=self._s("fuel") or {},
            transport_current=self._s("transport_c") or {},
            transport_proposed=self._s("transport_p") or {},
            annualise=bool(self._s("annualise", False)),
            months_covered=months,
            annual_multiplier=self._s("annual_mult"),
            excludes=[n for n in (self._s("excludes") or "").splitlines()
                     if n.strip()],
            surcharge_excludes=[n for n in (self._s("sur_excludes") or "")
                                .splitlines() if n.strip()],
        )

    def apply_fuel_flags(self, data: pd.DataFrame) -> pd.DataFrame:
        """Fold the user's fuel overrides back onto the detail rows."""
        out = S.add_fuel_flag(data)
        flags = self._s("fuel_flags")
        if flags is not None and not flags.empty:
            m = {(r["OpCo"], r["Surcharge"]): bool(r["Fuel applies"])
                 for _, r in flags.iterrows()}
            out["Fuel applies"] = [
                m.get((o, s), f)
                for o, s, f in zip(out["OpCo"], out["Surcharge"],
                                   out["Fuel applies"])
            ]
        return out

    def render_totals_preview(self) -> None:
        data = self.current()
        if data is None:
            return
        cfg = self.config()
        tot = SA.preview_totals(self.apply_fuel_flags(data), cfg)
        if tot.empty:
            return
        theme.section("Total cost components")
        show = tot.copy()
        for c in ("Current", "Proposed", "Impact"):
            show[c] = show[c].map(_money)
        st.dataframe(show, use_container_width=True, hide_index=True)

    # ----------------------------------------------------------------
    def render_summary(self) -> None:
        result = self.current()
        if result is None:
            st.info("Load a template first.")
            return
        result = S.recalculate(result) if "Priced" in result.columns else result

        theme.section("Surcharge summary", "one row per OpCo and surcharge")

        g = S.by_surcharge(result)
        show = g[["OpCo", "Surcharge", "List", "Discount 1", "Discount 2",
                  "Occurrences", "Net Spend 1", "Net Spend 2", "Impact"]].copy()
        show["Discount 1"] = show["Discount 1"].map(lambda v: f"{v:.1%}")
        show["Discount 2"] = show["Discount 2"].map(lambda v: f"{v:.1%}")
        show["Occurrences"] = show["Occurrences"].map(lambda v: f"{v:,.0f}")
        for c in ("Net Spend 1", "Net Spend 2", "Impact"):
            show[c] = show[c].map(
                lambda v: "—" if pd.isna(v) else f"${v:,.2f}")
        show.columns = ["OpCo", "Surcharge", "List", "Current disc",
                        "Proposed disc", "Occurrences", "Current cost",
                        "Proposed cost", "Impact"]
        st.dataframe(show, use_container_width=True, hide_index=True, height=520)

        theme.section("Totals")
        tot = S.opco_totals(result)
        t = tot.copy()
        t["Occurrences"] = t["Occurrences"].map(lambda v: f"{v:,.0f}")
        for c in ("Net Spend 1", "Net Spend 2", "Impact"):
            t[c] = t[c].map(lambda v: f"${v:,.2f}")
        t.columns = ["OpCo", "Surcharges", "Occurrences", "Current cost",
                     "Proposed cost", "Impact"]
        st.dataframe(t, use_container_width=True, hide_index=True)

        unpriced = result[~result["Priced"].astype(bool)]
        if not unpriced.empty:
            names = sorted(set(unpriced["Surcharge"]))
            st.info(
                "Not priced per occurrence by the template — "
                + ", ".join(names[:6])
                + (" …" if len(names) > 6 else "")
                + ". Declared Value is charged per $100 of declared value, so its "
                  "cost comes from the Surcharge Detail Template."
            )

        csv = S.by_surcharge(result).to_csv(index=False).encode()
        st.download_button("⬇  Download surcharge table (CSV)", data=csv,
                           file_name="Surcharge Analysis.csv", mime="text/csv",
                           key=self._k("csv_dl"))

    # ----------------------------------------------------------------
    def render_build_details(self, standalone: bool = True) -> None:
        """Notes / CHT / grouping / annualisation inputs. When embedded
        inside another process, the identity fields (CHT, date range) are
        skipped — the combined Summary section takes those from the parent
        analysis instead of repeating them."""
        theme.section(
            "Surcharge summary details" if standalone
            else "Surcharge summary options")
        info = self._s("info")

        if standalone:
            c1, c2 = st.columns(2)
            with c1:
                self._set("cht_id", st.text_input(
                    "CHT / Group ID", key=self._k("cht")))
                self._set("date_range", st.text_input(
                    "Date range", value=info.period_label if info else "",
                    key=self._k("dr")))

        c1, c2 = st.columns(2)
        with c1:
            self._set("group_unchanged", st.checkbox(
                "Group surcharges with no discount change", True,
                key=self._k("group"),
                help="List individually only where the discount changes and "
                     "occurrences exist; sum the rest into “All other "
                     "surcharges subject to fuel”."))
        with c2:
            ann = st.checkbox("Annualise the surcharge totals", False,
                              key=self._k("ann"))
            self._set("annualise", ann)
            if ann:
                default = (12 / info.months) if (info and info.months) else 1.0
                self._set("annual_mult", st.number_input(
                    "Annualisation multiplier", 0.1, 24.0, float(default), 0.5,
                    key=self._k("annm"),
                    help=f"Data covers {info.months if info else '?'} months, "
                         f"so 12 ÷ months = ×{default:g}."))

        self._set("notes", st.text_area(
            "Additional surcharge notes (one per line)",
            "Focus: impact analysis for proposed surcharge discounts",
            key=self._k("notes")))
        e1, e2 = st.columns(2)
        with e1:
            self._set("excludes", st.text_area(
                "Surcharge excludes (one per line)",
                "Ground Economy shipments\nInternational shipments",
                key=self._k("exc")))
        with e2:
            self._set("sur_excludes", st.text_area(
                "Surcharges exclude (one per line)",
                "Pickup charges\nDemand Surcharges", key=self._k("sexc")))


# ==========================================================================
def _prepare(df: pd.DataFrame) -> pd.DataFrame:
    """Editor view: discounts as percentages, derived columns alongside."""
    out = df.copy()
    out["Discount 1 %"] = pd.to_numeric(out["Discount 1"],
                                        errors="coerce").fillna(0) * 100
    out["Discount 2 %"] = pd.to_numeric(out["Discount 2"],
                                        errors="coerce").fillna(0) * 100
    return out


def _apply(edited: pd.DataFrame) -> pd.DataFrame:
    """Take the edited percentages back to fractions and recalculate."""
    out = edited.copy()
    out["Discount 1"] = pd.to_numeric(out["Discount 1 %"],
                                      errors="coerce").fillna(0) / 100
    out["Discount 2"] = pd.to_numeric(out["Discount 2 %"],
                                      errors="coerce").fillna(0) / 100
    return S.recalculate(out)


def _changes(original: pd.DataFrame, result: pd.DataFrame) -> int:
    """Rows where any of List, Discount 1 or Discount 2 differs."""
    diff = None
    for col in ("List", "Discount 1", "Discount 2"):
        a = pd.to_numeric(original[col], errors="coerce").fillna(-1).round(6)
        b = pd.to_numeric(result[col], errors="coerce").fillna(-1).round(6)
        d = a.values != b.values
        diff = d if diff is None else (diff | d)
    return int(diff.sum()) if diff is not None else 0


def _money(v) -> str:
    if v is None or pd.isna(v):
        return "—"
    return f"-${abs(v):,.0f}" if v < 0 else f"${v:,.0f}"


def _match_opco(name: str, totals: Dict[str, Tuple[float, float]]
               ) -> Optional[Tuple[float, float]]:
    if name in totals:
        return totals[name]
    lo = name.lower()
    for k, v in totals.items():
        if lo in k.lower() or k.lower() in lo:
            return v
    return None


# ==========================================================================
# Standalone Process 3 screen
# ==========================================================================
def render() -> None:
    theme.masthead(
        "Surcharge Analysis",
        "Read occurrences and discounts from the Surcharge Pricing Template, "
        "adjust any rate or discount, and see the impact.",
    )

    step = SurchargeStep("sc")

    t1, t2, t3, t4 = st.tabs(
        ["1 · Template", "2 · Surcharges", "3 · Fuel & totals", "4 · Build"])
    with t1:
        step.render_template()
    with t2:
        step.render_editor()
    with t3:
        step.render_fuel()
    with t4:
        _build(step)


def _build(step: SurchargeStep) -> None:
    data = step.current()
    if data is None:
        st.info("Load a template first.")
        return

    step.render_build_details(standalone=True)

    if st.button("Build workbook", type="primary", key=step._k("build")):
        cfg = step.config()
        with st.spinner("Writing formulas…"):
            buf, reported = SA.run(step.apply_fuel_flags(data), cfg)
        step._set("output", buf.getvalue())
        step._set("reported", reported)
        st.success(f"{len(reported)} reported surcharge lines.")

    out = step._s("output")
    if not out:
        return

    step.render_summary()
    step.render_totals_preview()

    st.download_button(
        "⬇  Download surcharge workbook", data=out,
        file_name="Surcharge Analysis.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        key=step._k("dl"))
    st.caption(
        "Every cost in the workbook is a live SUMIFS over the Surcharge "
        "Detail tab, and the fuel rates live on the Rules tab — change one "
        "there and the summary recalculates in Excel."
    )
