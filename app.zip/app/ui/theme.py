"""
FedEx-styled presentation layer for the Streamlit app.

Palette follows the FedEx corporate colours - purple #4D148C and orange
#FF6600 - with a neutral supporting scale. Kept in one place so every process
screen looks the same and a rebrand is a single edit.
"""

from __future__ import annotations

from typing import Iterable, Optional

import streamlit as st

# --------------------------------------------------------------------------
PURPLE = "#4D148C"
PURPLE_DARK = "#3A0F6B"
PURPLE_LIGHT = "#7B4BB7"
PURPLE_WASH = "#F3EEF9"
ORANGE = "#FF6600"
ORANGE_DARK = "#E05500"
ORANGE_WASH = "#FFF1E6"
INK = "#26232B"
MUTED = "#6B6675"
BORDER = "#E4E0EB"
CANVAS = "#FBFAFC"

CSS = f"""
<style>
:root {{
  --fx-purple: {PURPLE};
  --fx-purple-dark: {PURPLE_DARK};
  --fx-purple-light: {PURPLE_LIGHT};
  --fx-purple-wash: {PURPLE_WASH};
  --fx-orange: {ORANGE};
  --fx-orange-dark: {ORANGE_DARK};
  --fx-orange-wash: {ORANGE_WASH};
  --fx-ink: {INK};
  --fx-muted: {MUTED};
  --fx-border: {BORDER};
  --fx-canvas: {CANVAS};
}}

/* ---------- canvas ---------- */
.stApp {{ background: var(--fx-canvas); }}
.block-container {{ padding-top: 1.4rem; padding-bottom: 3rem; max-width: 1500px; }}
html, body, [class*="css"] {{ color: var(--fx-ink); }}

h1, h2, h3, h4 {{ color: var(--fx-purple); font-weight: 700; letter-spacing: -.01em; }}
h1 {{ font-size: 1.65rem; }}
h2 {{ font-size: 1.3rem; }}
h3 {{ font-size: 1.05rem; }}
hr {{ border-color: var(--fx-border); }}

/* ---------- masthead ---------- */
.fx-header {{
  background: linear-gradient(100deg, var(--fx-purple) 0%, var(--fx-purple-dark) 62%, #2C0B52 100%);
  border-radius: 12px;
  padding: 1.05rem 1.5rem 1.15rem;
  margin: 0 0 1.15rem;
  position: relative;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(77,20,140,.16);
}}
.fx-header:after {{
  content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 4px;
  background: linear-gradient(90deg, var(--fx-orange) 0%, #FF8A3D 55%, transparent 100%);
}}
.fx-header h1 {{
  color: #fff; margin: 0; font-size: 1.45rem; font-weight: 700; letter-spacing: -.015em;
}}
.fx-header .fx-sub {{
  color: #D9CCEC; font-size: .82rem; margin-top: .28rem; letter-spacing: .01em;
}}
.fx-header .fx-accent {{ color: var(--fx-orange); }}

/* ---------- section headers ---------- */
.fx-section {{
  display: flex; align-items: baseline; gap: .6rem;
  border-left: 4px solid var(--fx-orange);
  padding: .1rem 0 .1rem .7rem; margin: 1.5rem 0 .55rem;
}}
.fx-section .fx-title {{ font-weight: 700; color: var(--fx-purple); font-size: 1.02rem; }}
.fx-section .fx-hint {{ color: var(--fx-muted); font-size: .8rem; }}

.fx-card {{
  background: #fff; border: 1px solid var(--fx-border); border-radius: 10px;
  padding: .9rem 1.05rem; margin-bottom: .8rem;
}}
.fx-note {{
  background: var(--fx-purple-wash); border-left: 3px solid var(--fx-purple-light);
  border-radius: 6px; padding: .55rem .8rem; font-size: .84rem; color: #3F3A48;
  margin: .35rem 0 .7rem;
}}
.fx-rule {{
  background: var(--fx-orange-wash); border-left: 3px solid var(--fx-orange);
  border-radius: 6px; padding: .55rem .8rem; font-size: .84rem; color: #4A3520;
  margin: .35rem 0 .7rem;
}}
.fx-chip {{
  display: inline-block; padding: .12rem .55rem; border-radius: 999px;
  font-size: .72rem; font-weight: 600; letter-spacing: .02em; margin-right: .3rem;
}}
.fx-chip-purple {{ background: var(--fx-purple-wash); color: var(--fx-purple); }}
.fx-chip-orange {{ background: var(--fx-orange-wash); color: var(--fx-orange-dark); }}
.fx-chip-grey   {{ background: #EEECF1; color: var(--fx-muted); }}

/* ---------- sidebar ---------- */
section[data-testid="stSidebar"] {{
  background: #fff; border-right: 1px solid var(--fx-border); min-width: 20.5rem;
}}
section[data-testid="stSidebar"] .fx-brand {{
  background: linear-gradient(135deg, var(--fx-purple) 0%, var(--fx-purple-dark) 100%);
  border-radius: 10px; padding: .85rem 1rem; margin-bottom: 1rem;
}}
section[data-testid="stSidebar"] .fx-brand .fx-name {{
  color: #fff; font-weight: 700; font-size: 1.02rem; line-height: 1.2;
}}
section[data-testid="stSidebar"] .fx-brand .fx-name span {{ color: var(--fx-orange); }}
section[data-testid="stSidebar"] .fx-brand .fx-tag {{
  color: #CBB9E4; font-size: .74rem; margin-top: .2rem;
}}
section[data-testid="stSidebar"] label {{ color: var(--fx-ink); }}

/* nav radio -> pill list */
section[data-testid="stSidebar"] div[role="radiogroup"] {{ gap: .18rem; }}
section[data-testid="stSidebar"] div[role="radiogroup"] > label {{
  border: 1px solid transparent; border-radius: 8px;
  padding: .42rem .6rem; margin: 0; transition: all .12s ease;
}}
section[data-testid="stSidebar"] div[role="radiogroup"] > label:hover {{
  background: var(--fx-purple-wash);
}}
section[data-testid="stSidebar"] div[role="radiogroup"] > label:has(input:checked) {{
  background: var(--fx-purple-wash);
  border-color: #DCCEF0;
  box-shadow: inset 3px 0 0 var(--fx-orange);
}}
section[data-testid="stSidebar"] div[role="radiogroup"] > label:has(input:checked) p {{
  color: var(--fx-purple) !important; font-weight: 650;
}}

/* ---------- tabs ---------- */
.stTabs [data-baseweb="tab-list"] {{
  gap: .15rem; border-bottom: 1px solid var(--fx-border);
}}
.stTabs [data-baseweb="tab"] {{
  height: 2.5rem; padding: 0 1rem; color: var(--fx-muted);
  font-weight: 600; font-size: .87rem; border-radius: 8px 8px 0 0;
}}
.stTabs [data-baseweb="tab"]:hover {{ background: var(--fx-purple-wash); color: var(--fx-purple); }}
.stTabs [aria-selected="true"] {{ color: var(--fx-purple) !important; background: #fff; }}
.stTabs [data-baseweb="tab-highlight"] {{ background: var(--fx-orange); height: 3px; }}
.stTabs [data-baseweb="tab-border"] {{ background: var(--fx-border); }}

/* ---------- buttons ---------- */
.stButton > button, .stDownloadButton > button, .stFormSubmitButton > button {{
  border-radius: 8px; font-weight: 600; border: 1px solid var(--fx-border);
  transition: all .12s ease;
}}
.stButton > button:hover, .stDownloadButton > button:hover {{
  border-color: var(--fx-orange); color: var(--fx-orange-dark);
}}
.stButton > button[kind="primary"], .stFormSubmitButton > button[kind="primary"] {{
  background: var(--fx-purple); border-color: var(--fx-purple); color: #fff;
}}
.stButton > button[kind="primary"]:hover {{
  background: var(--fx-purple-dark); border-color: var(--fx-purple-dark); color: #fff;
  box-shadow: 0 2px 8px rgba(77,20,140,.25);
}}
.stDownloadButton > button {{
  background: var(--fx-orange); border-color: var(--fx-orange); color: #fff;
}}
.stDownloadButton > button:hover {{
  background: var(--fx-orange-dark); border-color: var(--fx-orange-dark); color: #fff;
  box-shadow: 0 2px 8px rgba(255,102,0,.28);
}}

/* ---------- inputs ---------- */
.stTextInput input, .stNumberInput input, .stTextArea textarea,
div[data-baseweb="select"] > div {{ border-radius: 8px !important; }}
.stTextInput input:focus, .stNumberInput input:focus, .stTextArea textarea:focus {{
  border-color: var(--fx-purple) !important; box-shadow: 0 0 0 2px rgba(77,20,140,.12) !important;
}}
div[data-baseweb="tag"] {{ background: var(--fx-purple) !important; }}

/* ---------- expanders ---------- */
details, div[data-testid="stExpander"] {{
  border: 1px solid var(--fx-border) !important; border-radius: 10px !important;
  background: #fff; overflow: hidden;
}}
div[data-testid="stExpander"] summary {{ font-weight: 600; color: var(--fx-purple); }}
div[data-testid="stExpander"] summary:hover {{ background: var(--fx-purple-wash); }}

/* ---------- metrics ---------- */
div[data-testid="stMetric"] {{
  background: #fff; border: 1px solid var(--fx-border);
  border-left: 4px solid var(--fx-purple);
  border-radius: 10px; padding: .7rem .9rem;
}}
div[data-testid="stMetricValue"] {{ font-size: 1.5rem; color: var(--fx-purple); font-weight: 700; }}
div[data-testid="stMetricLabel"] p {{ color: var(--fx-muted); font-size: .78rem; }}

/* ---------- tables ---------- */
div[data-testid="stDataFrame"], div[data-testid="stTable"] {{
  border: 1px solid var(--fx-border); border-radius: 10px; overflow: hidden;
}}

/* ---------- alerts ---------- */
div[data-testid="stAlert"] {{ border-radius: 9px; border-left-width: 4px; }}

/* ---------- file uploader ---------- */
section[data-testid="stFileUploaderDropzone"] {{
  border: 1.5px dashed #CFC6DD; border-radius: 10px; background: #fff;
}}
section[data-testid="stFileUploaderDropzone"]:hover {{
  border-color: var(--fx-orange); background: var(--fx-orange-wash);
}}

/* ---------- progress / spinner ---------- */
.stProgress > div > div > div > div {{ background: var(--fx-orange); }}

/* ---------- footer ---------- */
.fx-footer {{
  margin-top: 2.2rem; padding-top: .8rem; border-top: 1px solid var(--fx-border);
  color: var(--fx-muted); font-size: .75rem;
}}
</style>
"""


# --------------------------------------------------------------------------
def inject() -> None:
    """Apply the stylesheet. Call once per rerun, before anything renders."""
    st.markdown(CSS, unsafe_allow_html=True)


def masthead(title: str, subtitle: str = "", accent: str = "") -> None:
    """Purple banner with an orange rule, used at the top of every process."""
    accent_html = f' <span class="fx-accent">{accent}</span>' if accent else ""
    sub = f'<div class="fx-sub">{subtitle}</div>' if subtitle else ""
    st.markdown(
        f'<div class="fx-header"><h1>{title}{accent_html}</h1>{sub}</div>',
        unsafe_allow_html=True,
    )


def brand() -> None:
    """Sidebar brand block."""
    st.markdown(
        '<div class="fx-brand">'
        '<div class="fx-name">Re-rating <span>Toolkit</span></div>'
        '<div class="fx-tag">ER / BDA &nbsp;·&nbsp; Manual Re-rating</div>'
        '</div>',
        unsafe_allow_html=True,
    )


def section(title: str, hint: str = "") -> None:
    hint_html = f'<span class="fx-hint">{hint}</span>' if hint else ""
    st.markdown(
        f'<div class="fx-section"><span class="fx-title">{title}</span>'
        f'{hint_html}</div>',
        unsafe_allow_html=True,
    )


def note(text: str) -> None:
    """Soft purple explanatory note."""
    st.markdown(f'<div class="fx-note">{text}</div>', unsafe_allow_html=True)


def rule(text: str) -> None:
    """Orange callout for a quoted rule from the procedure."""
    st.markdown(f'<div class="fx-rule">{text}</div>', unsafe_allow_html=True)


def chips(items: Iterable[tuple]) -> None:
    """Render (label, tone) chips; tone is 'purple' | 'orange' | 'grey'."""
    html = "".join(
        f'<span class="fx-chip fx-chip-{tone}">{label}</span>'
        for label, tone in items
    )
    st.markdown(html, unsafe_allow_html=True)


def footer(text: Optional[str] = None) -> None:
    st.markdown(
        f'<div class="fx-footer">{text or ""}</div>', unsafe_allow_html=True
    )
