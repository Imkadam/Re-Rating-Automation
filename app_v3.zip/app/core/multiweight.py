"""
Multiweight Re-Rating.

Procedure: "Multiweight ReRating".

Ground Multiweight (MWT) shipments travelling to the same destination on the
same day are billed as one aggregated shipment rather than package-by-package,
at a lower per-pound "tier" rate - as long as the aggregate clears the
customer-agreement minimums. This module is the pure calculation behind that:
grouping shipments into one "Tag" per shipment, matching the aggregate weight
against a weight tier, and applying the tier rate / minimum charge / deficit
weight rule to produce a "Least Cost" and a blended Cost/lb.

The published FY tier boundaries and per-zone rates are not standardised the
way MBW surcharges are - the analyst reads them off the customer's own Net
Rate Sheet, so `default_tiers()` only ships the boundary/minimum-charge shape,
left for the analyst to fill in from that rate sheet. `MWTTerms` (Minimum
Average Package Weight, Minimum Shipment Weight) are read directly from the
customer agreement and have no sensible global default.

Rating formula (confirmed against the procedure's own later steps, which
describe "Least Cost" and "Cost/lb" without spelling out the arithmetic in
between)::

    aggregate_weight = sum(package weights in the Tag group)
    billed_weight     = MAX(aggregate_weight,
                             Minimum Average Package Weight x package_count,
                             Minimum Shipment Weight)
    deficit_weight    = MAX(0, tier.min_weight - billed_weight)
    billed_weight     = MAX(billed_weight, tier.min_weight)   # deficit is billed
    tier_cost         = MAX(billed_weight x tier.rate_per_lb[zone],
                             tier.min_charge[zone])
    least_cost        = MIN(tier_cost, sum of single-piece cost in the group)
    cost_per_lb        = least_cost / billed_weight

Groups whose aggregate weight falls below the first tier's minimum are not
Multiweight-eligible; they are rated as plain single-piece Ground (least_cost
degenerates to the summed single-piece cost, cost_per_lb to the same figure
divided by the summed weight, matching the procedure's own two Cost/lb
formulas for MWT vs. GR shipments).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

ZONES = ["2", "3", "4", "5", "6", "7", "8"]

# Products the procedure groups into the MWT pivot ("Ground, Ground
# Multiweight (MWT), Home Delivery (only if MWT applies per the customer
# agreement)"). Home Delivery is opt-in per engagement, so it is left out of
# the default and added by the analyst when the agreement calls for it.
DEFAULT_MWT_PRODUCTS = ["Ground", "Ground Multiweight", "Multiweight"]


@dataclass
class MWTTier:
    """One weight tier of the Ground Multiweight rate table."""

    label: str
    min_weight: float
    max_weight: Optional[float]                          # None = open-ended
    rate_per_lb: Dict[str, float] = field(default_factory=dict)   # zone -> $/lb
    min_charge: Dict[str, float] = field(default_factory=dict)    # zone -> $

    def contains(self, weight: float) -> bool:
        if weight < self.min_weight:
            return False
        return self.max_weight is None or weight <= self.max_weight


def default_tiers() -> List[MWTTier]:
    """
    Two-tier shape matching the reference Job Aid table (200-499 lbs /
    500+ lbs), minimum charge defaulted to the published $91 FY2026 figure -
    per-zone rates start at 0.0 for the analyst to fill in from the
    customer's own Ground Multiweight rate table, since those aren't a
    published constant the way MBW surcharge rates are.
    """
    return [
        MWTTier(
            label="Tier 1 (200-499 lbs)", min_weight=200.0, max_weight=499.0,
            rate_per_lb={z: 0.0 for z in ZONES},
            min_charge={z: 91.0 for z in ZONES},
        ),
        MWTTier(
            label="Tier 2 (500+ lbs)", min_weight=500.0, max_weight=None,
            rate_per_lb={z: 0.0 for z in ZONES},
            min_charge={z: 91.0 for z in ZONES},
        ),
    ]


@dataclass
class MWTTerms:
    """Customer-agreement terms that decide how the tier minimums apply."""

    minimum_average_package_weight: float = 0.0
    minimum_shipment_weight: float = 0.0


def tier_for(weight: float, tiers: Sequence[MWTTier]) -> Optional[MWTTier]:
    """The tier this aggregate weight falls in, or None below the first
    tier's floor (not MWT-eligible)."""
    for t in tiers:
        if t.contains(weight):
            return t
    if tiers and weight is not None and weight > tiers[-1].min_weight:
        return tiers[-1]           # heavier than the top tier's own ceiling
    return None


def make_tag(ship_date, origin_zip, recipient_addr, recipient_postal) -> str:
    """
    Procedure: "Generate a unique identifier for each shipment by
    concatenating Ship Date, Actual Origin ZIP, Recipient Address, Recipient
    Postal Code" - the key that groups a multi-package shipment together.
    """
    parts = (ship_date, origin_zip, recipient_addr, recipient_postal)

    def _part(p) -> str:
        if p is None:
            return ""
        s = str(p).strip()
        return "" if s.lower() == "nan" else s

    return "|".join(_part(p) for p in parts)


@dataclass
class GroupResult:
    """The rated outcome for one Tag group, one side (Current / Proposed)."""

    tag: str
    zone: str
    package_count: float
    aggregate_weight: float
    single_piece_cost: Optional[float]
    tier: Optional[MWTTier]
    is_mwt: bool
    billed_weight: float
    deficit_weight: float
    tier_cost: Optional[float]
    least_cost: Optional[float]
    cost_per_lb: Optional[float]


def rate_group(tag: str, zone: str, package_count: float,
              aggregate_weight: float, single_piece_cost: Optional[float],
              tiers: Sequence[MWTTier], terms: MWTTerms) -> GroupResult:
    """Rate one Tag group per the formula in the module docstring."""
    tier = tier_for(aggregate_weight, tiers)
    sp_cost = single_piece_cost

    if tier is None:
        # Below the first tier's floor - not MWT-eligible, plain Ground.
        cost_per_lb = ((sp_cost / aggregate_weight)
                       if (sp_cost is not None and aggregate_weight) else None)
        return GroupResult(
            tag, zone, package_count, aggregate_weight, sp_cost,
            None, False, aggregate_weight, 0.0, sp_cost, sp_cost, cost_per_lb,
        )

    avg_floor = terms.minimum_average_package_weight * package_count
    billed = max(aggregate_weight, avg_floor, terms.minimum_shipment_weight)
    deficit = max(0.0, tier.min_weight - billed)
    billed = max(billed, tier.min_weight)

    rate = tier.rate_per_lb.get(zone, 0.0) or 0.0
    min_charge = tier.min_charge.get(zone, 0.0) or 0.0
    tier_cost = max(billed * rate, min_charge)

    least_cost = (min(tier_cost, sp_cost) if sp_cost is not None else tier_cost)
    cost_per_lb = (least_cost / billed) if billed else None

    return GroupResult(
        tag, zone, package_count, aggregate_weight, sp_cost,
        tier, True, billed, deficit, tier_cost, least_cost, cost_per_lb,
    )
