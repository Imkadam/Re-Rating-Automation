"""
Process registry.

Every re-rating process registers itself here.  app.py reads this list to
build the sidebar, so adding a new process means adding one entry - no changes
to the Streamlit shell.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List


@dataclass
class Process:
    key: str
    name: str
    description: str
    render: Callable[[], None]
    status: str = "ready"          # 'ready' | 'planned'


def _load() -> List[Process]:
    from ui import dim_mbw_ui, multiweight_ui, rate_comparison_ui

    return [
        Process(
            key="rate_comparison",
            name="Rate Comparison",
            description=(
                "Cleanse shipment data, rate every shipment against the "
                "Current and Proposed Net Rate Sheets, and build the Summary."
            ),
            render=rate_comparison_ui.render,
        ),
        Process(
            key="dim_mbw",
            name="DIM Change & MBW",
            description=(
                "Recalculate L/W/H, DIM volume and rated weights for a new DIM "
                "factor, then apply UA / OS / AHS minimum billable weights."
            ),
            render=dim_mbw_ui.render,
        ),
        Process(
            key="multiweight",
            name="Multiweight Re-Rating",
            description=(
                "Group Ground shipments into Multiweight tags, rate them "
                "against the tier rate table, and re-rate every other "
                "service the way Rate Comparison does."
            ),
            render=multiweight_ui.render,
        ),
        # Surcharge Analysis is no longer a standalone sidebar entry - it
        # runs as an optional step inside Rate Comparison and DIM Change &
        # MBW's own "Surcharges" tab (see ui/surcharge_ui.py::SurchargeStep).
        #
        # Zone Change Analysis is queued but not yet built - hidden from the
        # sidebar for the current version. Re-add a Process(...,
        # render=_planned("<name>"), status="planned") entry here when it's
        # ready to surface again.
    ]


def _planned(name: str):
    def render() -> None:
        import streamlit as st

        st.header(name)
        st.info(
            f"**{name}** is next in the build queue. The Rate Comparison "
            "module is live - its cleansing, rate-sheet parser and formula "
            "builders are shared, so this process plugs straight into them."
        )
    return render


PROCESSES: List[Process] = []


def get_processes() -> List[Process]:
    global PROCESSES
    if not PROCESSES:
        PROCESSES = _load()
    return PROCESSES
