"""
Process 4 - Multiweight Re-Rating ("Multiweight ReRating")

Ground shipments to the same destination on the same day are aggregated into
one "Tag" and, once the aggregate clears the customer-agreement minimums,
billed at a lower per-pound Multiweight (MWT) tier rate instead of
package-by-package - see ``core.multiweight`` for the exact formula. Every
other service is rated exactly as Rate Comparison would (same mapping,
missing-rate handling, heavyweight logic - reused verbatim), since a
Multiweight request is still a full rate comparison with one extra step
layered on top of the Ground service.

Output tabs
-----------
Summary                    notes, MWT terms, service table (Ground/MWT
                            combined into one row, every other service its
                            own), Impact, disclaimer
Shipment Data               one row per shipment - single-piece cost, Tag,
                            MWT Cost/lb, Least Cost, Rated/DNR
Current MWT Calculation     one row per Tag (Ground-family only) - Current
                            side: pieces, weight, tier, billed/deficit
                            weight, tier cost, least cost, cost/lb
Proposed MWT Calculation    the same, Proposed side
MWT Rules                   customer-agreement terms, tier boundaries and
                            per-zone tier rate / minimum charge - both sides
current_rates / proposed_rates   embedded Net Rate Sheets (+ AS rows, helper column)
Zone Map                    alpha -> numeric zone reference
"""

from __future__ import annotations

from dataclasses import dataclass, field
from io import BytesIO
from typing import Dict, List, Optional, Tuple

import openpyxl
import pandas as pd
from openpyxl.utils import get_column_letter

from core import formulas as F
from core import multiweight as M
from core.config import (
    COL,
    FMT_INT,
    FMT_MONEY,
    FMT_MONEY_2DP,
    FMT_PCT_1DP,
    SUMMARY_SERVICE_ORDER,
)
from core.evaluate import build_grids, evaluate
from core.excel_writer import (
    BOLD,
    BOX,
    TITLE_FONT,
    autosize,
    mark_total_row,
    new_workbook,
    style_header_row,
    write_disclaimer,
    write_notes_block,
    write_zone_map,
)
from core.ratesheet import RateBlock
from core.shipment import (
    CleanseOptions,
    CleanseReport,
    add_normalised_zone,
    cleanse,
    date_range_label,
)
from processes import rate_comparison as rc

PROCESS_NAME = "Multiweight Re-Rating"
PROCESS_DESCRIPTION = (
    "Aggregate Ground shipments to the same destination on the same day into "
    "Multiweight tags, rate them against the tier rate table, and re-rate "
    "every other service the same way Rate Comparison does."
)

DETAIL_SHEET = "Shipment Data"
CUR_CALC_SHEET = "Current MWT Calculation"
PRO_CALC_SHEET = "Proposed MWT Calculation"
RULES_SHEET = "MWT Rules"
ZONE_SHEET = "Zone Map"
CURRENT_SHEET = rc.CURRENT_SHEET
PROPOSED_SHEET = rc.PROPOSED_SHEET
LIST_SHEET = rc.LIST_SHEET

MWT_SUMMARY_LABEL = "Ground / MWT"


# ==========================================================================
@dataclass
class MultiweightConfig:
    # drop_multi_piece defaults to False here (unlike every other process) -
    # multi-piece shipments are exactly what Multiweight groups and rates,
    # so dropping them would silently strip out the process's own subject.
    cleanse: CleanseOptions = field(
        default_factory=lambda: CleanseOptions(drop_multi_piece=False))
    mappings: Dict[str, rc.ServiceMapping] = field(default_factory=dict)

    # Products pooled into the Tag/MWT grouping - Ground plus whatever else
    # the customer agreement's Multiweight terms cover (Home Delivery is
    # opt-in per the procedure, so it is not in the default list).
    mwt_products: List[str] = field(
        default_factory=lambda: list(M.DEFAULT_MWT_PRODUCTS))

    current_tiers: List[M.MWTTier] = field(default_factory=M.default_tiers)
    proposed_tiers: List[M.MWTTier] = field(default_factory=M.default_tiers)
    terms: M.MWTTerms = field(default_factory=M.MWTTerms)

    analysis_notes: List[str] = field(default_factory=list)
    date_range: str = ""
    cht_id: str = ""

    heavy_method: str = rc.HEAVY_AUTO
    heavy_threshold: float = rc.STANDARD_MAX_WEIGHT
    write_per_pound_rows: bool = True

    # Same missing-Proposed-rate handling as Rate Comparison, for every
    # non-Ground service rated the standard way.
    missing_proposed: Dict[str, str] = field(default_factory=dict)
    list_rates_for_current: Dict[str, bool] = field(default_factory=dict)
    list_fallback: Dict[str, str] = field(default_factory=dict)

    write_formulas: bool = True


# ==========================================================================
# MWT Rules tab
# ==========================================================================
class RulesRefs:
    """Absolute A1 references into the MWT Rules tab."""

    def __init__(self, sheet: str = RULES_SHEET):
        self.sheet = sheet
        self.terms_avg = ""
        self.terms_min_ship = ""
        self.current_bounds_range = ""
        self.proposed_bounds_range = ""
        # (first_row, last_row) of the per-zone rate table, so a caller can
        # build a SUMIFS over any one column (B=Tier Min Wt, C=Zone,
        # D=Rate/lb, E=Min Charge) sharing those same row bounds.
        self.current_rate_rows: Tuple[int, int] = (0, 0)
        self.proposed_rate_rows: Tuple[int, int] = (0, 0)

    def col(self, letter: str, rows: Tuple[int, int]) -> str:
        """A single-column range within the rate table, quoted and ready
        to drop into a SUMIFS."""
        first, last = rows
        return self.cell(f"${letter}${first}:${letter}${last}")

    def cell(self, ref: str) -> str:
        # Quoted: "MWT Rules" has a space, and an unquoted multi-word sheet
        # name in a formula is invalid Excel syntax (#NAME? error) - the
        # same class of bug already fixed once this session for "Surcharge
        # Rules". Never remove these quotes.
        return f"'{self.sheet}'!{ref}"


def _write_rules(wb, config: MultiweightConfig) -> RulesRefs:
    ws = wb.create_sheet(RULES_SHEET)
    refs = RulesRefs()

    ws["B1"] = "MWT Rules & terms"
    ws["B1"].font = TITLE_FONT
    ws["B2"] = ("Every figure on this tab is referenced by the MWT "
                "Calculation tabs — change one here and the workbook "
                "recalculates.")
    ws["B2"].font = BOLD

    r = 4
    ws.cell(row=r, column=2, value="Customer agreement terms").font = BOLD
    r += 1
    ws.cell(row=r, column=2, value="Minimum Average Package Weight (lbs)")
    ws.cell(row=r, column=3,
            value=float(config.terms.minimum_average_package_weight)
            ).number_format = FMT_INT
    refs.terms_avg = f"$C${r}"
    r += 1
    ws.cell(row=r, column=2, value="Minimum Shipment Weight (lbs)")
    ws.cell(row=r, column=3,
            value=float(config.terms.minimum_shipment_weight)
            ).number_format = FMT_INT
    refs.terms_min_ship = f"$C${r}"
    r += 2

    def write_bounds(title: str, tiers: List[M.MWTTier]) -> str:
        nonlocal r
        ws.cell(row=r, column=2, value=title).font = BOLD
        r += 1
        head = r
        for j, h in enumerate(["Min Weight", "Max Weight", "Label"]):
            ws.cell(row=head, column=2 + j, value=h)
        style_header_row(ws, head, 2, 4)
        r = head + 1
        first = r
        for t in tiers:
            ws.cell(row=r, column=2, value=float(t.min_weight)
                    ).number_format = FMT_INT
            if t.max_weight is not None:
                ws.cell(row=r, column=3, value=float(t.max_weight)
                        ).number_format = FMT_INT
            else:
                ws.cell(row=r, column=3, value="open")
            ws.cell(row=r, column=4, value=t.label)
            for c in range(2, 5):
                ws.cell(row=r, column=c).border = BOX
            r += 1
        bounds_range = f"$B${first}:$D${r - 1}"
        r += 1
        return bounds_range

    refs.current_bounds_range = write_bounds(
        "Current tier boundaries", config.current_tiers)
    refs.proposed_bounds_range = write_bounds(
        "Proposed tier boundaries", config.proposed_tiers)

    def write_rate_table(title: str, tiers: List[M.MWTTier]) -> Tuple[int, int]:
        nonlocal r
        ws.cell(row=r, column=2, value=title).font = BOLD
        r += 1
        head = r
        for j, h in enumerate(["Tier Min Wt", "Zone", "Rate/lb", "Min Charge"]):
            ws.cell(row=head, column=2 + j, value=h)
        style_header_row(ws, head, 2, 5)
        r = head + 1
        first = r
        for t in tiers:
            for z in M.ZONES:
                ws.cell(row=r, column=2, value=float(t.min_weight)
                        ).number_format = FMT_INT
                ws.cell(row=r, column=3, value=z)
                ws.cell(row=r, column=4,
                        value=float(t.rate_per_lb.get(z, 0.0) or 0.0)
                        ).number_format = "0.0000"
                ws.cell(row=r, column=5,
                        value=float(t.min_charge.get(z, 0.0) or 0.0)
                        ).number_format = FMT_MONEY_2DP
                for c in range(2, 6):
                    ws.cell(row=r, column=c).border = BOX
                r += 1
        rows = (first, r - 1)
        r += 1
        return rows

    refs.current_rate_rows = write_rate_table(
        "Current tier rate & minimum charge (per zone)", config.current_tiers)
    refs.proposed_rate_rows = write_rate_table(
        "Proposed tier rate & minimum charge (per zone)", config.proposed_tiers)

    autosize(ws, {2: 26, 3: 14, 4: 22, 5: 14})
    ws.sheet_view.showGridLines = False
    return refs


# ==========================================================================
# Shipment Data tab - single-piece rating (reusing Rate Comparison's
# mapping/formula machinery verbatim) plus the Tag column
# ==========================================================================
DETAIL_HEADERS = [
    "ID", "Tracking Number", "Product Name", "OpCo", "Package Type",
    "Zone", "Zone (Numeric)", "Rated Weight (Lbs)", "Pieces", "Shipments",
    "Tag",
    "Current Cost", "Proposed Cost", "Current Method", "Proposed Method",
    "Proposed Rate Source",
    "Current MWT Cost/lb", "Proposed MWT Cost/lb",
    "Current Least Cost", "Proposed Least Cost",
    "Cost Impact", "Rated",
]
C = {name: i + 1 for i, name in enumerate(DETAIL_HEADERS)}


def _f(value, default=None) -> Optional[float]:
    v = pd.to_numeric(value, errors="coerce")
    return float(v) if pd.notna(v) else default


def _write_detail(ws, df: pd.DataFrame, mappings: Dict[str, rc.ServiceMapping],
                  helper_for, grids, config: MultiweightConfig) -> dict:
    """Every service rated single-piece, exactly like Rate Comparison, plus
    the Tag each row needs for the MWT grouping that follows."""
    for j, h in enumerate(DETAIL_HEADERS, start=1):
        ws.cell(row=1, column=j, value=h)
    style_header_row(ws, 1, 1, len(DETAIL_HEADERS))
    ws.freeze_panes = "D2"

    def get(row, key):
        return row.get(COL[key]) if COL[key] in df.columns else None

    def L(name: str) -> str:
        return get_column_letter(C[name])

    mwt_products_low = {p.strip().lower() for p in config.mwt_products}
    write_formulas = config.write_formulas

    records: List[dict] = []
    r = 2
    for i, (_, row) in enumerate(df.iterrows(), start=1):
        product = str(get(row, "product") or "").strip()
        opco = str(get(row, "opco") or "").strip()
        pkg = str(get(row, "package_type") or "").strip()
        zone_raw = get(row, "zone")
        zone_num = row.get("Zone (Numeric)")
        zf = float(zone_num) if pd.notna(zone_num) else None
        weight = _f(get(row, "rated_weight"), 0.0)
        pieces = _f(get(row, "pieces"), 1.0)
        shipments = _f(get(row, "shipments"), 1.0)

        tag = M.make_tag(get(row, "ship_date"), get(row, "origin_zip"),
                         get(row, "recipient_addr"), get(row, "recipient_postal"))

        ws.cell(row=r, column=C["ID"], value=i)
        ws.cell(row=r, column=C["Tracking Number"],
                value=str(get(row, "tracking") or ""))
        ws.cell(row=r, column=C["Product Name"], value=product)
        ws.cell(row=r, column=C["OpCo"], value=opco)
        ws.cell(row=r, column=C["Package Type"], value=pkg)
        ws.cell(row=r, column=C["Zone"],
                value=zone_raw if zone_raw is not None else "")
        ws.cell(row=r, column=C["Zone (Numeric)"], value=zf)
        ws.cell(row=r, column=C["Rated Weight (Lbs)"], value=weight)
        ws.cell(row=r, column=C["Pieces"], value=pieces)
        ws.cell(row=r, column=C["Shipments"], value=shipments)
        ws.cell(row=r, column=C["Tag"], value=tag)

        # ---- standard single-piece rating - identical to Rate Comparison
        m = mappings.get(product) or rc.ServiceMapping(product=product)
        z_ref = f"${L('Zone (Numeric)')}{r}"
        w_ref = f"${L('Rated Weight (Lbs)')}{r}"
        cur_plan = rc.plan_rate(m.current_block, m.current_heavy, pkg, weight,
                                config.heavy_method, config.heavy_threshold)
        pro_plan = rc.plan_rate(m.proposed_block, m.proposed_heavy, pkg, weight,
                                config.heavy_method, config.heavy_threshold)
        cur_f = rc.formula_for(cur_plan, helper_for, w_ref, z_ref)
        pro_f = rc.formula_for(pro_plan, helper_for, w_ref, z_ref)
        cur_val = evaluate(cur_plan, grids, weight, zf) if grids else None
        pro_val = evaluate(pro_plan, grids, weight, zf) if grids else None

        if write_formulas:
            c1 = ws.cell(row=r, column=C["Current Cost"],
                        value=F.wrap_iferror(cur_f) if cur_f else None)
            c2 = ws.cell(row=r, column=C["Proposed Cost"],
                        value=F.wrap_iferror(pro_f) if pro_f else None)
        else:
            c1 = ws.cell(row=r, column=C["Current Cost"],
                        value=cur_val if cur_f else None)
            c2 = ws.cell(row=r, column=C["Proposed Cost"],
                        value=pro_val if pro_f else None)
        c1.number_format = FMT_MONEY_2DP
        c2.number_format = FMT_MONEY_2DP

        ws.cell(row=r, column=C["Current Method"], value=cur_plan.note)
        ws.cell(row=r, column=C["Proposed Method"], value=pro_plan.note)
        ws.cell(row=r, column=C["Proposed Rate Source"],
                value=rc.PROPOSED_SOURCE_LABELS.get(m.proposed_source,
                                                    m.proposed_source))

        records.append({
            "Row": r, "Product Name": product, "OpCo": opco, "Tag": tag,
            "Zone (Numeric)": zf, "Rated Weight (Lbs)": weight,
            "Pieces": pieces, "Shipments": shipments,
            "Current Cost": cur_val, "Proposed Cost": pro_val,
            "MWT Eligible Product": product.strip().lower() in mwt_products_low,
            "Rated": bool(cur_f and pro_f),
        })
        r += 1

    widths = {C[n]: w for n, w in (
        ("ID", 6), ("Tracking Number", 17), ("Product Name", 19), ("OpCo", 10),
        ("Package Type", 19), ("Zone", 7), ("Zone (Numeric)", 13),
        ("Rated Weight (Lbs)", 16), ("Pieces", 8), ("Shipments", 10),
        ("Tag", 30), ("Current Cost", 13), ("Proposed Cost", 14),
        ("Current Method", 30), ("Proposed Method", 30),
        ("Proposed Rate Source", 26),
        ("Current MWT Cost/lb", 16), ("Proposed MWT Cost/lb", 17),
        ("Current Least Cost", 16), ("Proposed Least Cost", 17),
        ("Cost Impact", 12), ("Rated", 9))}
    autosize(ws, widths)
    ws.auto_filter.ref = f"A1:{get_column_letter(len(DETAIL_HEADERS))}{r - 1}"

    return {"sheet": ws.title, "first_row": 2, "last_row": max(r - 1, 2),
            "frame": pd.DataFrame(records)}


# ==========================================================================
# MWT Calculation tabs - one row per Tag, Ground-family products only
# ==========================================================================
CALC_HEADERS = [
    "Tag", "Zone", "Service", "Pieces", "Weight", "Single-Piece Cost",
    "Tier Min Wt", "Billed Weight", "Deficit Weight", "Rate/lb", "Min Charge",
    "Tier Cost", "Least Cost", "Cost/lb",
]
CC = {name: i + 2 for i, name in enumerate(CALC_HEADERS)}


def _write_calc_tab(ws, title: str, frame: pd.DataFrame, cost_col: str,
                    dsheet: str, d_first: int, d_last: int,
                    bounds_range: str, rate_rows: Tuple[int, int],
                    refs: RulesRefs, tiers: List[M.MWTTier],
                    terms: M.MWTTerms, write_formulas: bool) -> dict:
    ws.cell(row=1, column=2, value=title).font = TITLE_FONT
    ws.cell(row=2, column=2,
            value="One row per Tag (Ground-family shipments only). Blank "
                  "Tier Min Wt = below the first tier, rated as plain "
                  "Ground.").font = BOLD

    head = 4
    for j, h in enumerate(CALC_HEADERS):
        ws.cell(row=head, column=2 + j, value=h)
    style_header_row(ws, head, 2, 2 + len(CALC_HEADERS) - 1)

    eligible = frame[frame["MWT Eligible Product"]]
    if eligible.empty:
        autosize(ws, {2: 30, 3: 8})
        ws.sheet_view.showGridLines = False
        return {"sheet": ws.title, "first_row": head + 1, "last_row": head,
                "tag_row": {}, "results": {}}

    groups = eligible.groupby("Tag", as_index=False).agg(
        Zone=("Zone (Numeric)", "first"),
        Pieces=("Pieces", "sum"),
        Weight=("Rated Weight (Lbs)", "sum"),
        SinglePiece=(cost_col, lambda s: s.sum(min_count=1)),
    )

    zone_col = get_column_letter(CC["Zone"])

    def L(name: str) -> str:
        return get_column_letter(CC[name])

    r = head + 1
    tag_row: Dict[str, int] = {}
    results: Dict[str, "M.GroupResult"] = {}
    for _, g in groups.iterrows():
        tag, zone = g["Tag"], g["Zone"]
        zone_str = "" if pd.isna(zone) else f"{zone:g}"
        weight_v = float(g["Weight"]) if pd.notna(g["Weight"]) else 0.0
        pieces_v = float(g["Pieces"]) if pd.notna(g["Pieces"]) else 0.0
        sp_v = float(g["SinglePiece"]) if pd.notna(g["SinglePiece"]) else None
        # Computed in Python either way - the on-screen preview and the
        # Summary tab's Python frame need these values even when the cells
        # themselves hold formulas.
        results[tag] = M.rate_group(tag, zone_str, pieces_v, weight_v, sp_v,
                                    tiers, terms)

        tag_row[tag] = r
        ws.cell(row=r, column=CC["Tag"], value=tag)
        ws.cell(row=r, column=CC["Zone"], value=zone_str)

        if write_formulas:
            tag_ref = f"${L('Tag')}{r}"
            ws.cell(row=r, column=CC["Pieces"],
                    value=F.sumifs(dsheet, get_column_letter(C["Pieces"]),
                                   get_column_letter(C["Tag"]), tag_ref,
                                   d_first, d_last)).number_format = FMT_INT
            ws.cell(row=r, column=CC["Weight"],
                    value=F.sumifs(dsheet,
                                   get_column_letter(C["Rated Weight (Lbs)"]),
                                   get_column_letter(C["Tag"]), tag_ref,
                                   d_first, d_last)).number_format = FMT_INT
            cost_dcol = get_column_letter(
                C["Current Cost"] if cost_col == "Current Cost"
                else C["Proposed Cost"])
            ws.cell(row=r, column=CC["Single-Piece Cost"],
                    value=F.sumifs(dsheet, cost_dcol,
                                   get_column_letter(C["Tag"]), tag_ref,
                                   d_first, d_last)
                    ).number_format = FMT_MONEY_2DP

            weight_ref = f"${L('Weight')}{r}"
            pieces_ref = f"${L('Pieces')}{r}"
            sp_ref = f"${L('Single-Piece Cost')}{r}"
            zone_ref = f"${zone_col}{r}"

            tier_min = (f"=IFERROR(VLOOKUP({weight_ref},{refs.cell(bounds_range)},"
                       f"1,TRUE),\"\")")
            ws.cell(row=r, column=CC["Tier Min Wt"], value=tier_min)
            tmin_ref = f"${L('Tier Min Wt')}{r}"

            ws.cell(row=r, column=CC["Service"],
                    value=f'=IF({tmin_ref}="","GR","MWT")')
            service_ref = f"${L('Service')}{r}"

            # "Raw" billed weight (aggregate vs. the two agreement floors,
            # before the tier floor is applied) is inlined into both
            # formulas below rather than round-tripped through a cell -
            # writing it to Billed Weight and then overwriting that same
            # cell with the deficit-inclusive figure would leave Deficit
            # Weight's cell reference silently reading the *new* formula
            # once Excel recalculates, not the value it was built from.
            avg_floor = f"{refs.cell(refs.terms_avg)}*{pieces_ref}"
            min_ship = refs.cell(refs.terms_min_ship)
            raw_billed = f"MAX({weight_ref},{avg_floor},{min_ship})"

            ws.cell(row=r, column=CC["Deficit Weight"],
                    value=(f'=IF({service_ref}="MWT",'
                          f"MAX(0,{tmin_ref}-{raw_billed}),0)")
                    ).number_format = FMT_INT

            ws.cell(row=r, column=CC["Billed Weight"],
                    value=(f'=IF({service_ref}="MWT",'
                          f"MAX({raw_billed},{tmin_ref}),{weight_ref})")
                    ).number_format = FMT_INT
            billed_ref = f"${L('Billed Weight')}{r}"

            tier_col = refs.col("B", rate_rows)
            zone_col_range = refs.col("C", rate_rows)
            rate_col = refs.col("D", rate_rows)
            charge_col = refs.col("E", rate_rows)

            rate_formula = (
                f'=IF({service_ref}="MWT",'
                f"SUMIFS({rate_col},{tier_col},{tmin_ref},"
                f"{zone_col_range},{zone_ref}),\"\")")
            ws.cell(row=r, column=CC["Rate/lb"], value=rate_formula
                    ).number_format = "0.0000"
            rate_ref = f"${L('Rate/lb')}{r}"

            charge_formula = (
                f'=IF({service_ref}="MWT",'
                f"SUMIFS({charge_col},{tier_col},{tmin_ref},"
                f"{zone_col_range},{zone_ref}),\"\")")
            ws.cell(row=r, column=CC["Min Charge"], value=charge_formula
                    ).number_format = FMT_MONEY_2DP
            charge_ref = f"${L('Min Charge')}{r}"

            tier_cost_formula = (
                f'=IF({service_ref}="MWT",'
                f"MAX({billed_ref}*{rate_ref},{charge_ref}),\"\")")
            ws.cell(row=r, column=CC["Tier Cost"], value=tier_cost_formula
                    ).number_format = FMT_MONEY_2DP
            tier_cost_ref = f"${L('Tier Cost')}{r}"

            least_cost_formula = (
                f'=IF({service_ref}="MWT",'
                f'IF(ISNUMBER({sp_ref}),MIN({tier_cost_ref},{sp_ref}),'
                f"{tier_cost_ref}),{sp_ref})")
            ws.cell(row=r, column=CC["Least Cost"], value=least_cost_formula
                    ).number_format = FMT_MONEY_2DP
            least_cost_ref = f"${L('Least Cost')}{r}"

            ws.cell(row=r, column=CC["Cost/lb"],
                    value=f"=IFERROR({least_cost_ref}/{billed_ref},\"\")"
                    ).number_format = "0.0000"

            for c in range(2, 2 + len(CALC_HEADERS)):
                ws.cell(row=r, column=c).border = BOX
            r += 1
        else:
            gr = results[tag]
            ws.cell(row=r, column=CC["Pieces"], value=pieces_v
                    ).number_format = FMT_INT
            ws.cell(row=r, column=CC["Weight"], value=weight_v
                    ).number_format = FMT_INT
            ws.cell(row=r, column=CC["Single-Piece Cost"], value=sp_v
                    ).number_format = FMT_MONEY_2DP

            ws.cell(row=r, column=CC["Service"],
                    value="MWT" if gr.is_mwt else "GR")
            ws.cell(row=r, column=CC["Tier Min Wt"],
                    value=float(gr.tier.min_weight) if gr.tier else None
                    ).number_format = FMT_INT
            ws.cell(row=r, column=CC["Billed Weight"], value=gr.billed_weight
                    ).number_format = FMT_INT
            ws.cell(row=r, column=CC["Deficit Weight"], value=gr.deficit_weight
                    ).number_format = FMT_INT
            rate_v = (gr.tier.rate_per_lb.get(zone_str, 0.0) if gr.tier else None)
            mc_v = (gr.tier.min_charge.get(zone_str, 0.0) if gr.tier else None)
            ws.cell(row=r, column=CC["Rate/lb"], value=rate_v
                    ).number_format = "0.0000"
            ws.cell(row=r, column=CC["Min Charge"], value=mc_v
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=CC["Tier Cost"], value=gr.tier_cost
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=CC["Least Cost"], value=gr.least_cost
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=CC["Cost/lb"], value=gr.cost_per_lb
                    ).number_format = "0.0000"
            for c in range(2, 2 + len(CALC_HEADERS)):
                ws.cell(row=r, column=c).border = BOX
            r += 1

    last_row = r - 1
    autosize(ws, {2: 30, 3: 8, 4: 10, 5: 10, 6: 10, 7: 16, 8: 12, 9: 14,
                  10: 14, 11: 10, 12: 12, 13: 12, 14: 12, 15: 10})
    ws.sheet_view.showGridLines = False
    return {"sheet": ws.title, "first_row": head + 1, "last_row": last_row,
            "tag_row": tag_row, "results": results}


# ==========================================================================
# Second pass over Shipment Data - MWT Cost/lb, Least Cost, Rated/DNR, once
# the MWT Calculation tabs exist to look back into
# ==========================================================================
def _lookup_formula(tag_ref: str, calc: dict, col_name: str, fallback: str
                    ) -> str:
    if calc["last_row"] < calc["first_row"]:
        return fallback
    tag_col = get_column_letter(CC["Tag"])
    val_col = get_column_letter(CC[col_name])
    rng = (f"'{calc['sheet']}'!${tag_col}${calc['first_row']}:"
          f"${val_col}${calc['last_row']}")
    col_index = CC[col_name] - CC["Tag"] + 1
    return f"=IFERROR(VLOOKUP({tag_ref},{rng},{col_index},FALSE),{fallback})"


def _write_mwt_lookback(ws, detail: dict, cur_calc: dict, pro_calc: dict,
                        write_formulas: bool) -> pd.DataFrame:
    """Fills Current/Proposed MWT Cost/lb, Least Cost, Cost Impact and
    Rated/DNR back onto Shipment Data, and returns the frame with those
    columns added (for the Summary tab and the on-screen preview)."""
    frame = detail["frame"].copy()
    cur_least: List[Optional[float]] = []
    pro_least: List[Optional[float]] = []
    cur_cpl: List[Optional[float]] = []
    pro_cpl: List[Optional[float]] = []
    rated: List[str] = []

    def L(name: str) -> str:
        return get_column_letter(C[name])

    for _, rec in frame.iterrows():
        r = int(rec["Row"])
        tag = rec["Tag"]
        weight = rec["Rated Weight (Lbs)"]
        cur_cost, pro_cost = rec["Current Cost"], rec["Proposed Cost"]

        if write_formulas:
            tag_ref = f"${L('Tag')}{r}"
            weight_ref = f"${L('Rated Weight (Lbs)')}{r}"
            cur_cost_ref = f"${L('Current Cost')}{r}"
            pro_cost_ref = f"${L('Proposed Cost')}{r}"

            ws.cell(row=r, column=C["Current MWT Cost/lb"],
                    value=_lookup_formula(tag_ref, cur_calc, "Cost/lb", '""')
                    ).number_format = "0.0000"
            ws.cell(row=r, column=C["Proposed MWT Cost/lb"],
                    value=_lookup_formula(tag_ref, pro_calc, "Cost/lb", '""')
                    ).number_format = "0.0000"

            # Procedure: "Current Least Cost = Current Cost/lb x Current
            # Weight" - the group's blended Cost/lb is allocated back to
            # each package by its own weight, not the group's flat total
            # repeated on every row.
            cur_cpl_ref = f"${L('Current MWT Cost/lb')}{r}"
            pro_cpl_ref = f"${L('Proposed MWT Cost/lb')}{r}"
            ws.cell(row=r, column=C["Current Least Cost"],
                    value=(f"=IF(ISNUMBER({cur_cpl_ref}),"
                          f"{cur_cpl_ref}*{weight_ref},{cur_cost_ref})")
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=C["Proposed Least Cost"],
                    value=(f"=IF(ISNUMBER({pro_cpl_ref}),"
                          f"{pro_cpl_ref}*{weight_ref},{pro_cost_ref})")
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=C["Cost Impact"],
                    value=f"=IFERROR(${L('Proposed Least Cost')}{r}"
                          f"-${L('Current Least Cost')}{r},\"\")"
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=C["Rated"],
                    value=f'=IF(AND(ISNUMBER(${L("Current Least Cost")}{r}),'
                          f'ISNUMBER(${L("Proposed Least Cost")}{r})),'
                          f'"Rated","DNR")')
        else:
            cur_gr = cur_calc["results"].get(tag)
            pro_gr = pro_calc["results"].get(tag)
            c_cpl = cur_gr.cost_per_lb if cur_gr else None
            p_cpl = pro_gr.cost_per_lb if pro_gr else None
            cur_lc = (c_cpl * weight) if c_cpl is not None else cur_cost
            pro_lc = (p_cpl * weight) if p_cpl is not None else pro_cost
            impact = ((pro_lc - cur_lc)
                     if (cur_lc is not None and pro_lc is not None) else None)
            is_rated = cur_lc is not None and pro_lc is not None

            ws.cell(row=r, column=C["Current MWT Cost/lb"], value=c_cpl
                    ).number_format = "0.0000"
            ws.cell(row=r, column=C["Proposed MWT Cost/lb"], value=p_cpl
                    ).number_format = "0.0000"
            ws.cell(row=r, column=C["Current Least Cost"], value=cur_lc
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=C["Proposed Least Cost"], value=pro_lc
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=C["Cost Impact"], value=impact
                    ).number_format = FMT_MONEY_2DP
            ws.cell(row=r, column=C["Rated"],
                    value="Rated" if is_rated else "DNR")

        # Always compute the Python figures for the frame - the on-screen
        # preview needs them even when the cells hold formulas.
        gr_c = cur_calc["results"].get(tag)
        gr_p = pro_calc["results"].get(tag)
        c_cpl2 = gr_c.cost_per_lb if gr_c else None
        p_cpl2 = gr_p.cost_per_lb if gr_p else None
        cl = (c_cpl2 * weight) if c_cpl2 is not None else cur_cost
        pl = (p_cpl2 * weight) if p_cpl2 is not None else pro_cost
        cur_least.append(cl)
        pro_least.append(pl)
        cur_cpl.append(c_cpl2)
        pro_cpl.append(p_cpl2)
        rated.append("Rated" if (cl is not None and pl is not None) else "DNR")

    frame["Current Least Cost"] = cur_least
    frame["Proposed Least Cost"] = pro_least
    frame["Current MWT Cost/lb"] = cur_cpl
    frame["Proposed MWT Cost/lb"] = pro_cpl
    frame["Rated (MWT)"] = rated
    return frame


# ==========================================================================
# Summary tab
# ==========================================================================
def summary_frame(frame: pd.DataFrame, mwt_products: List[str]) -> pd.DataFrame:
    """
    Service table for the Summary tab and the on-screen preview - every
    Ground-family product (MWT-eligible or not) rolls into one
    ``MWT_SUMMARY_LABEL`` row, everything else keeps its own row, same as
    the standard SUMMARY_SERVICE_ORDER pattern elsewhere in the app.
    """
    if frame is None or frame.empty:
        return pd.DataFrame()

    low_set = {p.strip().lower() for p in mwt_products}
    work = frame.copy()
    work["_group"] = work["Product Name"].map(
        lambda p: MWT_SUMMARY_LABEL if str(p).strip().lower() in low_set
        else p)

    present = list(work["_group"].dropna().unique())
    ordered = ([MWT_SUMMARY_LABEL] if MWT_SUMMARY_LABEL in present else [])
    ordered += [s for s in SUMMARY_SERVICE_ORDER if s in present]
    ordered += [s for s in sorted(present) if s not in ordered]

    rows = []
    for svc in ordered:
        g = work[work["_group"] == svc]
        cur = g["Current Least Cost"].sum(min_count=1)
        pro = g["Proposed Least Cost"].sum(min_count=1)
        cur = 0.0 if pd.isna(cur) else float(cur)
        pro = 0.0 if pd.isna(pro) else float(pro)
        rows.append({
            "Service": svc,
            "Shipments": float(g["Shipments"].sum()),
            "Rated Wt": float(g["Rated Weight (Lbs)"].sum()),
            "Current Cost": cur, "Proposed Cost": pro,
            "Impact": pro - cur,
            "Impact %": (pro - cur) / cur if cur else 0.0,
        })

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    total = {
        "Service": "Total",
        "Shipments": out["Shipments"].sum(),
        "Rated Wt": out["Rated Wt"].sum(),
        "Current Cost": out["Current Cost"].sum(),
        "Proposed Cost": out["Proposed Cost"].sum(),
        "Impact": out["Impact"].sum(),
    }
    total["Impact %"] = (total["Impact"] / total["Current Cost"]
                         if total["Current Cost"] else 0.0)
    return pd.concat([out, pd.DataFrame([total])], ignore_index=True)


def _write_summary(ws, detail: dict, frame: pd.DataFrame,
                   report: CleanseReport, config: MultiweightConfig,
                   date_range: str, mappings: Dict[str, rc.ServiceMapping]
                   ) -> int:
    dsheet = detail["sheet"]

    ws["B1"] = "Multiweight Re-Rating Analysis"
    ws["B1"].font = TITLE_FONT

    r = 3
    if date_range:
        ws.cell(row=r, column=2,
                value=f"Shipment data date range: {date_range}").font = BOLD
        r += 1
    if config.cht_id:
        ws.cell(row=r, column=2,
                value=f"CHT / Group ID: {config.cht_id}").font = BOLD
        r += 1
    r += 1

    r = write_notes_block(ws, r, "Notes:", report.note_lines())

    extra_notes = list(config.analysis_notes)
    if not frame.empty:
        dnr = int((frame["Rated (MWT)"] == "DNR").sum())
        mwt_rows = int(
            frame["Product Name"].str.strip().str.lower().isin(
                {p.strip().lower() for p in config.mwt_products}).sum())
        extra_notes.append(
            f"{mwt_rows:,} Ground-family shipments grouped into Multiweight "
            f"tags and rated against the tier table; {dnr:,} shipments left "
            "as DNR (Do Not Rate).")
    for m in mappings.values():
        if m.proposed_missing and m.note:
            extra_notes.append(f"{m.product}: {m.note}")
    if extra_notes:
        r = write_notes_block(ws, r, "Assumptions & adjustments:", extra_notes)

    frame.attrs["notes"] = list(report.note_lines())
    frame.attrs["assumptions"] = extra_notes
    frame.attrs["date_range"] = date_range
    frame.attrs["cht_id"] = config.cht_id

    # ---- service table ---------------------------------------------------
    ws.cell(row=r, column=2, value="*** ESTIMATED Net Rate Cost ***").font = BOLD
    r += 1
    header_row = r
    headers = ["Service", "Shipments", "Rated Wt", "Current Cost",
               "Proposed Cost", "Impact", "Impact %"]
    for j, h in enumerate(headers):
        ws.cell(row=header_row, column=2 + j, value=h)
    style_header_row(ws, header_row, 2, 2 + len(headers) - 1)

    sf = summary_frame(frame, config.mwt_products)
    body_first = header_row + 1
    r = body_first
    for _, row in sf.iterrows():
        if row["Service"] == "Total":
            continue
        ws.cell(row=r, column=2, value=row["Service"])
        ws.cell(row=r, column=3, value=row["Shipments"]
                ).number_format = FMT_INT
        ws.cell(row=r, column=4, value=row["Rated Wt"]
                ).number_format = FMT_INT
        ws.cell(row=r, column=5, value=row["Current Cost"]
                ).number_format = FMT_MONEY
        ws.cell(row=r, column=6, value=row["Proposed Cost"]
                ).number_format = FMT_MONEY
        ws.cell(row=r, column=7, value=f"=F{r}-E{r}").number_format = FMT_MONEY
        ws.cell(row=r, column=8,
                value=f"=IFERROR(G{r}/E{r},0)").number_format = FMT_PCT_1DP
        for c in range(2, 9):
            ws.cell(row=r, column=c).border = BOX
        r += 1

    body_last = r - 1
    total_row = r
    ws.cell(row=total_row, column=2, value="Total")
    for col in ("C", "D", "E", "F", "G"):
        cell = ws.cell(row=total_row, column=ord(col) - 64,
                       value=f"=SUM({col}{body_first}:{col}{body_last})")
        cell.number_format = FMT_INT if col in ("C", "D") else FMT_MONEY
    ws.cell(row=total_row, column=8,
            value=f"=IFERROR(G{total_row}/E{total_row},0)"
            ).number_format = FMT_PCT_1DP
    mark_total_row(ws, total_row, 2, 8)

    r = total_row + 2
    autosize(ws, {2: 26, 3: 12, 4: 14, 5: 16, 6: 16, 7: 14, 8: 11})
    return r


# ==========================================================================
def run(shipment_df: pd.DataFrame,
        current_wb: openpyxl.Workbook, current_blocks: List[RateBlock],
        proposed_wb: openpyxl.Workbook, proposed_blocks: List[RateBlock],
        config: MultiweightConfig,
        list_wb: Optional[openpyxl.Workbook] = None,
        list_blocks: Optional[List[RateBlock]] = None,
        ) -> Tuple[BytesIO, CleanseReport, pd.DataFrame]:
    """
    Returns (workbook bytes, cleanse report, the rated detail frame).

    Every non-Ground service is rated exactly as Rate Comparison would -
    same mapping resolution, missing-Proposed-rate handling and heavyweight
    logic, reused verbatim. Ground-family shipments additionally get
    grouped into Multiweight tags and re-rated against the tier table; see
    ``core.multiweight`` for that formula.
    """
    wb = new_workbook()

    summary_ws = wb.create_sheet("Summary")
    detail_ws = wb.create_sheet(DETAIL_SHEET)
    cur_calc_ws = wb.create_sheet(CUR_CALC_SHEET)
    pro_calc_ws = wb.create_sheet(PRO_CALC_SHEET)
    zone_range = write_zone_map(wb, ZONE_SHEET)

    cur_sheets, cur_blocks = rc._embed(wb, current_wb, current_blocks,
                                       CURRENT_SHEET, config.write_per_pound_rows)
    pro_sheets, pro_blocks = rc._embed(wb, proposed_wb, proposed_blocks,
                                       PROPOSED_SHEET, config.write_per_pound_rows)
    lst_blocks: List[RateBlock] = []
    if list_wb is not None and list_blocks:
        _, lst_blocks = rc._embed(wb, list_wb, list_blocks, LIST_SHEET,
                                  config.write_per_pound_rows)

    helper_by_sheet: Dict[str, int] = {}
    for sheets in (cur_sheets, pro_sheets):
        for name, emb in sheets.items():
            helper_by_sheet[name] = emb.helper_col
    for name in wb.sheetnames:
        helper_by_sheet.setdefault(name, 20)

    def helper_for(block: RateBlock) -> int:
        return helper_by_sheet.get(block.sheet, 20)

    # --- mappings, resolved from the raw extract so an excluded-by-strategy
    # service can be folded into the cleanse below (same order Rate
    # Comparison and DIM Change & MBW use) ---------------------------------
    products_all = sorted(
        shipment_df[COL["product"]].astype(str).str.strip().unique()
    ) if COL["product"] in shipment_df.columns else []

    mappings = config.mappings or rc.build_default_mappings(
        products_all, cur_blocks, pro_blocks, lst_blocks)
    mappings = rc._rebind_mappings(mappings, cur_blocks, pro_blocks, lst_blocks)
    mappings, excluded = rc.apply_missing_strategies(
        mappings, config.missing_proposed, lst_blocks,
        config.list_rates_for_current, config.list_fallback)

    opts = config.cleanse
    if excluded:
        opts = CleanseOptions(**{**opts.__dict__})
        opts.excluded_products = list(
            dict.fromkeys(list(opts.excluded_products) + excluded))

    clean_df, report = cleanse(shipment_df, opts)
    clean_df = add_normalised_zone(clean_df)

    grids = build_grids(wb, [n for n in wb.sheetnames
                             if n.startswith((CURRENT_SHEET, PROPOSED_SHEET,
                                              LIST_SHEET))])

    detail = _write_detail(detail_ws, clean_df, mappings, helper_for, grids,
                           config)

    rules_refs = _write_rules(wb, config)

    cur_calc = _write_calc_tab(
        cur_calc_ws, CUR_CALC_SHEET, detail["frame"], "Current Cost",
        detail["sheet"], detail["first_row"], detail["last_row"],
        rules_refs.current_bounds_range, rules_refs.current_rate_rows,
        rules_refs, config.current_tiers, config.terms, config.write_formulas)
    pro_calc = _write_calc_tab(
        pro_calc_ws, PRO_CALC_SHEET, detail["frame"], "Proposed Cost",
        detail["sheet"], detail["first_row"], detail["last_row"],
        rules_refs.proposed_bounds_range, rules_refs.proposed_rate_rows,
        rules_refs, config.proposed_tiers, config.terms, config.write_formulas)

    frame = _write_mwt_lookback(detail_ws, detail, cur_calc, pro_calc,
                                config.write_formulas)

    date_range = config.date_range or date_range_label(clean_df)
    end_row = _write_summary(summary_ws, detail, frame, report, config,
                             date_range, mappings)
    write_disclaimer(summary_ws, end_row)

    wb.move_sheet("Summary", offset=-wb.sheetnames.index("Summary"))

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf, report, frame
