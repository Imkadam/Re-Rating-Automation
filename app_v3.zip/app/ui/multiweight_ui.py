"""Streamlit UI for the Multiweight Re-Rating process."""

from __future__ import annotations

from typing import Dict, List

import pandas as pd
import streamlit as st

from core import multiweight as M
from core.config import (
    COL,
    DISCLAIMER,
    LIST_FALLBACK_BLANK,
    LIST_FALLBACK_CURRENT,
    LIST_FALLBACK_LABELS,
    MISSING_EXCLUDE,
    MISSING_LEAVE_BLANK,
    MISSING_LIST_RATES,
    MISSING_STRATEGY_LABELS,
    MISSING_USE_CURRENT,
)
from core.ratesheet import RateBlock
from core.shipment import (
    CleanseOptions,
    default_excluded_products,
    list_sheets as excel_sheet_names,
    load_shipment_data,
)
from processes import multiweight as mw
from processes import rate_comparison as rc
from ui import theme

STATE = "mw"


def _s(key: str, default=None):
    return st.session_state.get(f"{STATE}__{key}", default)


def _set(key: str, value) -> None:
    st.session_state[f"{STATE}__{key}"] = value


# --------------------------------------------------------------------------
def render() -> None:
    theme.masthead(
        "Multiweight Re-Rating",
        "Group Ground shipments to the same destination on the same day "
        "into Multiweight tags, rate every other service the way Rate "
        "Comparison does, and re-rate both sides.",
    )

    t1, t2, t3, t4, t5 = st.tabs([
        "1 · Inputs", "2 · Rate sheet mapping", "3 · Missing rates",
        "4 · MWT setup", "5 · Build",
    ])
    with t1:
        _inputs()
    with t2:
        _mapping()
    with t3:
        _missing()
    with t4:
        _mwt_setup()
    with t5:
        _build()


# --------------------------------------------------------------------------
def _inputs() -> None:
    theme.section("Shipment data", "must carry Ship Date, Actual Origin Zip, "
                  "Recipient Address and Recipient Postal")
    theme.note(
        "Those four fields build the <b>Tag</b> that groups a multi-package "
        "shipment together — same shipment, same day, same destination."
    )

    f = st.file_uploader("Shipment Detail extract (.xlsx / .xlsm)",
                         type=["xlsx", "xlsm"], key="mw_ship_file")
    if f is not None:
        sheets = excel_sheet_names(f)
        idx = sheets.index("Shipment Data") if "Shipment Data" in sheets else 0
        sheet = st.selectbox("Worksheet holding the shipment rows", sheets,
                             index=idx, key="mw_ship_sheet")
        if st.button("Load shipment data", type="primary", key="mw_load"):
            with st.spinner("Reading shipment data…"):
                df = load_shipment_data(f, sheet)
            _set("df", df)
            _set("excluded", default_excluded_products(df))
            _set("mappings", None)
            st.success(f"Loaded {len(df):,} rows × {len(df.columns)} columns.")

    df = _s("df")
    if df is not None:
        c1, c2, c3 = st.columns(3)
        c1.metric("Rows", f"{len(df):,}")
        if COL["product"] in df.columns:
            c2.metric("Services", df[COL["product"]].nunique())
        missing_cols = [c for c in (COL["ship_date"], COL["origin_zip"],
                                    COL["recipient_addr"], COL["recipient_postal"])
                        if c not in df.columns]
        c3.metric("Tag columns present", f"{4 - len(missing_cols)}/4")
        if missing_cols:
            st.error("Missing columns needed for the Tag: "
                     + ", ".join(missing_cols))
        st.dataframe(df.head(15), use_container_width=True, height=220)

    theme.section("Net rate sheets", "raw FedEx ratesheet exports")
    c1, c2 = st.columns(2)
    with c1:
        cur = st.file_uploader("Current Net Rate Sheet",
                               type=["xlsx", "xlsm"], key="mw_cur_file")
        cur_sheets = _sheet_picker(cur, "cur")
    with c2:
        pro = st.file_uploader("Proposed Net Rate Sheet",
                               type=["xlsx", "xlsm"], key="mw_pro_file")
        pro_sheets = _sheet_picker(pro, "pro")

    with st.expander("Optional — List Rate Sheet", expanded=False):
        theme.rule(
            "Procedure, First Overnight: <i>“If the Current and Proposed Net "
            "Rate Sheets are from different years, use FO List Rates to rate "
            "the shipments.”</i> Upload it here to enable that option on the "
            "<b>Missing rates</b> tab."
        )
        list_file = st.file_uploader("List Rate Sheet",
                                     type=["xlsx", "xlsm"], key="mw_list_file")
        list_sheet_names = _sheet_picker(list_file, "list")

    theme.section("Cleansing")
    theme.note(
        "<b>Pieces greater than 1 stays off by default</b> for this process — "
        "multi-piece shipments are exactly what Multiweight groups and rates, "
        "dropping them would remove the process's own subject."
    )
    products = sorted(df[COL["product"]].astype(str).str.strip().unique()) \
        if df is not None and COL["product"] in df.columns else []
    excluded = st.multiselect("Product Names to exclude", products,
                              default=_s("excluded", []), key="mw_excluded")
    cc1, cc2 = st.columns(2)
    with cc1:
        zero = st.checkbox("USD List Freight Charge is $0 or blank", True,
                           key="mw_zero")
        zones = st.checkbox("Non-US Domestic zones (51, 00)", True, key="mw_z")
        pieces = st.checkbox("Pieces greater than 1", False, key="mw_pieces")
    with cc2:
        origin = st.checkbox("Origin Region is not US", True, key="mw_o")
        dest = st.checkbox("Destination Region is not US", True, key="mw_d")
    _set("opts", CleanseOptions(
        excluded_products=excluded, drop_zero_freight=zero,
        drop_non_us_zones=zones, drop_multi_piece=pieces,
        drop_non_us_origin=origin, drop_non_us_dest=dest,
        drop_over_150=False))

    if st.button("Parse rate sheets", disabled=not (cur and pro),
                key="mw_parse"):
        with st.spinner("Detecting rate tables…"):
            cur_wb, cur_blocks = rc.load_ratesheet_blocks(cur, cur_sheets)
            pro_wb, pro_blocks = rc.load_ratesheet_blocks(pro, pro_sheets)
            cur_info = rc.load_ratesheet_info(cur_wb, cur_sheets)
            pro_info = rc.load_ratesheet_info(pro_wb, pro_sheets)
            lst_wb = lst_blocks = None
            if list_file is not None:
                lst_wb, lst_blocks = rc.load_ratesheet_blocks(
                    list_file, list_sheet_names)
        for k, v in (("cur_wb", cur_wb), ("cur_blocks", cur_blocks),
                     ("pro_wb", pro_wb), ("pro_blocks", pro_blocks),
                     ("cur_info", cur_info), ("pro_info", pro_info),
                     ("lst_wb", lst_wb), ("lst_blocks", lst_blocks),
                     ("mappings", None), ("missing", None)):
            _set(k, v)
        st.success(
            f"Detected {len(cur_blocks)} Current and {len(pro_blocks)} "
            "Proposed rate tables."
            + (f" {len(lst_blocks)} List Rate tables." if lst_blocks else "")
        )

    if _s("cur_blocks"):
        with st.expander(f"Current rate tables detected ({len(_s('cur_blocks'))})"):
            st.dataframe(pd.DataFrame([
                {"Service": b.service, "Billing type": b.billing_type,
                 "Table": "per-lb / range" if b.is_per_pound else "standard"}
                for b in _s("cur_blocks")]), use_container_width=True)


def _sheet_picker(file, key: str):
    if file is None:
        return None
    try:
        names = excel_sheet_names(file)
    except Exception:
        return None
    if len(names) <= 1:
        return names
    return st.multiselect("Worksheets to scan", names, default=names,
                          key=f"mw_{key}_sheets") or names


# --------------------------------------------------------------------------
# Rate sheet mapping / missing rates - same mechanics as Rate Comparison
# --------------------------------------------------------------------------
def _index(blocks: List[RateBlock]):
    from core.ratesheet import index_blocks
    return index_blocks(blocks)


def _products() -> List[str]:
    df = _s("df")
    if df is None:
        return []
    products = sorted(df[COL["product"]].astype(str).str.strip().unique())
    opts = _s("opts")
    excluded = set(opts.excluded_products) if opts else set()
    return [p for p in products if p not in excluded]


def _ensure_mappings() -> Dict[str, rc.ServiceMapping]:
    if _s("mappings") is None:
        cur_info, pro_info = _s("cur_info"), _s("pro_info")
        _set("mappings", rc.build_default_mappings(
            _products(), _s("cur_blocks") or [], _s("pro_blocks") or [],
            _s("lst_blocks") or [],
            cur_info.effective_year if cur_info else None,
            pro_info.effective_year if pro_info else None,
        ))
    return _s("mappings")


def _mapping() -> None:
    if _s("df") is None or not _s("cur_blocks") or not _s("pro_blocks"):
        st.info("Load the shipment data and parse both rate sheets on the "
               "**Inputs** tab first.")
        return

    mappings = _ensure_mappings()
    theme.section("Which rate table rates each service?",
                  "auto-detected — override where the agreement differs")

    cur_blocks, pro_blocks = _s("cur_blocks"), _s("pro_blocks")
    cur_opts = ["— none —"] + [b.label for b in cur_blocks]
    pro_opts = ["— none —"] + [b.label for b in pro_blocks]
    cur_by = {b.label: b for b in cur_blocks}
    pro_by = {b.label: b for b in pro_blocks}

    for product in _products():
        m = mappings.get(product) or rc.ServiceMapping(product=product)
        if m.proposed_missing:
            head = f"**{product}**  ·  no Proposed table — see *Missing rates*"
        else:
            head = (f"**{product}**  ·  "
                    f"{m.current_block.label if m.current_block else 'no current table'}")
        with st.expander(head, expanded=m.current_block is None):
            c1, c2 = st.columns(2)
            with c1:
                cur = st.selectbox(
                    "Current — standard table", cur_opts,
                    index=cur_opts.index(m.current_block.label)
                    if m.current_block and m.current_block.label in cur_opts else 0,
                    key=f"mw_map_cur_{product}")
                curh = st.selectbox(
                    "Current — heavyweight / per-lb table", cur_opts,
                    index=cur_opts.index(m.current_heavy.label)
                    if m.current_heavy and m.current_heavy.label in cur_opts else 0,
                    key=f"mw_map_curh_{product}")
            with c2:
                pro = st.selectbox(
                    "Proposed — standard table", pro_opts,
                    index=pro_opts.index(m.proposed_block.label)
                    if m.proposed_block and m.proposed_block.label in pro_opts else 0,
                    key=f"mw_map_pro_{product}")
                proh = st.selectbox(
                    "Proposed — heavyweight / per-lb table", pro_opts,
                    index=pro_opts.index(m.proposed_heavy.label)
                    if m.proposed_heavy and m.proposed_heavy.label in pro_opts else 0,
                    key=f"mw_map_proh_{product}")

            picked_pro = pro_by.get(pro)
            mappings[product] = rc.ServiceMapping(
                product=product,
                current_block=cur_by.get(cur),
                proposed_block=picked_pro,
                current_heavy=cur_by.get(curh),
                proposed_heavy=pro_by.get(proh),
                proposed_missing=picked_pro is None,
                missing_strategy=m.missing_strategy,
            )
    _set("mappings", mappings)


def _missing() -> None:
    if _s("df") is None or not _s("cur_blocks") or not _s("pro_blocks"):
        st.info("Load the shipment data and parse both rate sheets on the "
               "**Inputs** tab first.")
        return

    mappings = _ensure_mappings()
    missing = [p for p, m in mappings.items() if m.proposed_missing]

    theme.section("Services missing from the Proposed rate sheet",
                  "procedure — First Overnight (FO) Shipments")
    theme.rule(
        "<i>“If Proposed Rates are unavailable and both Net Rate Sheets are "
        "from the same year, use the Current Rates as the Proposed Rates. "
        "If the Current and Proposed Net Rate Sheets are from different "
        "years, use FO List Rates to rate the shipments.”</i>"
    )

    if not missing:
        st.success(
            "Every service in the shipment data has a table on the Proposed "
            "rate sheet — nothing to decide here."
        )
        return

    cur_info, pro_info = _s("cur_info"), _s("pro_info")
    cy = cur_info.effective_year if cur_info else None
    py = pro_info.effective_year if pro_info else None
    have_list = bool(_s("lst_blocks"))

    if cy and py:
        same = cy == py
        theme.note(
            f"Current sheet <b>{cy}</b> · Proposed sheet <b>{py}</b> — "
            + ("<b>same year</b>, so the procedure points at "
               "<i>Current rates as Proposed</i>."
               if same else
               "<b>different years</b>, so the procedure points at "
               "<i>List Rates</i>.")
        )
    if not have_list:
        st.caption(
            "No List Rate Sheet uploaded — that option is disabled. Add one "
            "on the **Inputs** tab to enable it."
        )

    strategies: Dict[str, str] = dict(_s("missing") or {})
    list_for_current: Dict[str, bool] = dict(_s("missing_cur") or {})
    list_fallback: Dict[str, str] = dict(_s("missing_fb") or {})

    if len(missing) > 1:
        b1, b2 = st.columns([3, 1])
        with b1:
            bulk = st.selectbox(
                "Set every service below to…",
                ["— leave as they are —", MISSING_USE_CURRENT,
                 MISSING_LIST_RATES, MISSING_EXCLUDE, MISSING_LEAVE_BLANK],
                format_func=lambda k: (k if k.startswith("—")
                                       else MISSING_STRATEGY_LABELS[k]),
                key="mw_missing_bulk",
            )
        with b2:
            st.markdown("<div style='height:1.75rem'></div>",
                        unsafe_allow_html=True)
            if st.button("Apply to all", use_container_width=True,
                        key="mw_missing_bulk_apply"):
                if not bulk.startswith("—"):
                    for p in missing:
                        st.session_state.pop(f"mw_missing_{p}", None)
                        strategies[p] = bulk
                    _set("missing", strategies)
                    st.rerun()

    options = [MISSING_USE_CURRENT, MISSING_LIST_RATES,
               MISSING_EXCLUDE, MISSING_LEAVE_BLANK]

    for product in missing:
        m = mappings[product]
        default = strategies.get(product, m.missing_strategy
                                 or MISSING_LEAVE_BLANK)
        with st.container():
            st.markdown(
                f'<div class="fx-card"><b>{product}</b> — no table on the '
                f'Proposed rate sheet</div>', unsafe_allow_html=True)

            usable = [o for o in options
                     if not (o == MISSING_LIST_RATES and not have_list)
                     and not (o == MISSING_USE_CURRENT
                              and m.current_block is None)]
            if default not in usable:
                default = MISSING_LEAVE_BLANK

            choice = st.radio(
                f"How should {product} be rated?",
                usable,
                index=usable.index(default),
                format_func=lambda k: MISSING_STRATEGY_LABELS[k],
                key=f"mw_missing_{product}",
            )
            strategies[product] = choice

            if choice == MISSING_LIST_RATES:
                on_list = rc.pick_block(
                    _index(_s("lst_blocks") or []), product, False) is not None
                if on_list:
                    st.caption(
                        "✓ The List Rate Sheet has a table for this service.")
                else:
                    st.caption(
                        "⚠ The List Rate Sheet has **no** table for this "
                        "service — the fallback below decides what happens.")

                fb_options = [LIST_FALLBACK_CURRENT, LIST_FALLBACK_BLANK]
                if m.current_block is None:
                    fb_options = [LIST_FALLBACK_BLANK]
                fb_default = list_fallback.get(product, LIST_FALLBACK_CURRENT)
                if fb_default not in fb_options:
                    fb_default = fb_options[0]
                list_fallback[product] = st.selectbox(
                    "If the List Rate Sheet has no table for this service",
                    fb_options,
                    index=fb_options.index(fb_default),
                    format_func=lambda k: LIST_FALLBACK_LABELS[k],
                    key=f"mw_missing_fb_{product}",
                )
                list_for_current[product] = st.checkbox(
                    "Also rate the Current side from the List Rate Sheet",
                    value=list_for_current.get(product, False),
                    key=f"mw_missing_cur_{product}",
                    disabled=not on_list,
                )
            if choice == MISSING_USE_CURRENT:
                st.caption(
                    "Current and Proposed will be identical for this "
                    "service, so its impact will be $0."
                )
            st.markdown("")

    _set("missing", strategies)
    _set("missing_cur", list_for_current)
    _set("missing_fb", list_fallback)


# --------------------------------------------------------------------------
def _mwt_setup() -> None:
    theme.section("Multiweight products",
                  "which Product Names get grouped into MWT tags")
    theme.rule(
        "Procedure: pool <i>“Ground, Ground Multiweight (MWT), Home "
        "Delivery (only if MWT applies per the customer agreement)”</i> "
        "into one Pivot Table."
    )
    products = _products() or M.DEFAULT_MWT_PRODUCTS
    default = _s("mwt_products", [p for p in M.DEFAULT_MWT_PRODUCTS
                                  if p in products] or M.DEFAULT_MWT_PRODUCTS)
    mwt_products = st.multiselect(
        "Products grouped into Multiweight tags", products,
        default=[p for p in default if p in products] or default,
        key="mw_products",
        help="Add Home Delivery here only when the customer agreement's "
             "Multiweight terms actually cover it.")
    _set("mwt_products", mwt_products)

    theme.section("Customer agreement terms",
                  "from the Multiweight Terms and Conditions in this "
                  "customer's agreement — not a published constant")
    c1, c2 = st.columns(2)
    with c1:
        avg_pkg_wt = st.number_input(
            "Minimum Average Package Weight (lbs)", 0.0, 1000.0, 0.0, 1.0,
            key="mw_avg_pkg_wt",
            help="If the aggregate weight ÷ package count falls below this, "
                 "the billed weight is bumped up as if every package "
                 "weighed this much.")
    with c2:
        min_ship_wt = st.number_input(
            "Minimum Shipment Weight (lbs)", 0.0, 2000.0, 0.0, 1.0,
            key="mw_min_ship_wt",
            help="The aggregate is never billed below this weight.")
    _set("terms", M.MWTTerms(minimum_average_package_weight=avg_pkg_wt,
                             minimum_shipment_weight=min_ship_wt))

    theme.section("Weight tiers",
                  "read off the Ground Multiweight table on each Net Rate Sheet")
    theme.note(
        "Auto-detected boundary shown as a starting point — confirm or "
        "correct the tier break weight and per-zone rate from the rate "
        "sheet itself; the $91 minimum charge defaults to the published "
        "FY2026 figure."
    )

    for side, key in (("Current", "cur_tiers"), ("Proposed", "pro_tiers")):
        st.markdown(f"**{side} tiers**")
        tiers = _s(key)
        if tiers is None:
            tiers = M.default_tiers()
        new_tiers = []
        for i, base in enumerate(tiers):
            with st.expander(f"{base.label}", expanded=(i == 0)):
                c1, c2 = st.columns(2)
                min_w = c1.number_input(
                    "Tier floor (lbs)", 0.0, 5000.0, float(base.min_weight),
                    1.0, key=f"mw_{key}_{i}_min")
                is_open = base.max_weight is None
                open_ended = c2.checkbox(
                    "Open-ended (no ceiling)", value=is_open,
                    key=f"mw_{key}_{i}_open")
                max_w = None
                if not open_ended:
                    max_w = c2.number_input(
                        "Tier ceiling (lbs)", min_w, 10000.0,
                        float(base.max_weight or min_w + 299), 1.0,
                        key=f"mw_{key}_{i}_max")

                rate_cols = st.columns(len(M.ZONES))
                charge_cols = st.columns(len(M.ZONES))
                rate_per_lb = {}
                min_charge = {}
                for zc, z in zip(rate_cols, M.ZONES):
                    rate_per_lb[z] = zc.number_input(
                        f"Zone {z} rate/lb", 0.0, 100.0,
                        float(base.rate_per_lb.get(z, 0.0)), 0.01,
                        key=f"mw_{key}_{i}_rate_{z}", format="%.4f")
                for cc_col, z in zip(charge_cols, M.ZONES):
                    min_charge[z] = cc_col.number_input(
                        f"Zone {z} min $", 0.0, 10000.0,
                        float(base.min_charge.get(z, 91.0)), 1.0,
                        key=f"mw_{key}_{i}_charge_{z}")

                new_tiers.append(M.MWTTier(
                    label=f"Tier {i + 1} ({min_w:g}-"
                          f"{'open' if open_ended else f'{max_w:g}'} lbs)",
                    min_weight=min_w,
                    max_weight=None if open_ended else max_w,
                    rate_per_lb=rate_per_lb, min_charge=min_charge,
                ))
        _set(key, new_tiers)


# --------------------------------------------------------------------------
def _build() -> None:
    df = _s("df")
    if df is None or not _s("cur_blocks") or not _s("pro_blocks"):
        st.info("Complete the **Inputs** tab first.")
        return

    theme.section("Summary tab details")
    c1, c2 = st.columns(2)
    with c1:
        cht = st.text_input("CHT / Group ID", key="mw_cht")
    with c2:
        date_range = st.text_input(
            "Date range (blank = derive from the data)", "", key="mw_dr")

    theme.section("Heavyweight shipments", "procedure — packages over 150 lbs")
    h1, h2 = st.columns([3, 2])
    with h1:
        heavy_method = st.radio(
            "Heavyweight rating method",
            [rc.HEAVY_AUTO, rc.HEAVY_TABLE, rc.HEAVY_PER_LB],
            format_func=lambda k: rc.HEAVY_METHOD_LABELS[k],
            key="mw_heavy_method")
    with h2:
        threshold = st.number_input(
            "Heavyweight threshold (lbs)", 1.0, 5000.0, 150.0, 1.0,
            key="mw_heavy_threshold")
        write_as = st.checkbox(
            'Insert the per-pound "AS" rows into the rate sheet tabs', True,
            key="mw_write_as")

    notes = st.text_area(
        "Additional notes / assumptions (one per line)",
        "Focus: impact analysis for Multiweight-eligible Ground shipments",
        key="mw_notes")
    write_formulas = st.checkbox(
        "Keep live formulas in the workbook", True, key="mw_write_formulas",
        help="On (default): every calculated cell is a live Excel formula "
             "against the MWT Rules tab and the embedded rate sheets. Off: "
             "the same already-computed values are written as plain "
             "numbers instead.")

    if not _s("mwt_products"):
        st.warning(
            "No products selected on the **MWT setup** tab — nothing will "
            "be grouped into Multiweight tags. Visit that tab first."
        )

    if st.button("Build workbook", type="primary", key="mw_build"):
        cfg = mw.MultiweightConfig(
            cleanse=_s("opts") or CleanseOptions(drop_multi_piece=False),
            mappings=_ensure_mappings(),
            mwt_products=_s("mwt_products") or list(M.DEFAULT_MWT_PRODUCTS),
            current_tiers=_s("cur_tiers") or M.default_tiers(),
            proposed_tiers=_s("pro_tiers") or M.default_tiers(),
            terms=_s("terms") or M.MWTTerms(),
            analysis_notes=[n for n in notes.splitlines() if n.strip()],
            date_range=date_range.strip(),
            cht_id=cht.strip(),
            heavy_method=heavy_method,
            heavy_threshold=float(threshold),
            write_per_pound_rows=bool(write_as),
            missing_proposed=_s("missing") or {},
            list_rates_for_current=_s("missing_cur") or {},
            list_fallback=_s("missing_fb") or {},
            write_formulas=write_formulas,
        )
        with st.spinner("Grouping Multiweight tags and writing formulas…"):
            buf, report, frame = mw.run(
                df, _s("cur_wb"), _s("cur_blocks"),
                _s("pro_wb"), _s("pro_blocks"), cfg,
                list_wb=_s("lst_wb"), list_blocks=_s("lst_blocks"))
        _set("output", buf.getvalue())
        _set("detail", frame)
        st.success(f"Processed {report.final_rows:,} shipments.")

    out = _s("output")
    if not out:
        return
    frame = _s("detail")

    if frame is not None and not frame.empty:
        mwt_low = {p.strip().lower() for p in
                  (_s("mwt_products") or M.DEFAULT_MWT_PRODUCTS)}
        mwt_rows = frame[frame["Product Name"].str.strip().str.lower()
                         .isin(mwt_low)]
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Shipments", f"{len(frame):,}")
        m2.metric("Ground-family", f"{len(mwt_rows):,}")
        m3.metric("Unique tags", f"{mwt_rows['Tag'].nunique():,}")
        dnr = int((frame["Rated (MWT)"] == "DNR").sum())
        m4.metric("DNR", f"{dnr:,}")

        _summary_preview(frame)

    st.download_button(
        "⬇  Download Multiweight Re-Rating workbook", data=out,
        file_name="Multiweight Re-Rating.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        key="mw_dl")
    st.caption(
        "The tier boundaries, per-zone rates and customer-agreement terms "
        "live on the **MWT Rules** tab — change one there and the whole "
        "workbook recalculates in Excel."
    )


def _money(v) -> str:
    if v is None or pd.isna(v):
        return "—"
    return f"-${abs(v):,.0f}" if v < 0 else f"${v:,.0f}"


def _summary_preview(frame: pd.DataFrame) -> None:
    sf = mw.summary_frame(frame, _s("mwt_products") or M.DEFAULT_MWT_PRODUCTS)
    if sf.empty:
        return
    theme.section("Summary tab", "exactly what the workbook's Summary shows")

    total = sf.iloc[-1]
    k1, k2, k3 = st.columns(3)
    k1.metric("Current cost", _money(total["Current Cost"]))
    k2.metric("Proposed cost", _money(total["Proposed Cost"]))
    pct = (total["Impact"] / total["Current Cost"]
          if total["Current Cost"] else 0)
    k3.metric("Impact", _money(total["Impact"]),
             delta=f"{pct:.1%}", delta_color="inverse")

    body = sf.copy()
    body["Shipments"] = body["Shipments"].map(lambda v: f"{v:,.0f}")
    body["Rated Wt"] = body["Rated Wt"].map(lambda v: f"{v:,.0f}")
    for c in ("Current Cost", "Proposed Cost", "Impact"):
        body[c] = body[c].map(_money)
    body["Impact %"] = sf["Impact %"].map(lambda v: f"{v:.1%}")

    def _bold_total(row):
        last = row.name == len(body) - 1
        return ["font-weight:700;background-color:#EFE7F7" if last else ""
                for _ in row]

    st.dataframe(body.style.apply(_bold_total, axis=1),
                use_container_width=True, hide_index=True)

    notes = list(frame.attrs.get("notes", []))
    assumptions = list(frame.attrs.get("assumptions", []))
    if notes or assumptions:
        with st.expander("Notes, assumptions & disclaimer"):
            for title, items in (("Notes:", notes),
                                 ("Assumptions & adjustments:", assumptions)):
                if items:
                    st.markdown(f"**{title}**")
                    for n in items:
                        st.markdown(f"- {n}")
            st.markdown("**Disclaimer:**")
            st.caption(DISCLAIMER)
