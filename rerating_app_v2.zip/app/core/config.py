"""
Central configuration for the Re-rating toolkit.

Everything here is *data*, not logic, so it can be tuned without touching
the processing code. Values follow the ER/BDA Manual Re-rating procedure.
"""

# --------------------------------------------------------------------------
# Zone normalisation
# --------------------------------------------------------------------------
# Some FedEx zones arrive as alphabetical codes. Procedure: "Sometimes zones can
# be alphabetical too, e.g. 17(A) Alaska, 9(H) Hawaii. We need translation."
ALPHA_ZONE_MAP = {
    "A": 17,   # Alaska
    "H": 9,    # Hawaii
    "M": 99,   # Military (APO/FPO)
    "P": 10,   # Puerto Rico
    "Z": 26,   # Other non-contiguous US territories
}

# Zones that are not US Domestic and must be dropped during cleansing.
NON_US_DOMESTIC_ZONES = {0, 51}


# --------------------------------------------------------------------------
# Shipment Data column names (as produced by the Shipment Detail Template)
# --------------------------------------------------------------------------
COL = {
    "tracking": "Tracking Number",
    "product": "Product Name",
    "pay_type": "Pay Type",
    "package_type": "Package Type",
    "rated_weight": "Rated Weight (Lbs)",
    "pieces": "Pieces",
    "shipments": "Shipments",
    "zone": "Zone",
    "payer_name": "Payer Global Name",
    "payer_group_id": "Payer Group ID",
    "opco": "OpCo",
    "invoice_date": "Invoice Date",
    "ship_date": "Ship Date",
    "list_freight": "USD List Freight Charge",
    "discount_amt": "USD Discount Amount",
    "net_transport": "USD Net Transportation Amount",
    "origin_region": "Origin Region",
    "dest_region": "Destination Region",
    "original_weight": "Original Weight (Lbs)",
    "length": "Length",
    "width": "Width",
    "height": "Height",
    "dim_divisor": "DIM Divisor",
    "origin_zip": "Actual Origin Zip",
    "recipient_addr": "Recipient Address",
    "recipient_postal": "Recipient Postal",
}

# Procedure step 3 - "Retain Required Columns".
RETAIN_COLUMNS = [
    COL["tracking"],
    COL["product"],
    COL["pay_type"],
    COL["package_type"],
    COL["rated_weight"],
    COL["pieces"],
    COL["shipments"],
    COL["zone"],
    COL["payer_name"],
    COL["payer_group_id"],
    COL["opco"],
    COL["invoice_date"],
    COL["ship_date"],
    COL["list_freight"],
    COL["discount_amt"],
    COL["net_transport"],
    COL["origin_region"],
    COL["dest_region"],
    COL["original_weight"],
    COL["length"],
    COL["width"],
    COL["height"],
    COL["dim_divisor"],
]


# --------------------------------------------------------------------------
# Cleansing defaults (procedure step 2)
# --------------------------------------------------------------------------
# Product names normally excluded from a US Domestic rate comparison.
DEFAULT_EXCLUDED_PRODUCT_KEYWORDS = [
    "F1R",
    "Pickup",
    "International",
    "Intl",
    "Freight",
    "Ground Economy",
    "SmartPost",
]

CLEANSE_RULES_HELP = {
    "product": "Drop services not under review (F1R, Pickup, International, Freight, ...)",
    "list_freight": "Drop rows where USD List Freight Charge is 0 or blank",
    "zone": "Drop non-US-Domestic zones (Zone 51, Zone 00)",
    "pieces": "Drop rows where Pieces > 1",
    "origin": "Drop rows where Origin Region is not US",
    "dest": "Drop rows where Destination Region is not US",
}


# --------------------------------------------------------------------------
# Package Type -> rate-table section
# --------------------------------------------------------------------------
# Rate sheets split each service into Envelope / Pak / Package sub-tables.
ENVELOPE_PACKAGE_TYPES = {"fedex letter", "fedex envelope", "envelope", "letter"}
PAK_PACKAGE_TYPES = {"fedex pak", "pak"}

# Procedure: "If the Rated Weight of any Pak shipment exceeds 2 lbs, rate the
# shipment using Customer Packaging rates."
PAK_MAX_WEIGHT = 2

# Standard net rate sheets stop at 150 lbs.
STANDARD_MAX_WEIGHT = 150


# --------------------------------------------------------------------------
# Rate sheet title -> shipment Product Name
# --------------------------------------------------------------------------
# Matched longest-first against the rate-sheet block title (case insensitive).
RATESHEET_SERVICE_ALIASES = [
    ("fedex first overnight freight", "First Overnight Freight"),
    ("fedex first overnight", "First Overnight"),
    ("fedex priority overnight", "Priority Overnight"),
    ("fedex standard overnight", "Standard Overnight"),
    ("fedex 2day a.m.", "2Day AM"),
    ("fedex 2day am", "2Day AM"),
    ("fedex 2day freight", "2Day Freight"),
    ("fedex 3day freight", "3Day Freight"),
    ("fedex 1day freight", "1Day Freight"),
    ("fedex 2day", "2Day"),
    ("fedex express saver", "Express Saver"),
    ("fedex ground economy", "Ground Economy"),
    ("home delivery domestic mwt", "Home Delivery MWT"),
    # Must come before the plain "single piece" alias below, or the "RM"
    # (Return Manager) tables would be matched as ordinary Home Delivery.
    ("home delivery domestic single piece rm", "Return Manager"),
    ("home delivery domestic single piece", "Home Delivery"),
    ("ground domestic mwt", "Ground MWT"),
    ("ground domestic single piece", "Ground"),
    ("ground export single piece", "Ground Export"),
]

# Shipment Product Name -> preferred rate-sheet service, when they differ.
# Multiweight: "For Ground Multiweight shipments, initially rate them
# using the single-piece Ground Net Rates."
PRODUCT_TO_RATESHEET_SERVICE = {
    "Multiweight": "Ground",
    "Ground Multiweight": "Ground",
    "Ground MWT": "Ground",
    "Home Delivery": "Home Delivery",
}

# Services where "if Proposed Rates are unavailable, use Current as Proposed".
FALLBACK_PROPOSED_TO_CURRENT = {"First Overnight", "First Overnight Freight"}


# --------------------------------------------------------------------------
# What to do when a service has no table on the Proposed rate sheet
# --------------------------------------------------------------------------
# First Overnight (FO) Shipments:
#   "If Proposed Rates are unavailable and both Net Rate Sheets are from the
#    same year, use the Current Rates as the Proposed Rates.
#    If the Current and Proposed Net Rate Sheets are from different years, use
#    FO List Rates to rate the shipments."
MISSING_USE_CURRENT = "use_current"
MISSING_LIST_RATES = "list_rates"
MISSING_EXCLUDE = "exclude"
MISSING_LEAVE_BLANK = "leave_blank"

MISSING_STRATEGY_LABELS = {
    MISSING_USE_CURRENT:
        "Use the Current rates as the Proposed rates "
        "(both sheets from the same year)",
    MISSING_LIST_RATES:
        "Use List Rates from a separate rate sheet "
        "(sheets from different years)",
    MISSING_EXCLUDE:
        "Exclude this service from the analysis",
    MISSING_LEAVE_BLANK:
        "Leave the Proposed cost blank (rate it manually later)",
}

# A List Rate Sheet rarely covers every service. When the chosen strategy is
# MISSING_LIST_RATES but the list sheet has no table for a given product, this
# decides what happens next - per service, so a mixed set of products can be
# part list-rated and part current-rated in the same analysis.
LIST_FALLBACK_CURRENT = "fallback_current"
LIST_FALLBACK_BLANK = "fallback_blank"

LIST_FALLBACK_LABELS = {
    LIST_FALLBACK_CURRENT:
        "Use the Current rates for that service",
    LIST_FALLBACK_BLANK:
        "Leave the Proposed cost blank",
}

LIST_FALLBACK_NOTES = {
    LIST_FALLBACK_CURRENT:
        "Proposed rates unavailable and service not on the List Rate Sheet - "
        "Current rates used as Proposed",
    LIST_FALLBACK_BLANK:
        "Proposed rates unavailable and service not on the List Rate Sheet - "
        "left unrated",
}


MISSING_STRATEGY_NOTES = {
    MISSING_USE_CURRENT:
        "Proposed rates unavailable - Current rates used as Proposed",
    MISSING_LIST_RATES:
        "Proposed rates unavailable - List Rates used",
    MISSING_EXCLUDE:
        "Proposed rates unavailable - service excluded from the analysis",
    MISSING_LEAVE_BLANK:
        "Proposed rates unavailable - left unrated",
}


# --------------------------------------------------------------------------
# Summary tab
# --------------------------------------------------------------------------
# Reporting order used on the Summary tab (procedure step 7).
SUMMARY_SERVICE_ORDER = [
    "First Overnight",
    "Priority Overnight",
    "Standard Overnight",
    "2Day AM",
    "2Day",
    "Express Saver",
    "1Day Freight",
    "2Day Freight",
    "3Day Freight",
    "Ground",
    "Multiweight",
    "Home Delivery",
    "Return Manager",
    "Ground Economy",
]

DISCLAIMER = (
    "The data presented in this document is for your information and convenience "
    "only.  FedEx does not guarantee the accuracy or completeness of this "
    "data.  This confidential information is being provided to you for your "
    "exclusive use and benefit and is provided subject to terms of our mutual "
    "non-disclosure agreement.  The information may not be shared with any "
    "third party without FedEx’s written consent.  This information "
    "cannot be used to file claims or request refunds or invoice adjustments."
)

# Number formats (Formatting Standards)
FMT_MONEY = '"$"#,##0'
FMT_MONEY_2DP = '"$"#,##0.00'
FMT_PCT_1DP = "0.0%"
FMT_INT = "#,##0"
FMT_WEIGHT = "#,##0"
