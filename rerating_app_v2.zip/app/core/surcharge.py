"""
Surcharge Pricing Template reader.

The Surcharge Pricing Template ("Discount Comparison") is a macro workbook
that pulls a customer's surcharge occurrences from Teradata and prices them at
two effective dates - Discount 1 (current agreement) and Discount 2 (proposed).

Where the numbers live
----------------------
The visible working tabs - *By Zone Charges*, *ExDom Parcel*, *Ground*,
*Ground Economy* and the international ones - hold the real cells. Each tab
repeats a nine-column block per Pricing Category::

    A                B           C..K  (Category 1)      L..T (Category 2) ...
    Surcharge        2026 List   Disc 1 Discount | Disc 2 Discount |
                                 Disc 1 Net Rate | Change | Disc 2 Net Rate |
                                 Occurrences | Est Disc 1 Net Spend |
                                 Change | Est Disc 2 Net Spend

The hidden *Surcharge Master Data* tab mirrors those cells by formula
(``='By Zone Charges'!C5``) and adds the columns the working tabs lack - OpCo,
Surcharge Category and Subcategory. That makes it the better source: one flat
table, already attributed to an operating company.

This module reads Master Data when it is present and complete, and falls back
to walking the working tabs when it is not.

The template's own arithmetic, which the app reproduces so an edited rate or
discount recalculates the same way::

    Net Rate N   = ROUND(List x (1 - Discount N), 2)
    Net Spend N  = Net Rate N x Occurrences
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional

import pandas as pd

MASTER_SHEET = "Surcharge Master Data"

# Working tabs, in the order the procedure lists them.
WORKING_TABS = [
    "By Zone Charges", "ExDom Parcel", "Ground", "Ground Economy",
    "ExDom Freight", "ExIntl Parcel", "ExIntl Freight",
    "Clearance Fee", "Pickup Fee",
]

# Tab -> operating company, where the tab itself determines it.
TAB_OPCO = {
    "ExDom Parcel": "Express",
    "ExDom Freight": "Express Freight",
    "ExIntl Parcel": "Express",
    "ExIntl Freight": "Express Freight",
    "Ground": "Ground",
    "Ground Economy": "Ground Economy",
}

# Columns of the flat table this module produces.
COLUMNS = [
    "OpCo", "Category", "Subcategory", "Surcharge", "Zone",
    "List", "Discount 1", "Discount 2",
    "Net Rate 1", "Net Rate 2", "Occurrences",
    "Net Spend 1", "Net Spend 2", "Impact",
    "Source", "Priced",
]


# --------------------------------------------------------------------------
def _num(v) -> Optional[float]:
    if isinstance(v, bool) or v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        s = v.strip().replace(",", "").replace("$", "").replace("%", "")
        try:
            return float(s)
        except ValueError:
            return None
    return None


def _clean(v) -> str:
    return str(v).replace("\n", " ").strip() if v is not None else ""


def excel_round(value: Optional[float], digits: int = 2) -> Optional[float]:
    """
    Excel's ROUND, which is *not* Python's round().

    Two differences have to be reproduced, and both bite on real rows:

    1. Excel rounds a half **away from zero**; Python rounds half to even.
    2. Excel first collapses the value to **15 significant digits**. In binary
       floating point ``29.5 * (1 - 0.55)`` is 13.274999999999999, not 13.275 -
       so rounding it directly gives 13.27, while Excel sees 13.275 and returns
       13.28. Formatting to 15 significant digits first restores the half.

    Without both steps the AHS zone rates drift a cent and the totals no longer
    tie to the template.
    """
    if value is None:
        return None
    fifteen = Decimal(f"{float(value):.15g}")
    quantum = Decimal(1).scaleb(-digits)
    return float(fifteen.quantize(quantum, rounding=ROUND_HALF_UP))


def net_rate(list_rate: Optional[float], discount: Optional[float]
             ) -> Optional[float]:
    """The template's own arithmetic: ROUND(List x (1 - Discount), 2)."""
    if list_rate is None:
        return None
    return excel_round(list_rate * (1 - (discount or 0.0)), 2)


def recalculate(df: pd.DataFrame) -> pd.DataFrame:
    """
    Re-derive net rates, spends and impact from List / Discounts / Occurrences.

    Called after the analyst edits a rate or a discount so the table behaves
    exactly as the template would.
    """
    out = df.copy()
    out["Net Rate 1"] = [net_rate(l, d) for l, d
                         in zip(out["List"], out["Discount 1"])]
    out["Net Rate 2"] = [net_rate(l, d) for l, d
                         in zip(out["List"], out["Discount 2"])]
    occ = pd.to_numeric(out["Occurrences"], errors="coerce").fillna(0.0)
    for n in ("1", "2"):
        rate = pd.to_numeric(out[f"Net Rate {n}"], errors="coerce")
        spend = rate * occ
        # A surcharge the template cannot price (Declared Value is charged per
        # $100 of value, not per occurrence) keeps a blank spend rather than a
        # fabricated one.
        out[f"Net Spend {n}"] = spend.where(out["Priced"], other=pd.NA)
    s1 = pd.to_numeric(out["Net Spend 1"], errors="coerce")
    s2 = pd.to_numeric(out["Net Spend 2"], errors="coerce")
    out["Impact"] = (s2 - s1)
    return out


# --------------------------------------------------------------------------
@dataclass
class TemplateInfo:
    """What the template says about itself."""

    start_period: str = ""
    end_period: str = ""
    effective_1: Optional[object] = None
    effective_2: Optional[object] = None
    categories: List[str] = field(default_factory=list)
    source_sheet: str = ""
    shipments: Optional[int] = None
    invoiced: Optional[float] = None

    @property
    def months(self) -> Optional[int]:
        """Months of shipment data, from the YYYYMM start/end periods."""
        try:
            s, e = str(self.start_period), str(self.end_period)
            sy, sm = int(s[:4]), int(s[4:6])
            ey, em = int(e[:4]), int(e[4:6])
            return (ey - sy) * 12 + (em - sm) + 1
        except Exception:
            return None

    @property
    def period_label(self) -> str:
        import datetime as _dt
        try:
            s, e = str(self.start_period), str(self.end_period)
            a = _dt.date(int(s[:4]), int(s[4:6]), 1)
            b = _dt.date(int(e[:4]), int(e[4:6]), 1)
            return f"{a:%b %Y} - {b:%b %Y}"
        except Exception:
            return ""


def read_info(wb) -> TemplateInfo:
    info = TemplateInfo()
    if "Selection" in wb.sheetnames:
        ws = wb["Selection"]
        for row in ws.iter_rows(min_row=1, max_row=6, values_only=True):
            for i, v in enumerate(row):
                label = _clean(v).lower().rstrip(":")
                nxt = row[i + 1] if i + 1 < len(row) else None
                if label == "start date":
                    info.start_period = _clean(nxt)
                elif label == "end date":
                    info.end_period = _clean(nxt)
                elif label == "effective date 1":
                    info.effective_1 = nxt
                elif label == "effective date 2":
                    info.effective_2 = nxt

    if "Invoiced Data Overview" in wb.sheetnames:
        ws = wb["Invoiced Data Overview"]
        for row in ws.iter_rows(values_only=True):
            if _clean(row[0]).lower() == "grand total":
                info.shipments = int(_num(row[1]) or 0) or None
                info.invoiced = _num(row[2])
                break
    return info


def available_categories(wb) -> List[str]:
    """Pricing Categories the template carries (Category 1 / 2 / 3)."""
    cats: List[str] = []
    if MASTER_SHEET in wb.sheetnames:
        ws = wb[MASTER_SHEET]
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row,
                                min_col=2, max_col=2, values_only=True):
            c = _clean(row[0])
            if c and c not in cats:
                cats.append(c)
    if not cats:
        for tab in WORKING_TABS:
            if tab in wb.sheetnames:
                ws = wb[tab]
                row2 = next(ws.iter_rows(min_row=2, max_row=2,
                                         values_only=True), ())
                for v in row2:
                    vv = _clean(v)
                    if vv.startswith("Category") and vv not in cats:
                        cats.append(vv)
                break
    return cats or ["Category 1"]


# --------------------------------------------------------------------------
def _split_zone(name: str) -> tuple:
    """'Express AHS - Dimensions Zones 3-4' -> (surcharge, zone band)."""
    low = name.lower()
    for marker in (" zones ", " zone "):
        i = low.rfind(marker)
        if i > 0:
            return name[:i].strip(), name[i:].strip()
    return name.strip(), ""


def from_master(wb, category: str = "Category 1") -> pd.DataFrame:
    """Read the flat Surcharge Master Data mirror."""
    ws = wb[MASTER_SHEET]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return pd.DataFrame(columns=COLUMNS)

    hdr = [_clean(h) for h in rows[0]]

    def col(*names) -> Optional[int]:
        for want in names:
            for i, h in enumerate(hdr):
                if h.lower() == want.lower():
                    return i
        for want in names:
            for i, h in enumerate(hdr):
                if h.lower().startswith(want.lower()):
                    return i
        return None

    c_cat = col("Pricing Category")
    c_opco = col("OpCo")
    c_group = col("Surcharge Category")
    c_sub = col("Surcharge Subcategory")
    c_name = col("Surcharge")
    c_list = col("2026 List", "List")
    c_d1 = col("Disc 1 Discount")
    c_d2 = col("Disc 2 Discount")
    c_occ = col("Occurrences")
    c_s1 = col("Est Disc 1  Net Spend", "Est Disc 1 Net Spend")
    c_s2 = col("Est Disc 2  Net Spend", "Est Disc 2 Net Spend")

    out = []
    for r in rows[1:]:
        if c_cat is not None and _clean(r[c_cat]) != category:
            continue
        name = _clean(r[c_name]) if c_name is not None else ""
        if not name:
            continue
        occ = _num(r[c_occ]) if c_occ is not None else None
        lst = _num(r[c_list]) if c_list is not None else None
        d1 = _num(r[c_d1]) if c_d1 is not None else None
        d2 = _num(r[c_d2]) if c_d2 is not None else None
        s1 = _num(r[c_s1]) if c_s1 is not None else None
        s2 = _num(r[c_s2]) if c_s2 is not None else None
        sur, zone = _split_zone(name)
        out.append({
            "OpCo": _clean(r[c_opco]) if c_opco is not None else "",
            "Category": _clean(r[c_group]) if c_group is not None else "",
            "Subcategory": _clean(r[c_sub]) if c_sub is not None else "",
            "Surcharge": sur, "Zone": zone,
            "List": lst, "Discount 1": d1 or 0.0, "Discount 2": d2 or 0.0,
            "Net Rate 1": net_rate(lst, d1), "Net Rate 2": net_rate(lst, d2),
            "Occurrences": occ or 0.0,
            "Net Spend 1": s1, "Net Spend 2": s2,
            "Impact": (s2 - s1) if (s1 is not None and s2 is not None) else None,
            "Source": MASTER_SHEET,
            # The template leaves Net Spend blank where a surcharge cannot be
            # priced per occurrence (Declared Value is per $100 of value).
            "Priced": lst is not None and s1 is not None,
        })
    return pd.DataFrame(out, columns=COLUMNS)


def from_working_tabs(wb, category: str = "Category 1",
                      tabs: Optional[List[str]] = None) -> pd.DataFrame:
    """
    Walk the visible working tabs.

    Used when Master Data is missing. Category blocks are located from row 2
    and their columns matched by header name, because the block stride is not
    the same on every tab (nine columns on the domestic tabs, twelve on
    ExIntl Freight).
    """
    out = []
    for tab in (tabs or WORKING_TABS):
        if tab not in wb.sheetnames:
            continue
        ws = wb[tab]
        # Materialized once per tab and indexed like a list-of-lists below,
        # rather than random-accessed cell by cell - works the same against
        # a read_only workbook (no styled Cell objects, much less memory on
        # a big template) and against a normal one.
        rows = [tuple(r) for r in ws.iter_rows(values_only=True)]
        if len(rows) < 2:
            continue
        max_col = max((len(r) for r in rows), default=0)

        def cell(r_idx: int, c_idx: int):
            if 1 <= r_idx <= len(rows):
                row = rows[r_idx - 1]
                if 1 <= c_idx <= len(row):
                    return row[c_idx - 1]
            return None

        starts = [c for c in range(1, max_col + 1)
                  if _clean(cell(2, c)).startswith("Category")]
        if not starts:
            continue
        want = None
        for c in starts:
            if _clean(cell(2, c)) == category:
                want = c
                break
        if want is None:
            want = starts[0]
        end = min([c for c in starts if c > want] + [max_col + 1])

        idx: Dict[str, int] = {}
        for c in range(want, end):
            h = _clean(cell(3, c)).lower()
            if not h:
                continue
            if h.startswith("disc 1 discount"):
                idx["d1"] = c
            elif h.startswith("disc 2 discount"):
                idx["d2"] = c
            elif h.startswith("occurrence"):
                idx["occ"] = c
            elif h.startswith("est disc 1"):
                idx["s1"] = c
            elif h.startswith("est disc 2"):
                idx["s2"] = c
        if "occ" not in idx:
            continue

        group = ""
        for r in range(4, len(rows) + 1):
            name = _clean(cell(r, 1))
            if not name:
                continue
            lst = _num(cell(r, 2))
            occ = _num(cell(r, idx["occ"]))
            if lst is None:
                # a group header - remember it and skip, its children carry
                # the detail and the template already totals it
                group = name
                continue

            zone = ""
            sur = name
            if name.lower().startswith(("zone", "zones")):
                sur, zone = group, name
            else:
                sur, zone = _split_zone(name)

            opco = TAB_OPCO.get(tab, "")
            if not opco:
                low = (group or sur).lower()
                opco = ("Ground" if low.startswith("ground")
                        else "Express" if low.startswith("express") else "")

            d1 = _num(cell(r, idx["d1"])) if "d1" in idx else None
            d2 = _num(cell(r, idx["d2"])) if "d2" in idx else None
            s1 = _num(cell(r, idx["s1"])) if "s1" in idx else None
            s2 = _num(cell(r, idx["s2"])) if "s2" in idx else None

            out.append({
                "OpCo": opco, "Category": group, "Subcategory": group,
                "Surcharge": sur, "Zone": zone,
                "List": lst, "Discount 1": d1 or 0.0, "Discount 2": d2 or 0.0,
                "Net Rate 1": net_rate(lst, d1), "Net Rate 2": net_rate(lst, d2),
                "Occurrences": occ or 0.0,
                "Net Spend 1": s1, "Net Spend 2": s2,
                "Impact": (s2 - s1) if (s1 is not None and s2 is not None)
                          else None,
                "Source": tab,
                "Priced": s1 is not None,
            })
    return pd.DataFrame(out, columns=COLUMNS)


def parse(wb, category: str = "Category 1") -> pd.DataFrame:
    """Read the template, preferring the flat mirror over the working tabs."""
    df = pd.DataFrame(columns=COLUMNS)
    if MASTER_SHEET in wb.sheetnames:
        df = from_master(wb, category)
    if df.empty or pd.to_numeric(df["Occurrences"],
                                 errors="coerce").fillna(0).sum() == 0:
        alt = from_working_tabs(wb, category)
        if not alt.empty:
            df = alt
    return df.reset_index(drop=True)


# --------------------------------------------------------------------------
def with_occurrences(df: pd.DataFrame) -> pd.DataFrame:
    """Only the surcharges the customer actually incurred."""
    occ = pd.to_numeric(df["Occurrences"], errors="coerce").fillna(0)
    return df.loc[occ > 0].reset_index(drop=True)


def by_surcharge(df: pd.DataFrame) -> pd.DataFrame:
    """
    Roll the zone bands up to one row per OpCo + surcharge.

    This is the level the summary reports at; the zone detail stays available
    underneath for anyone who wants to see how a figure was built.
    """
    if df.empty:
        return df
    work = df.copy()
    for c in ("Occurrences", "Net Spend 1", "Net Spend 2"):
        work[c] = pd.to_numeric(work[c], errors="coerce")

    g = (work.groupby(["OpCo", "Surcharge"], dropna=False, as_index=False)
              .agg(Occurrences=("Occurrences", "sum"),
                   **{"Net Spend 1": ("Net Spend 1", "sum"),
                      "Net Spend 2": ("Net Spend 2", "sum")},
                   Zones=("Zone", lambda s: sum(1 for x in s if str(x).strip())),
                   **{"List (min)": ("List", "min"),
                      "List (max)": ("List", "max"),
                      "Discount 1": ("Discount 1", "max"),
                      "Discount 2": ("Discount 2", "max")}))
    g["Impact"] = g["Net Spend 2"] - g["Net Spend 1"]
    g["List"] = [
        f"{a:,.2f}" if a == b else "zone-based"
        for a, b in zip(g["List (min)"], g["List (max)"])
    ]
    return g.sort_values(["OpCo", "Net Spend 1"],
                         ascending=[True, False]).reset_index(drop=True)


def opco_totals(df: pd.DataFrame) -> pd.DataFrame:
    """Express / Ground subtotals plus a grand total."""
    if df.empty:
        return df
    work = df.copy()
    for c in ("Occurrences", "Net Spend 1", "Net Spend 2"):
        work[c] = pd.to_numeric(work[c], errors="coerce")
    g = (work.groupby("OpCo", dropna=False, as_index=False)
              .agg(Surcharges=("Surcharge", "nunique"),
                   Occurrences=("Occurrences", "sum"),
                   **{"Net Spend 1": ("Net Spend 1", "sum"),
                      "Net Spend 2": ("Net Spend 2", "sum")}))
    g["Impact"] = g["Net Spend 2"] - g["Net Spend 1"]
    total = {
        "OpCo": "Total",
        "Surcharges": int(g["Surcharges"].sum()),
        "Occurrences": g["Occurrences"].sum(),
        "Net Spend 1": g["Net Spend 1"].sum(),
        "Net Spend 2": g["Net Spend 2"].sum(),
        "Impact": g["Impact"].sum(),
    }
    return pd.concat([g, pd.DataFrame([total])], ignore_index=True)


# ==========================================================================
# Fuel
# ==========================================================================
# "Fuel surcharges are assessed on the net package rate plus the following
# applicable surcharges." Matched on keywords because the template's own
# names are more specific than the published list ("Express DAS - Residential"
# against "Delivery Area Surcharges").
FUEL_BOTH = [
    ("Additional Handling", ["ahs", "additional handling"]),
    ("Address Correction", ["address correction"]),
    ("Collect on Delivery", ["c.o.d", "cod", "collect on delivery"]),
    ("Delivery Signature Options", ["signature"]),
    ("Delivery Area Surcharges", ["das", "delivery area"]),
    ("Oversize", ["oversize"]),
    ("Demand - Oversize", ["demand - oversize"]),
    ("Demand - AHS", ["demand - ahs"]),
    ("Demand - Residential", ["demand - residential"]),
    ("Residential Delivery", ["residential delivery"]),
    ("Return On-Call Pickup", ["return on-call pickup"]),
]

FUEL_EXPRESS_ONLY = [
    ("Accessible Dangerous Goods", ["accessible dangerous"]),
    ("AHS - Non Stackable", ["non stackable", "non-stackable"]),
    ("Broker Select Option Fee", ["broker select"]),
    ("Courier Pickup", ["courier pickup"]),
    ("Delivery Reattempts", ["delivery reattempt"]),
    ("Dry Ice", ["dry ice"]),
    ("ExpressTag", ["expresstag"]),
    ("Extended Service Area Delivery", ["extended service area delivery"]),
    ("Extended Service Area Pickup", ["extended service area pickup"]),
    ("Int'l Out-of-Delivery Area", ["out-of-delivery area"]),
    ("Int'l Out-of-Pickup Area", ["out-of-pickup area"]),
    ("Int'l Premium Pickup", ["premium pickup"]),
    ("Metro Service Area Delivery", ["metro service area delivery"]),
    ("Metro Service Area Pickup", ["metro service area pickup"]),
    ("Residential Pickup", ["residential pickup"]),
    ("Saturday Delivery", ["saturday delivery"]),
    ("Saturday Pickup", ["saturday pickup"]),
]

FUEL_GROUND_ONLY = [
    ("Call Tag", ["call tag"]),
    ("Haz Mat", ["haz mat", "hazmat"]),
    ("HD Convenient Delivery Options", ["convenient delivery", "cdo"]),
    ("Northern Canada Surcharge", ["northern canada"]),
    ("On-Call Pickup", ["on-call pickup"]),
    ("Demand - Unauthorized", ["demand - unauthorized"]),
    ("Unauthorized", ["unauthorized", "unauth"]),
]

# Surcharges that are never themselves fuelled - fuel is the thing being
# calculated, and these are not part of its base.
FUEL_EXCLUDE = ["fuel surcharge", "fuel"]


def fuel_applicable(surcharge: str, opco: str) -> bool:
    """Whether fuel is assessed on this surcharge, per the published lists."""
    name = (surcharge or "").lower()
    if any(x in name for x in FUEL_EXCLUDE):
        return False
    o = (opco or "").lower()
    table = list(FUEL_BOTH)
    if o.startswith("express"):
        table += FUEL_EXPRESS_ONLY
    elif o.startswith("ground"):
        table += FUEL_GROUND_ONLY
    else:
        table += FUEL_EXPRESS_ONLY + FUEL_GROUND_ONLY
    for _label, keys in table:
        if any(k in name for k in keys):
            return True
    return False


def add_fuel_flag(df: pd.DataFrame) -> pd.DataFrame:
    """Add the 'Fuel applies' column, auto-detected and user-overridable."""
    out = df.copy()
    if "Fuel applies" not in out.columns:
        out["Fuel applies"] = [
            fuel_applicable(s, o)
            for s, o in zip(out["Surcharge"], out["OpCo"])
        ]
    return out


def fuel_cost(transport: float, surcharges: float, rate: float,
              discount: float = 0.0) -> float:
    """
    (Transportation + fuel-applicable surcharges) x (1 - discount) x fuel rate.
    """
    return (float(transport or 0.0) + float(surcharges or 0.0)) \
        * (1 - float(discount or 0.0)) * float(rate or 0.0)


# ==========================================================================
# Summary listing rules
# ==========================================================================
GROUPED_LABEL = "All other surcharges subject to fuel"


def summary_rows(df: pd.DataFrame, group_unchanged: bool = True
                 ) -> pd.DataFrame:
    """
    Build the reported surcharge table.

    "List only those surcharges as separate line items where there is a change
    in discount, and where occurrences are present. All other surcharges can be
    excluded from listing individually ... Surcharges with no discount change
    but with occurrences should be summed together under 'All other surcharges
    subject to fuel'."
    """
    if df.empty:
        return df
    g = by_surcharge(df)
    g["Discount changed"] = (
        pd.to_numeric(g["Discount 1"], errors="coerce").round(6)
        != pd.to_numeric(g["Discount 2"], errors="coerce").round(6)
    )
    if not group_unchanged:
        g["Listed"] = True
        return g

    listed = g["Discount changed"] & (
        pd.to_numeric(g["Occurrences"], errors="coerce").fillna(0) > 0)
    out = g.loc[listed].copy()
    out["Listed"] = True

    rest = g.loc[~listed]
    for opco, part in rest.groupby("OpCo", dropna=False):
        occ = pd.to_numeric(part["Occurrences"], errors="coerce").sum()
        if not occ:
            continue
        s1 = pd.to_numeric(part["Net Spend 1"], errors="coerce").sum()
        s2 = pd.to_numeric(part["Net Spend 2"], errors="coerce").sum()
        out = pd.concat([out, pd.DataFrame([{
            "OpCo": opco, "Surcharge": GROUPED_LABEL, "List": "various",
            "Discount 1": None, "Discount 2": None,
            "Occurrences": occ, "Net Spend 1": s1, "Net Spend 2": s2,
            "Impact": s2 - s1, "Discount changed": False, "Listed": False,
        }])], ignore_index=True)

    return out.sort_values(
        ["OpCo", "Listed", "Net Spend 1"],
        ascending=[True, False, False]).reset_index(drop=True)
