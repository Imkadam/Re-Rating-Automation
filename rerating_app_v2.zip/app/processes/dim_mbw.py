"""
Process 2 - DIM Change Analysis & MBW  ("DIM changes and MBW")

Re-rates a shipment file under a changed DIM factor, applying the Minimum
Billable Weight rules that a DIM change activates, and produces a workbook in
which every derived figure is a live Excel formula.

The DIM factors, MBW values, surcharge rates and every threshold live on a
**Rules** tab that the detail formulas point at - so an analyst can change the
proposed DIM factor (or a Service Guide threshold) in Excel and the whole
workbook recalculates without coming back to the app.

Output tabs
-----------
Summary        notes, DIMs applied, service table with weight & cost impact
DIM Detail     one row per shipment - re-ordered L/W/H through to both costs
Rules          DIM factors, MBW table, Service Guide thresholds
Shipment Data  the cleansed dataset
current_rates  embedded Current Net Rate Sheet   (+ AS rows, helper column)
proposed_rates embedded Proposed Net Rate Sheet  (+ AS rows, helper column)
Zone Map       alpha -> numeric zone reference
"""

from __future__ import annotations

from dataclasses import dataclass, field
from io import BytesIO
from typing import Dict, List, Optional, Tuple

import openpyxl
import pandas as pd
from openpyxl.utils import get_column_letter

from core import dim as D
from core.config import (
    COL,
    FMT_INT,
    FMT_MONEY,
    FMT_MONEY_2DP,
    FMT_PCT_1DP,
    SUMMARY_SERVICE_ORDER,
)
from core.evaluate import build_grids, evaluate
from core.excel_writer import (
    BOLD,
    BOX,
    HELPER_FILL,
    TITLE_FONT,
    autosize,
    mark_total_row,
    new_workbook,
    style_header_row,
    write_disclaimer,
    write_notes_block,
    write_zone_map,
)
from core.ratesheet import RateBlock
from core.shipment import (
    CleanseOptions,
    CleanseReport,
    add_normalised_zone,
    cleanse,
    date_range_label,
    normalise_zone,
)
from processes import rate_comparison as rc
from processes import surcharge_analysis as SA

PROCESS_NAME = "DIM Change & MBW"
PROCESS_DESCRIPTION = (
    "Recalculate L/W/H, DIM volume and rated weights for a new DIM factor, "
    "apply the UA / OS / AHS minimum billable weights, and re-rate both sides."
)

DETAIL_SHEET = "DIM Detail"
RULES_SHEET = "Rules"
DATA_SHEET = "Shipment Data"
ZONE_SHEET = "Zone Map"
CURRENT_SHEET = rc.CURRENT_SHEET
PROPOSED_SHEET = rc.PROPOSED_SHEET
LIST_SHEET = rc.LIST_SHEET


# ==========================================================================
@dataclass
class DimConfig:
    cleanse: CleanseOptions = field(default_factory=CleanseOptions)
    mappings: Dict[str, rc.ServiceMapping] = field(default_factory=dict)

    # DIM factors per OpCo, plus a default for anything not listed
    current_divisors: Dict[str, float] = field(default_factory=dict)
    proposed_divisors: Dict[str, float] = field(default_factory=dict)
    default_current_divisor: float = 139.0
    default_proposed_divisor: float = 175.0

    rules: List[D.MBWRule] = field(default_factory=D.default_rules)
    apply_mbw: bool = True

    analysis_notes: List[str] = field(default_factory=list)
    date_range: str = ""
    cht_id: str = ""
    include_shipment_data: bool = True

    heavy_method: str = rc.HEAVY_AUTO
    heavy_threshold: float = 150.0
    write_per_pound_rows: bool = True
    # A pure DIM change re-rates both sides on one rate sheet - only the
    # weight moves - so there is no second sheet to embed.
    same_ratesheet: bool = False

    # Same missing-Proposed-rate handling as Rate Comparison - a DIM change
    # still rates both sides against real rate sheets, so a service the
    # Proposed sheet has no table for needs the same procedure-driven choice
    # (use Current as Proposed / use List Rates / exclude / leave blank).
    missing_proposed: Dict[str, str] = field(default_factory=dict)
    list_rates_for_current: Dict[str, bool] = field(default_factory=dict)
    list_fallback: Dict[str, str] = field(default_factory=dict)

    # True (default): every calculated cell on DIM Detail and Summary is a
    # live formula against the Rules tab and the embedded rate sheets.
    # False: the same, already-computed values are written as plain numbers
    # instead - see RateComparisonConfig.write_formulas for the trade-off.
    write_formulas: bool = True


# ==========================================================================
# Rules tab - the single place every threshold lives
# ==========================================================================
class RulesRefs:
    """Absolute A1 references into the Rules tab, built as it is written."""

    def __init__(self, sheet: str = RULES_SHEET):
        self.sheet = sheet
        self.divisor_range = ""
        self.default_current = ""
        self.default_proposed = ""
        self.mbw_range = ""
        self.ua_products = ""
        self.rule_rows: Dict[str, int] = {}
        self.threshold_rows: Dict[str, int] = {}

    def cell(self, ref: str) -> str:
        return f"{self.sheet}!{ref}"


def _write_rules(wb, config: DimConfig, opcos: List[str]) -> RulesRefs:
    ws = wb.create_sheet(RULES_SHEET)
    refs = RulesRefs()

    ws["B1"] = "Rules & factors"
    ws["B1"].font = TITLE_FONT
    ws["B2"] = ("Every figure on this tab is referenced by the DIM Detail "
                "formulas — change one here and the workbook recalculates.")
    ws["B2"].font = BOLD

    # ---- DIM factors -----------------------------------------------------
    ws["B4"] = "DIM factors"
    ws["B4"].font = BOLD
    for j, h in enumerate(["OpCo", "Current", "Proposed"]):
        ws.cell(row=5, column=2 + j, value=h)
    style_header_row(ws, 5, 2, 4)

    r = 6
    for opco in opcos:
        ws.cell(row=r, column=2, value=opco)
        ws.cell(row=r, column=3,
                value=float(config.current_divisors.get(
                    opco, config.default_current_divisor)))
        ws.cell(row=r, column=4,
                value=float(config.proposed_divisors.get(
                    opco, config.default_proposed_divisor)))
        for c in (2, 3, 4):
            ws.cell(row=r, column=c).border = BOX
        r += 1
    first_div, last_div = 6, r - 1

    ws.cell(row=r, column=2, value="(all other OpCos)").font = BOLD
    ws.cell(row=r, column=3, value=float(config.default_current_divisor))
    ws.cell(row=r, column=4, value=float(config.default_proposed_divisor))
    for c in (2, 3, 4):
        ws.cell(row=r, column=c).fill = HELPER_FILL
        ws.cell(row=r, column=c).border = BOX

    refs.divisor_range = f"$B${first_div}:$D${last_div}"
    refs.default_current = f"$C${r}"
    refs.default_proposed = f"$D${r}"

    # ---- MBW table -------------------------------------------------------
    top = r + 2
    ws.cell(row=top, column=2,
            value="Minimum Billable Weight surcharges").font = BOLD
    ws.cell(row=top + 1, column=2,
            value="Tested highest net rate first — procedure: “the surcharge "
                  "with highest amount is applied for the shipment”.").font = \
        BOLD

    head = top + 2
    for j, h in enumerate(["Code", "Surcharge", "MBW (lbs)",
                           "Ground list rate", "Ground discount",
                           "Ground net rate", "Express list rate",
                           "Express discount", "Express net rate"]):
        ws.cell(row=head, column=2 + j, value=h)
    style_header_row(ws, head, 2, 10)

    r = head + 1
    for rule in D.by_cost(config.rules):
        refs.rule_rows[rule.code] = r
        g_lr, g_dc = rule.rate_for("ground")
        e_lr, e_dc = rule.rate_for("express")
        ws.cell(row=r, column=2, value=rule.code)
        ws.cell(row=r, column=3, value=rule.label)
        ws.cell(row=r, column=4, value=float(rule.mbw)).number_format = FMT_INT
        ws.cell(row=r, column=5, value=float(g_lr)).number_format = FMT_MONEY_2DP
        ws.cell(row=r, column=6, value=float(g_dc)).number_format = FMT_PCT_1DP
        ws.cell(row=r, column=7,
                value=f"=E{r}*(1-F{r})").number_format = FMT_MONEY_2DP
        ws.cell(row=r, column=8, value=float(e_lr)).number_format = FMT_MONEY_2DP
        ws.cell(row=r, column=9, value=float(e_dc)).number_format = FMT_PCT_1DP
        ws.cell(row=r, column=10,
                value=f"=H{r}*(1-I{r})").number_format = FMT_MONEY_2DP
        for c in range(2, 11):
            ws.cell(row=r, column=c).border = BOX
        r += 1
    refs.mbw_range = f"$B${head + 1}:$D${r - 1}"

    # ---- UA product eligibility -----------------------------------------
    ws.cell(row=head, column=12,
            value="UA applies only to these products").font = BOLD
    ua_rule = next((x for x in config.rules if x.code == D.UA), None)
    ua_products = (ua_rule.products if ua_rule else []) or D.UA_PRODUCTS
    pr = head + 1
    for p in ua_products:
        ws.cell(row=pr, column=12, value=p).border = BOX
        pr += 1
    refs.ua_products = f"$L${head + 1}:$L${pr - 1}"

    # ---- thresholds ------------------------------------------------------
    top = r + 2
    ws.cell(row=top, column=2, value="Service Guide thresholds").font = BOLD
    ws.cell(row=top + 1, column=2,
            value="A shipment triggers a surcharge when it exceeds any "
                  "threshold on its row.").font = BOLD

    head = top + 2
    for j, h in enumerate(["Code", "Longest side (in)", "2nd longest (in)",
                           "Length + girth (in)", "Cubic volume (in³)",
                           "Actual weight (lbs)"]):
        ws.cell(row=head, column=2 + j, value=h)
    style_header_row(ws, head, 2, 7)

    r = head + 1
    for rule in D.by_cost(config.rules):
        refs.threshold_rows[rule.code] = r
        ws.cell(row=r, column=2, value=rule.code)
        for j, v in enumerate((rule.max_length, rule.max_second,
                               rule.max_length_girth, rule.max_volume,
                               rule.max_weight)):
            cell = ws.cell(row=r, column=3 + j,
                           value=float(v) if v is not None else None)
            cell.border = BOX
            if v is None:
                cell.value = "n/a"
                cell.font = BOLD
        ws.cell(row=r, column=2).border = BOX
        r += 1

    autosize(ws, {2: 14, 3: 20, 4: 18, 5: 18, 6: 15, 7: 15, 8: 18, 9: 15,
                  10: 15, 12: 26})
    ws.sheet_view.showGridLines = False
    return refs


# ==========================================================================
# detail tab
# ==========================================================================
DETAIL_HEADERS = [
    "ID", "Tracking Number", "Product Name", "OpCo", "Package Type",
    "Zone", "Zone (Numeric)",
    "Length", "Width", "Height", "Has DIM",
    "Original Wt (Lbs)", "Rated Weight (Lbs)", "Actual Wt (Lbs)",
    "L", "W", "H", "DIM Vol", "L&Girth",
    "UA / OS / AHS", "MBW (lbs)",
    "Current DIM factor", "Proposed DIM factor",
    "Current DIM Wt", "Proposed DIM Wt",
    "Current Rated Weight", "Proposed Rated Weight",
    "Current Cost", "Proposed Cost",
    "Weight Impact", "Cost Impact",
    "Current Method", "Proposed Method", "Proposed Rate Source",
]
C = {name: i + 1 for i, name in enumerate(DETAIL_HEADERS)}


def _surcharge_formula(refs: RulesRefs, rules: List[D.MBWRule], row: int
                       ) -> str:
    """
    Nested IF that names the winning surcharge, highest net rate first.

    Each rule references only the threshold cells that apply to it, so an
    unused ("n/a") cell is never compared against.
    """
    L = f"${get_column_letter(C['L'])}{row}"
    W = f"${get_column_letter(C['W'])}{row}"
    VOL = f"${get_column_letter(C['DIM Vol'])}{row}"
    LG = f"${get_column_letter(C['L&Girth'])}{row}"
    AW = f"${get_column_letter(C['Actual Wt (Lbs)'])}{row}"
    PROD = f"${get_column_letter(C['Product Name'])}{row}"

    def th(code: str, col: int) -> str:
        return refs.cell(f"${get_column_letter(col)}${refs.threshold_rows[code]}")

    HAS = f"${get_column_letter(C['Has DIM'])}{row}"

    expr = '""'
    for rule in reversed(D.by_cost(rules)):          # build inside-out
        # Dimension tests are gated on Has DIM. Without that guard the blank
        # ("") a dimensionless row carries would compare as GREATER than any
        # threshold - Excel sorts text above numbers - and every such row
        # would falsely trigger the surcharge.
        dim_tests = []
        if rule.max_length is not None:
            dim_tests.append(f"{L}>{th(rule.code, 3)}")
        if rule.max_second is not None:
            dim_tests.append(f"{W}>{th(rule.code, 4)}")
        if rule.max_length_girth is not None:
            dim_tests.append(f"{LG}>{th(rule.code, 5)}")
        if rule.max_volume is not None:
            dim_tests.append(f"{VOL}>{th(rule.code, 6)}")

        parts = []
        if dim_tests:
            inner = (f"OR({','.join(dim_tests)})" if len(dim_tests) > 1
                     else dim_tests[0])
            parts.append(f'AND({HAS}="Y",{inner})')
        if rule.max_weight is not None:
            parts.append(f"{AW}>{th(rule.code, 7)}")
        if not parts:
            continue

        cond = f"OR({','.join(parts)})" if len(parts) > 1 else parts[0]
        if rule.products:
            cond = (f"AND(COUNTIF({refs.cell(refs.ua_products)},{PROD})>0,"
                    f"{cond})")
        expr = f'IF({cond},"{rule.code}",{expr})'

    return f"=IFERROR({expr},\"\")"


def _write_detail(ws, df: pd.DataFrame, mappings, helper_for, refs: RulesRefs,
                  config: DimConfig, grids, write_formulas: bool = True
                  ) -> dict:
    for j, h in enumerate(DETAIL_HEADERS, start=1):
        ws.cell(row=1, column=j, value=h)
    style_header_row(ws, 1, 1, len(DETAIL_HEADERS))
    ws.freeze_panes = "D2"

    def get(row, key):
        return row.get(COL[key]) if COL[key] in df.columns else None

    def L(name: str) -> str:
        return get_column_letter(C[name])

    records: List[dict] = []
    r = 2
    for i, (_, row) in enumerate(df.iterrows(), start=1):
        product = str(get(row, "product") or "").strip()
        opco = str(get(row, "opco") or "").strip()
        pkg = str(get(row, "package_type") or "").strip()
        zone_raw = get(row, "zone")
        zone_num = row.get("Zone (Numeric)")
        zf = float(zone_num) if pd.notna(zone_num) else None

        raw_l = _f(get(row, "length"))
        raw_w = _f(get(row, "width"))
        raw_h = _f(get(row, "height"))
        dims = D.reorder(raw_l, raw_w, raw_h)

        rated_in = _f(get(row, "rated_weight")) or 0.0
        orig_wt = _f(get(row, "original_weight"))
        actual = orig_wt if (orig_wt or 0) > 0 else rated_in

        cur_div = float(config.current_divisors.get(
            opco, config.default_current_divisor))
        pro_div = float(config.proposed_divisors.get(
            opco, config.default_proposed_divisor))

        rule = (D.resolve_surcharge(dims, actual, product, config.rules)
                if config.apply_mbw else None)
        mbw = rule.mbw if rule else 0.0

        cur_rw = D.rated_weight(dims, actual, rated_in, cur_div, mbw) or 0.0
        pro_rw = D.rated_weight(dims, actual, rated_in, pro_div, mbw) or 0.0

        # ---- plain values ------------------------------------------------
        ws.cell(row=r, column=C["ID"], value=i)
        ws.cell(row=r, column=C["Tracking Number"],
                value=str(get(row, "tracking") or ""))
        ws.cell(row=r, column=C["Product Name"], value=product)
        ws.cell(row=r, column=C["OpCo"], value=opco)
        ws.cell(row=r, column=C["Package Type"], value=pkg)
        ws.cell(row=r, column=C["Zone"],
                value=zone_raw if zone_raw is not None else "")
        ws.cell(row=r, column=C["Zone (Numeric)"], value=zf)
        ws.cell(row=r, column=C["Length"], value=raw_l)
        ws.cell(row=r, column=C["Width"], value=raw_w)
        ws.cell(row=r, column=C["Height"], value=raw_h)
        ws.cell(row=r, column=C["Has DIM"], value="Y" if dims.has_dims else "N")
        ws.cell(row=r, column=C["Original Wt (Lbs)"], value=orig_wt)
        ws.cell(row=r, column=C["Rated Weight (Lbs)"], value=rated_in)

        # ---- derived, as formulas ---------------------------------------
        lw = f"${L('Length')}{r}"
        ww = f"${L('Width')}{r}"
        hh = f"${L('Height')}{r}"
        has = f"${L('Has DIM')}{r}"

        # The procedure uses the package's actual (scale) weight; fall back to the
        # rated weight where the extract carries no actual weight.
        ow = f"${L('Original Wt (Lbs)')}{r}"
        ws.cell(
            row=r, column=C["Actual Wt (Lbs)"],
            value=(f"=IF(N({ow})>0,{ow},${L('Rated Weight (Lbs)')}{r})"
                   if write_formulas else actual))

        if write_formulas:
            ws.cell(row=r, column=C["L"],
                    value=f'=IF({has}="Y",MAX({lw},{ww},{hh}),"")')
            ws.cell(row=r, column=C["W"],
                    value=f'=IF({has}="Y",MEDIAN({lw},{ww},{hh}),"")')
            ws.cell(row=r, column=C["H"],
                    value=f'=IF({has}="Y",MIN({lw},{ww},{hh}),"")')
            ws.cell(row=r, column=C["DIM Vol"],
                    value=f'=IF({has}="Y",${L("L")}{r}*${L("W")}{r}*${L("H")}{r},"")')
            ws.cell(row=r, column=C["L&Girth"],
                    value=f'=IF({has}="Y",${L("L")}{r}+2*${L("W")}{r}'
                          f'+2*${L("H")}{r},"")')
        else:
            ws.cell(row=r, column=C["L"],
                    value=dims.length if dims.has_dims else None)
            ws.cell(row=r, column=C["W"],
                    value=dims.width if dims.has_dims else None)
            ws.cell(row=r, column=C["H"],
                    value=dims.height if dims.has_dims else None)
            ws.cell(row=r, column=C["DIM Vol"],
                    value=dims.volume if dims.has_dims else None)
            ws.cell(row=r, column=C["L&Girth"],
                    value=dims.length_girth if dims.has_dims else None)

        ws.cell(
            row=r, column=C["UA / OS / AHS"],
            value=((_surcharge_formula(refs, config.rules, r)
                   if write_formulas else (rule.code if rule else ""))
                  if config.apply_mbw else ""))

        sc = f"${L('UA / OS / AHS')}{r}"
        if write_formulas:
            mbw_val = (f"=IFERROR(VLOOKUP({sc},{refs.cell(refs.mbw_range)},3,"
                      f"FALSE),0)" if config.apply_mbw else 0)
        else:
            mbw_val = mbw if config.apply_mbw else 0
        ws.cell(row=r, column=C["MBW (lbs)"], value=mbw_val)

        opco_ref = f"${L('OpCo')}{r}"
        ws.cell(
            row=r, column=C["Current DIM factor"],
            value=(f"=IFERROR(VLOOKUP({opco_ref},"
                   f"{refs.cell(refs.divisor_range)},2,FALSE),"
                   f"{refs.cell(refs.default_current)})"
                   if write_formulas else cur_div))
        ws.cell(
            row=r, column=C["Proposed DIM factor"],
            value=(f"=IFERROR(VLOOKUP({opco_ref},"
                   f"{refs.cell(refs.divisor_range)},3,FALSE),"
                   f"{refs.cell(refs.default_proposed)})"
                   if write_formulas else pro_div))

        vol = f"${L('DIM Vol')}{r}"
        if write_formulas:
            for factor_col, out_col in (
                ("Current DIM factor", "Current DIM Wt"),
                ("Proposed DIM factor", "Proposed DIM Wt"),
            ):
                ws.cell(row=r, column=C[out_col],
                        value=f'=IF({has}="Y",{vol}/${L(factor_col)}{r},"")')
        else:
            ws.cell(row=r, column=C["Current DIM Wt"],
                    value=dims.volume / cur_div if dims.has_dims else None)
            ws.cell(row=r, column=C["Proposed DIM Wt"],
                    value=dims.volume / pro_div if dims.has_dims else None)

        if write_formulas:
            aw = f"${L('Actual Wt (Lbs)')}{r}"
            rw = f"${L('Rated Weight (Lbs)')}{r}"
            mbw_ref = f"${L('MBW (lbs)')}{r}"
            for dim_col, out_col in (("Current DIM Wt", "Current Rated Weight"),
                                     ("Proposed DIM Wt", "Proposed Rated Weight")):
                ws.cell(
                    row=r, column=C[out_col],
                    value=f'=MAX(IF({has}="Y",ROUNDUP(MAX({aw},${L(dim_col)}{r}),0),'
                          f"ROUNDUP({rw},0)),{mbw_ref})",
                ).number_format = FMT_INT
        else:
            ws.cell(row=r, column=C["Current Rated Weight"], value=cur_rw
                    ).number_format = FMT_INT
            ws.cell(row=r, column=C["Proposed Rated Weight"], value=pro_rw
                    ).number_format = FMT_INT

        # ---- rating -------------------------------------------------------
        m = mappings.get(product) or rc.ServiceMapping(product=product)
        z_ref = f"${L('Zone (Numeric)')}{r}"

        cur_plan = rc.plan_rate(m.current_block, m.current_heavy, pkg, cur_rw,
                                config.heavy_method, config.heavy_threshold)
        pro_plan = rc.plan_rate(m.proposed_block, m.proposed_heavy, pkg, pro_rw,
                                config.heavy_method, config.heavy_threshold)
        cur_f = rc.formula_for(cur_plan, helper_for,
                               f"${L('Current Rated Weight')}{r}", z_ref)
        pro_f = rc.formula_for(pro_plan, helper_for,
                               f"${L('Proposed Rated Weight')}{r}", z_ref)

        from core import formulas as F
        cur_val = evaluate(cur_plan, grids, cur_rw, zf) if grids else None
        pro_val = evaluate(pro_plan, grids, pro_rw, zf) if grids else None

        if write_formulas:
            c1 = ws.cell(row=r, column=C["Current Cost"],
                        value=F.wrap_iferror(cur_f) if cur_f else None)
            c2 = ws.cell(row=r, column=C["Proposed Cost"],
                        value=F.wrap_iferror(pro_f) if pro_f else None)
        else:
            c1 = ws.cell(row=r, column=C["Current Cost"],
                        value=cur_val if cur_f else None)
            c2 = ws.cell(row=r, column=C["Proposed Cost"],
                        value=pro_val if pro_f else None)
        c1.number_format = FMT_MONEY_2DP
        c2.number_format = FMT_MONEY_2DP

        ws.cell(
            row=r, column=C["Weight Impact"],
            value=(f"=${L('Proposed Rated Weight')}{r}"
                   f"-${L('Current Rated Weight')}{r}"
                   if write_formulas else pro_rw - cur_rw)
        ).number_format = FMT_INT
        if write_formulas:
            cost_impact_val = (f"=IFERROR(${L('Proposed Cost')}{r}"
                              f"-${L('Current Cost')}{r},\"\")")
        else:
            cost_impact_val = (pro_val - cur_val
                              if (cur_f and pro_f and cur_val is not None
                                  and pro_val is not None) else None)
        ws.cell(row=r, column=C["Cost Impact"], value=cost_impact_val
                ).number_format = FMT_MONEY_2DP

        ws.cell(row=r, column=C["Current Method"], value=cur_plan.note)
        ws.cell(row=r, column=C["Proposed Method"], value=pro_plan.note)
        ws.cell(row=r, column=C["Proposed Rate Source"],
                value=rc.PROPOSED_SOURCE_LABELS.get(m.proposed_source,
                                                    m.proposed_source))

        records.append({
            "ID": i, "Product Name": product, "OpCo": opco,
            "Has DIM": dims.has_dims,
            "Surcharge": rule.code if rule else "",
            "MBW (lbs)": mbw,
            "Current Rated Weight": cur_rw,
            "Proposed Rated Weight": pro_rw,
            "Shipments": _f(get(row, "shipments")) or 1.0,
            "Proposed Rate Source": m.proposed_source,
            "Current Cost": cur_val,
            "Proposed Cost": pro_val,
            "Rated": bool(cur_f and pro_f),
        })
        r += 1

    widths = {C[n]: w for n, w in (
        ("ID", 6), ("Tracking Number", 17), ("Product Name", 19), ("OpCo", 10),
        ("Package Type", 19), ("Zone", 7), ("Zone (Numeric)", 13),
        ("Length", 9), ("Width", 9), ("Height", 9), ("Has DIM", 9),
        ("Original Wt (Lbs)", 15), ("Rated Weight (Lbs)", 17),
        ("Actual Wt (Lbs)", 14),
        ("L", 7), ("W", 7), ("H", 7), ("DIM Vol", 11), ("L&Girth", 10),
        ("UA / OS / AHS", 14), ("MBW (lbs)", 11),
        ("Current DIM factor", 16), ("Proposed DIM factor", 17),
        ("Current DIM Wt", 15), ("Proposed DIM Wt", 16),
        ("Current Rated Weight", 18), ("Proposed Rated Weight", 19),
        ("Current Cost", 13), ("Proposed Cost", 14),
        ("Weight Impact", 13), ("Cost Impact", 12),
        ("Current Method", 30), ("Proposed Method", 30),
        ("Proposed Rate Source", 28))}
    autosize(ws, widths)
    ws.auto_filter.ref = f"A1:{get_column_letter(len(DETAIL_HEADERS))}{r - 1}"

    return {"sheet": ws.title, "first_row": 2, "last_row": max(r - 1, 2),
            "frame": pd.DataFrame(records)}


def _f(value) -> Optional[float]:
    v = pd.to_numeric(value, errors="coerce")
    return float(v) if pd.notna(v) else None


# ==========================================================================
def run(shipment_df: pd.DataFrame,
        current_wb: openpyxl.Workbook, current_blocks: List[RateBlock],
        proposed_wb: openpyxl.Workbook, proposed_blocks: List[RateBlock],
        config: DimConfig,
        surcharge_df: Optional[pd.DataFrame] = None,
        surcharge_config: Optional[SA.SurchargeConfig] = None,
        list_wb: Optional[openpyxl.Workbook] = None,
        list_blocks: Optional[List[RateBlock]] = None,
        ) -> Tuple[BytesIO, CleanseReport, pd.DataFrame, Optional[pd.DataFrame]]:
    """
    Returns (workbook bytes, cleanse report, the rated detail frame, the
    surcharge summary frame). When `surcharge_df` / `surcharge_config` are
    given, a Surcharge Analysis step is appended onto this same workbook —
    see ``rate_comparison.run`` for the equivalent, more detailed note.

    A DIM change still rates every shipment against real rate sheets, so it
    shares Rate Comparison's mapping and missing-Proposed-rate handling in
    full: `list_wb` / `list_blocks` are an optional List Rate Sheet, and
    mappings are resolved (and any exclude-strategy products folded into the
    cleanse) before cleansing, exactly as Rate Comparison does.
    """
    wb = new_workbook()

    summary_ws = wb.create_sheet("Summary")
    detail_ws = wb.create_sheet(DETAIL_SHEET)
    data_ws = wb.create_sheet(DATA_SHEET) if config.include_shipment_data else None
    zone_range = write_zone_map(wb, ZONE_SHEET)

    cur_sheets, cur_blocks = rc._embed(wb, current_wb, current_blocks,
                                       CURRENT_SHEET,
                                       config.write_per_pound_rows)
    same = config.same_ratesheet or (proposed_wb is current_wb
                                     and proposed_blocks is current_blocks)
    if same:
        pro_sheets, pro_blocks = cur_sheets, cur_blocks
    else:
        pro_sheets, pro_blocks = rc._embed(wb, proposed_wb, proposed_blocks,
                                           PROPOSED_SHEET,
                                           config.write_per_pound_rows)
    lst_blocks: List[RateBlock] = []
    if list_wb is not None and list_blocks:
        _, lst_blocks = rc._embed(wb, list_wb, list_blocks, LIST_SHEET,
                                  config.write_per_pound_rows)

    helper_by_sheet: Dict[str, int] = {}
    for sheets in (cur_sheets, pro_sheets):
        for name, emb in sheets.items():
            helper_by_sheet[name] = emb.helper_col
    for name in wb.sheetnames:
        helper_by_sheet.setdefault(name, 20)

    def helper_for(block: RateBlock) -> int:
        return helper_by_sheet.get(block.sheet, 20)

    # --- mappings, resolved from the raw extract so an excluded-by-strategy
    # service can still be folded into the cleanse below --------------------
    products_all = sorted(
        shipment_df[COL["product"]].astype(str).str.strip().unique()
    ) if COL["product"] in shipment_df.columns else []

    mappings = config.mappings or rc.build_default_mappings(
        products_all, cur_blocks, pro_blocks, lst_blocks)
    mappings = rc._rebind_mappings(mappings, cur_blocks, pro_blocks, lst_blocks)
    mappings, excluded = rc.apply_missing_strategies(
        mappings, config.missing_proposed, lst_blocks,
        config.list_rates_for_current, config.list_fallback)

    opts = config.cleanse
    if excluded:
        opts = CleanseOptions(**{**opts.__dict__})
        opts.excluded_products = list(
            dict.fromkeys(list(opts.excluded_products) + excluded))

    clean_df, report = cleanse(shipment_df, opts)
    clean_df = add_normalised_zone(clean_df)

    opcos = sorted(
        clean_df[COL["opco"]].astype(str).str.strip().unique()
    ) if COL["opco"] in clean_df.columns else []
    refs = _write_rules(wb, config, opcos)

    grids = build_grids(wb, [n for n in wb.sheetnames
                             if n.startswith((CURRENT_SHEET, PROPOSED_SHEET,
                                              LIST_SHEET))])
    if same:
        config.analysis_notes = list(config.analysis_notes) + [
            "Both sides rated on the same net rate sheet — only the DIM "
            "factor changes."]

    detail = _write_detail(detail_ws, clean_df, mappings, helper_for, refs,
                           config, grids, write_formulas=config.write_formulas)

    if data_ws is not None:
        rc._write_shipment_data(data_ws, clean_df)

    date_range = config.date_range or date_range_label(clean_df)
    end_row = _write_summary(summary_ws, detail, report, config, date_range,
                             opcos, mappings)

    surcharge_reported = None
    if surcharge_df is not None and surcharge_config is not None \
            and not surcharge_df.empty:
        totals = rc.opco_cost_totals(detail["frame"])
        end_row, surcharge_reported = SA.build_into(
            wb, summary_ws, end_row, surcharge_df, surcharge_config, totals)

    write_disclaimer(summary_ws, end_row)

    wb.move_sheet("Summary", offset=-wb.sheetnames.index("Summary"))

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf, report, detail["frame"], surcharge_reported


# ==========================================================================
def summary_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Service table for the Summary tab and the on-screen preview."""
    if frame is None or frame.empty:
        return pd.DataFrame()

    present = list(frame["Product Name"].dropna().unique())
    ordered = [s for s in SUMMARY_SERVICE_ORDER if s in present]
    ordered += [s for s in sorted(present) if s not in ordered]

    rows = []
    for svc in ordered:
        g = frame[frame["Product Name"] == svc]
        cw = float(g["Current Rated Weight"].sum())
        pw = float(g["Proposed Rated Weight"].sum())
        cc = g["Current Cost"].sum(min_count=1)
        pc = g["Proposed Cost"].sum(min_count=1)
        cc = 0.0 if pd.isna(cc) else float(cc)
        pc = 0.0 if pd.isna(pc) else float(pc)
        rows.append({
            "Service": svc,
            "Shipments": float(g["Shipments"].sum()),
            "Current Rated Wt": cw, "Current Cost": cc,
            "Proposed Rated Wt": pw, "Proposed Cost": pc,
            "Weight Impact": pw - cw, "Cost Impact": pc - cc,
        })

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    total = {"Service": "Total"}
    for c in out.columns[1:]:
        total[c] = out[c].sum()
    return pd.concat([out, pd.DataFrame([total])], ignore_index=True)


def _write_summary(ws, detail: dict, report: CleanseReport, config: DimConfig,
                   date_range: str, opcos: List[str],
                   mappings: Optional[Dict[str, rc.ServiceMapping]] = None
                   ) -> int:
    frame: pd.DataFrame = detail["frame"]
    dsheet = detail["sheet"]
    first, last = detail["first_row"], detail["last_row"]

    ws["B1"] = "DIM Change & MBW Analysis"
    ws["B1"].font = TITLE_FONT

    r = 3
    if date_range:
        ws.cell(row=r, column=2,
                value=f"Based on US Domestic shipment characteristics "
                      f"{date_range}").font = BOLD
        r += 1
    if config.cht_id:
        ws.cell(row=r, column=2,
                value=f"CHT / Group ID: {config.cht_id}").font = BOLD
        r += 1
    r += 1

    notes = list(report.note_lines())
    if config.apply_mbw:
        applied = frame[frame["Surcharge"] != ""] if not frame.empty else frame
        n = 0 if frame.empty else len(applied)
        notes.append(
            f"MBW logic applied where necessary — {n:,} shipments "
            "(Unauthorized, Oversize, AHS) floored at their minimum billable "
            "weight.")
    else:
        notes.append("MBW logic NOT applied to this analysis.")
    if not frame.empty:
        no_dims = int((~frame["Has DIM"]).sum())
        if no_dims:
            notes.append(
                f"{no_dims:,} shipments had no dimensions — rated weight "
                "rounded up from the shipment data, per the procedure.")
    r = write_notes_block(ws, r, "Notes:", notes)

    extra_notes = list(config.analysis_notes)
    for m in (mappings or {}).values():
        if m.proposed_missing and m.note:
            extra_notes.append(f"{m.product}: {m.note}")

    if extra_notes:
        r = write_notes_block(ws, r, "Assumptions & adjustments:", extra_notes)

    # ---- DIMs applied ----------------------------------------------------
    ws.cell(row=r, column=2, value="DIMs applied").font = BOLD
    r += 1
    for j, h in enumerate(["OpCo", "Current", "Proposed"]):
        ws.cell(row=r, column=2 + j, value=h)
    style_header_row(ws, r, 2, 4)
    r += 1
    for opco in (opcos or ["(all)"]):
        ws.cell(row=r, column=2, value=opco)
        ws.cell(row=r, column=3, value=float(config.current_divisors.get(
            opco, config.default_current_divisor)))
        ws.cell(row=r, column=4, value=float(config.proposed_divisors.get(
            opco, config.default_proposed_divisor)))
        for c in (2, 3, 4):
            ws.cell(row=r, column=c).border = BOX
        r += 1
    r += 1

    # ---- service table ---------------------------------------------------
    ws.cell(row=r, column=2,
            value="*** ESTIMATED Net Rate Cost ***").font = BOLD
    r += 1
    group = r
    ws.cell(row=group, column=4, value="Current")
    ws.cell(row=group, column=6, value="Proposed")
    ws.cell(row=group, column=8, value="Impact")
    ws.merge_cells(start_row=group, start_column=4, end_row=group, end_column=5)
    ws.merge_cells(start_row=group, start_column=6, end_row=group, end_column=7)
    ws.merge_cells(start_row=group, start_column=8, end_row=group, end_column=9)
    style_header_row(ws, group, 2, 9)

    head = group + 1
    for j, h in enumerate(["Service", "Shipments", "Rated Wt", "Cost",
                           "Rated Wt", "Cost", "Weight", "Cost"]):
        ws.cell(row=head, column=2 + j, value=h)
    style_header_row(ws, head, 2, 9)

    services = []
    if not frame.empty:
        present = list(frame["Product Name"].dropna().unique())
        services = [s for s in SUMMARY_SERVICE_ORDER if s in present]
        services += [s for s in sorted(present) if s not in services]

    body_first = head + 1
    r = body_first
    key = get_column_letter(C["Product Name"])
    cw = get_column_letter(C["Current Rated Weight"])
    pw = get_column_letter(C["Proposed Rated Weight"])
    cc = get_column_letter(C["Current Cost"])
    pc = get_column_letter(C["Proposed Cost"])

    from core import formulas as F
    write_formulas = config.write_formulas

    def _svc_totals(g: pd.DataFrame) -> Dict[str, float]:
        """The same per-service rollup the COUNTIFS/SUMIFS formulas below
        compute — used instead of them in static-value mode."""
        cw_v = float(g["Current Rated Weight"].sum())
        pw_v = float(g["Proposed Rated Weight"].sum())
        cc_v = float(g["Current Cost"].sum(min_count=1) or 0.0)
        pc_v = float(g["Proposed Cost"].sum(min_count=1) or 0.0)
        return {"count": len(g), "cw": cw_v, "pw": pw_v, "cc": cc_v, "pc": pc_v}

    for svc in services:
        kr = f"$B{r}"
        ws.cell(row=r, column=2, value=svc)
        if write_formulas:
            ws.cell(row=r, column=3,
                    value=F.countifs(dsheet, key, kr, first, last)
                    ).number_format = FMT_INT
            ws.cell(row=r, column=4,
                    value=F.sumifs(dsheet, cw, key, kr, first, last)
                    ).number_format = FMT_INT
            ws.cell(row=r, column=5,
                    value=F.sumifs(dsheet, cc, key, kr, first, last)
                    ).number_format = FMT_MONEY
            ws.cell(row=r, column=6,
                    value=F.sumifs(dsheet, pw, key, kr, first, last)
                    ).number_format = FMT_INT
            ws.cell(row=r, column=7,
                    value=F.sumifs(dsheet, pc, key, kr, first, last)
                    ).number_format = FMT_MONEY
            ws.cell(row=r, column=8, value=f"=F{r}-D{r}").number_format = FMT_INT
            ws.cell(row=r, column=9, value=f"=G{r}-E{r}").number_format = FMT_MONEY
        else:
            t = _svc_totals(frame[frame["Product Name"] == svc])
            ws.cell(row=r, column=3, value=t["count"]).number_format = FMT_INT
            ws.cell(row=r, column=4, value=t["cw"]).number_format = FMT_INT
            ws.cell(row=r, column=5, value=t["cc"]).number_format = FMT_MONEY
            ws.cell(row=r, column=6, value=t["pw"]).number_format = FMT_INT
            ws.cell(row=r, column=7, value=t["pc"]).number_format = FMT_MONEY
            ws.cell(row=r, column=8, value=t["pw"] - t["cw"]
                    ).number_format = FMT_INT
            ws.cell(row=r, column=9, value=t["pc"] - t["cc"]
                    ).number_format = FMT_MONEY
        for c in range(2, 10):
            ws.cell(row=r, column=c).border = BOX
        r += 1

    body_last = r - 1
    total = r
    ws.cell(row=total, column=2, value="Total")
    if write_formulas:
        for col in "CDEFGHI":
            cell = ws.cell(row=total, column=ord(col) - 64,
                           value=f"=SUM({col}{body_first}:{col}{body_last})")
            cell.number_format = FMT_MONEY if col in ("E", "G", "I") else FMT_INT
    else:
        for col in "CDEFGHI":
            colnum = ord(col) - 64
            col_total = sum(
                ws.cell(row=rr, column=colnum).value or 0
                for rr in range(body_first, body_last + 1))
            cell = ws.cell(row=total, column=colnum, value=col_total)
            cell.number_format = FMT_MONEY if col in ("E", "G", "I") else FMT_INT
    mark_total_row(ws, total, 2, 9)

    if write_formulas:
        ws.cell(row=total + 1, column=8,
                value=f"=IFERROR(H{total}/D{total},0)").number_format = FMT_PCT_1DP
        ws.cell(row=total + 1, column=9,
                value=f"=IFERROR(I{total}/E{total},0)").number_format = FMT_PCT_1DP
    else:
        d_total = ws.cell(row=total, column=4).value or 0
        e_total = ws.cell(row=total, column=5).value or 0
        h_total = ws.cell(row=total, column=8).value or 0
        i_total = ws.cell(row=total, column=9).value or 0
        ws.cell(row=total + 1, column=8,
                value=(h_total / d_total) if d_total else 0
                ).number_format = FMT_PCT_1DP
        ws.cell(row=total + 1, column=9,
                value=(i_total / e_total) if e_total else 0
                ).number_format = FMT_PCT_1DP
    for c in (8, 9):
        ws.cell(row=total + 1, column=c).font = BOLD

    frame.attrs["notes"] = notes
    frame.attrs["assumptions"] = extra_notes
    frame.attrs["date_range"] = date_range
    frame.attrs["cht_id"] = config.cht_id

    r = total + 3
    autosize(ws, {2: 26, 3: 12, 4: 14, 5: 15, 6: 14, 7: 15, 8: 13, 9: 14})
    ws.sheet_view.showGridLines = False
    return r
