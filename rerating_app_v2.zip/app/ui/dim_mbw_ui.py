"""Streamlit UI for the DIM Change & MBW process."""

from __future__ import annotations

from typing import Dict, List

import pandas as pd
import streamlit as st

from core import dim as D
from core.config import (
    COL,
    DISCLAIMER,
    LIST_FALLBACK_BLANK,
    LIST_FALLBACK_CURRENT,
    LIST_FALLBACK_LABELS,
    MISSING_EXCLUDE,
    MISSING_LEAVE_BLANK,
    MISSING_LIST_RATES,
    MISSING_STRATEGY_LABELS,
    MISSING_USE_CURRENT,
)
from core.ratesheet import RateBlock
from core.shipment import (
    CleanseOptions,
    default_excluded_products,
    list_sheets as excel_sheet_names,
    load_shipment_data,
)
from processes import dim_mbw as dm
from processes import rate_comparison as rc
from ui import theme
from ui.surcharge_ui import SurchargeStep

STATE = "dm"
SURCHARGE_NS = "dm_sc"


def _s(key: str, default=None):
    # Double underscore keeps stored values out of the widget-key
    # namespace (widgets use "<state>_<name>"), because Streamlit
    # refuses a write to a key a widget already owns.
    return st.session_state.get(f"{STATE}__{key}", default)


def _set(key: str, value) -> None:
    st.session_state[f"{STATE}__{key}"] = value


# --------------------------------------------------------------------------
def render() -> None:
    theme.masthead(
        "DIM Change & MBW",
        "Recalculate rated weights under a new DIM factor, apply the minimum "
        "billable weight rules, and re-rate both sides.",
    )

    t1, t2, t3, t4, t5, t6, t7 = st.tabs([
        "1 · Inputs", "2 · Rate sheet mapping", "3 · Missing rates",
        "4 · DIM factors", "5 · MBW rules", "6 · Build", "7 · Surcharges",
    ])
    with t1:
        _inputs()
    with t2:
        _mapping()
    with t3:
        _missing()
    with t4:
        _factors()
    with t5:
        _rules()
    with t6:
        _build()
    with t7:
        _surcharges()


# --------------------------------------------------------------------------
def _inputs() -> None:
    theme.section("Shipment data", "must carry Length, Width and Height")

    f = st.file_uploader("Shipment Detail extract (.xlsx / .xlsm)",
                         type=["xlsx", "xlsm"], key="dm_ship_file")
    if f is not None:
        sheets = excel_sheet_names(f)
        idx = sheets.index("Shipment Data") if "Shipment Data" in sheets else 0
        sheet = st.selectbox("Worksheet holding the shipment rows", sheets,
                             index=idx, key="dm_ship_sheet")
        if st.button("Load shipment data", type="primary"):
            with st.spinner("Reading shipment data…"):
                df = load_shipment_data(f, sheet)
            _set("df", df)
            _set("excluded", default_excluded_products(df))
            _set("mappings", None)
            st.success(f"Loaded {len(df):,} rows × {len(df.columns)} columns.")

    df = _s("df")
    if df is not None:
        dims_present = 0
        if all(COL[k] in df.columns for k in ("length", "width", "height")):
            dims_present = int(
                df[[COL["length"], COL["width"], COL["height"]]]
                .notna().all(axis=1).sum())
        c1, c2, c3 = st.columns(3)
        c1.metric("Rows", f"{len(df):,}")
        c2.metric("With dimensions", f"{dims_present:,}")
        c3.metric("Without", f"{len(df) - dims_present:,}")
        if dims_present == 0:
            st.error(
                "No rows carry Length / Width / Height — a DIM analysis needs "
                "dimensions. Check the extract."
            )
        elif dims_present < len(df):
            theme.note(
                "Rows without dimensions keep their existing rated weight, "
                "rounded up — procedure: <i>“If in case the Dimension column is "
                "present as NA … replace the value with the actual rated "
                "weight by rounding it up.”</i>"
            )
        st.dataframe(df.head(15), use_container_width=True, height=220)

    theme.section("Net rate sheets")
    theme.note(
        "A pure DIM change re-rates both sides on the <b>same</b> rate sheet — "
        "only the weight moves. Upload a Proposed sheet as well only when the "
        "rates are changing too."
    )
    c1, c2 = st.columns(2)
    with c1:
        cur = st.file_uploader("Current Net Rate Sheet",
                               type=["xlsx", "xlsm"], key="dm_cur_file")
        cur_sheets = _sheet_picker(cur, "cur")
    with c2:
        pro = st.file_uploader("Proposed Net Rate Sheet (optional)",
                               type=["xlsx", "xlsm"], key="dm_pro_file")
        pro_sheets = _sheet_picker(pro, "pro")
    same = st.checkbox(
        "Use the Current rate sheet for both sides", value=(pro is None),
        key="dm_same_sheet",
        help="Untick when the rates change as well as the DIM factor, so the "
             "Proposed sheet you uploaded above actually gets used.")
    if pro is not None and same:
        st.warning(
            "A Proposed sheet is uploaded but this box is still checked, so "
            "it will be **ignored** — the Current sheet rates both sides. "
            "Untick above to use the Proposed sheet you just uploaded."
        )

    with st.expander("Optional — List Rate Sheet", expanded=False):
        theme.rule(
            "Procedure, First Overnight: <i>“If the Current and Proposed Net "
            "Rate Sheets are from different years, use FO List Rates to rate "
            "the shipments.”</i> Upload the list rate sheet here to make that "
            "option available on the <b>Missing rates</b> tab."
        )
        list_file = st.file_uploader("List Rate Sheet",
                                     type=["xlsx", "xlsm"], key="dm_list_file")
        list_sheet_names = _sheet_picker(list_file, "list")

    theme.section("Cleansing")
    products = sorted(df[COL["product"]].astype(str).str.strip().unique()) \
        if df is not None and COL["product"] in df.columns else []
    excluded = st.multiselect("Product Names to exclude", products,
                              default=_s("excluded", []), key="dm_excluded")
    cc1, cc2 = st.columns(2)
    with cc1:
        zero = st.checkbox("USD List Freight Charge is $0 or blank", True,
                           key="dm_zero")
        zones = st.checkbox("Non-US Domestic zones (51, 00)", True, key="dm_z")
        pieces = st.checkbox("Pieces greater than 1", True, key="dm_pieces")
    with cc2:
        origin = st.checkbox("Origin Region is not US", True, key="dm_o")
        dest = st.checkbox("Destination Region is not US", True, key="dm_d")
    _set("opts", CleanseOptions(
        excluded_products=excluded, drop_zero_freight=zero,
        drop_non_us_zones=zones, drop_multi_piece=pieces,
        drop_non_us_origin=origin, drop_non_us_dest=dest,
        drop_over_150=False))

    if st.button("Parse rate sheets", disabled=cur is None):
        with st.spinner("Detecting rate tables…"):
            cur_wb, cur_blocks = rc.load_ratesheet_blocks(cur, cur_sheets)
            if pro is not None and not same:
                pro_wb, pro_blocks = rc.load_ratesheet_blocks(pro, pro_sheets)
            else:
                pro_wb, pro_blocks = cur_wb, cur_blocks
            cur_info = rc.load_ratesheet_info(cur_wb, cur_sheets)
            pro_info = rc.load_ratesheet_info(pro_wb, pro_sheets)
            lst_wb = lst_blocks = None
            if list_file is not None:
                lst_wb, lst_blocks = rc.load_ratesheet_blocks(
                    list_file, list_sheet_names)
        for k, v in (("cur_wb", cur_wb), ("cur_blocks", cur_blocks),
                     ("pro_wb", pro_wb), ("pro_blocks", pro_blocks),
                     ("cur_info", cur_info), ("pro_info", pro_info),
                     ("lst_wb", lst_wb), ("lst_blocks", lst_blocks),
                     ("same_sheet", pro is None or same),
                     ("mappings", None), ("missing", None)):
            _set(k, v)
        st.success(
            f"Detected {len(cur_blocks)} rate tables"
            + ("  ·  the same sheet rates both sides."
               if (pro is None or same) else
               f"  ·  {len(pro_blocks)} on the Proposed sheet.")
            + (f"  ·  {len(lst_blocks)} List Rate tables." if lst_blocks else "")
        )

    # Proposed is only shown separately when it's a distinct sheet - on the
    # same-sheet path pro_blocks is literally cur_blocks, so a second
    # identical expander would just be noise.
    same_sheet = _s("same_sheet", True)
    sections = [("Current", "cur_blocks")]
    if not same_sheet:
        sections.append(("Proposed", "pro_blocks"))
    sections.append(("List", "lst_blocks"))

    for label, key in sections:
        blocks = _s(key)
        if not blocks:
            continue
        with st.expander(f"{label} rate tables detected ({len(blocks)})"):
            st.dataframe(pd.DataFrame([
                {"Service": b.service, "Billing type": b.billing_type,
                 "Table": "per-lb / range" if b.is_per_pound else "standard",
                 "Header row": b.header_row}
                for b in blocks]), use_container_width=True)


def _sheet_picker(file, key: str):
    if file is None:
        return None
    try:
        names = excel_sheet_names(file)
    except Exception:
        return None
    if len(names) <= 1:
        return names
    return st.multiselect("Worksheets to scan", names, default=names,
                          key=f"dm_{key}_sheets") or names


# --------------------------------------------------------------------------
# Rate sheet mapping - same mechanics as Rate Comparison, since a DIM change
# still rates every shipment against real rate sheets.
# --------------------------------------------------------------------------
def _index(blocks: List[RateBlock]):
    from core.ratesheet import index_blocks
    return index_blocks(blocks)


def _products() -> List[str]:
    df = _s("df")
    if df is None:
        return []
    products = sorted(df[COL["product"]].astype(str).str.strip().unique())
    opts = _s("opts")
    excluded = set(opts.excluded_products) if opts else set()
    return [p for p in products if p not in excluded]


def _ensure_mappings() -> Dict[str, rc.ServiceMapping]:
    if _s("mappings") is None:
        cur_info, pro_info = _s("cur_info"), _s("pro_info")
        _set("mappings", rc.build_default_mappings(
            _products(), _s("cur_blocks") or [], _s("pro_blocks") or [],
            _s("lst_blocks") or [],
            cur_info.effective_year if cur_info else None,
            pro_info.effective_year if pro_info else None,
        ))
    return _s("mappings")


def _mapping() -> None:
    if _s("df") is None or not _s("cur_blocks"):
        st.info("Load the shipment data and parse the rate sheet(s) on the "
               "**Inputs** tab first.")
        return

    mappings = _ensure_mappings()
    theme.section("Which rate table rates each service?",
                  "auto-detected — override where the agreement differs")

    cur_blocks = _s("cur_blocks")
    pro_blocks = _s("pro_blocks") or cur_blocks
    cur_opts = ["— none —"] + [b.label for b in cur_blocks]
    pro_opts = ["— none —"] + [b.label for b in pro_blocks]
    cur_by = {b.label: b for b in cur_blocks}
    pro_by = {b.label: b for b in pro_blocks}

    for product in _products():
        m = mappings.get(product) or rc.ServiceMapping(product=product)
        if m.proposed_missing:
            head = f"**{product}**  ·  no Proposed table — see *Missing rates*"
        else:
            head = (f"**{product}**  ·  "
                    f"{m.current_block.label if m.current_block else 'no current table'}")
        with st.expander(head, expanded=m.current_block is None):
            c1, c2 = st.columns(2)
            with c1:
                cur = st.selectbox(
                    "Current — standard table", cur_opts,
                    index=cur_opts.index(m.current_block.label)
                    if m.current_block and m.current_block.label in cur_opts else 0,
                    key=f"dm_map_cur_{product}")
                curh = st.selectbox(
                    "Current — heavyweight / per-lb table", cur_opts,
                    index=cur_opts.index(m.current_heavy.label)
                    if m.current_heavy and m.current_heavy.label in cur_opts else 0,
                    key=f"dm_map_curh_{product}")
            with c2:
                pro = st.selectbox(
                    "Proposed — standard table", pro_opts,
                    index=pro_opts.index(m.proposed_block.label)
                    if m.proposed_block and m.proposed_block.label in pro_opts else 0,
                    key=f"dm_map_pro_{product}")
                proh = st.selectbox(
                    "Proposed — heavyweight / per-lb table", pro_opts,
                    index=pro_opts.index(m.proposed_heavy.label)
                    if m.proposed_heavy and m.proposed_heavy.label in pro_opts else 0,
                    key=f"dm_map_proh_{product}")

            picked_pro = pro_by.get(pro)
            mappings[product] = rc.ServiceMapping(
                product=product,
                current_block=cur_by.get(cur),
                proposed_block=picked_pro,
                current_heavy=cur_by.get(curh),
                proposed_heavy=pro_by.get(proh),
                proposed_missing=picked_pro is None,
                missing_strategy=m.missing_strategy,
            )
    _set("mappings", mappings)


def _missing() -> None:
    """Services with no table on the Proposed rate sheet."""
    if _s("df") is None or not _s("cur_blocks"):
        st.info("Load the shipment data and parse the rate sheet(s) on the "
               "**Inputs** tab first.")
        return

    mappings = _ensure_mappings()
    missing = [p for p, m in mappings.items() if m.proposed_missing]

    theme.section("Services missing from the Proposed rate sheet",
                  "procedure — First Overnight (FO) Shipments")
    theme.rule(
        "<i>“If Proposed Rates are unavailable and both Net Rate Sheets are "
        "from the same year, use the Current Rates as the Proposed Rates. "
        "If the Current and Proposed Net Rate Sheets are from different "
        "years, use FO List Rates to rate the shipments.”</i>"
    )

    if not missing:
        st.success(
            "Every service in the shipment data has a table on the Proposed "
            "rate sheet — nothing to decide here."
        )
        return

    cur_info, pro_info = _s("cur_info"), _s("pro_info")
    cy = cur_info.effective_year if cur_info else None
    py = pro_info.effective_year if pro_info else None
    have_list = bool(_s("lst_blocks"))

    if cy and py:
        same = cy == py
        theme.note(
            f"Current sheet <b>{cy}</b> · Proposed sheet <b>{py}</b> — "
            + ("<b>same year</b>, so the procedure points at "
               "<i>Current rates as Proposed</i>."
               if same else
               "<b>different years</b>, so the procedure points at "
               "<i>List Rates</i>.")
        )
    if not have_list:
        st.caption(
            "No List Rate Sheet uploaded — that option is disabled. Add one on "
            "the **Inputs** tab to enable it."
        )

    strategies: Dict[str, str] = dict(_s("missing") or {})
    list_for_current: Dict[str, bool] = dict(_s("missing_cur") or {})
    list_fallback: Dict[str, str] = dict(_s("missing_fb") or {})

    if len(missing) > 1:
        b1, b2 = st.columns([3, 1])
        with b1:
            bulk = st.selectbox(
                "Set every service below to…",
                ["— leave as they are —", MISSING_USE_CURRENT,
                 MISSING_LIST_RATES, MISSING_EXCLUDE, MISSING_LEAVE_BLANK],
                format_func=lambda k: (k if k.startswith("—")
                                       else MISSING_STRATEGY_LABELS[k]),
                key="dm_missing_bulk",
            )
        with b2:
            st.markdown("<div style='height:1.75rem'></div>",
                        unsafe_allow_html=True)
            if st.button("Apply to all", use_container_width=True,
                        key="dm_missing_bulk_apply"):
                if not bulk.startswith("—"):
                    for p in missing:
                        st.session_state.pop(f"dm_missing_{p}", None)
                        strategies[p] = bulk
                    _set("missing", strategies)
                    st.rerun()

    options = [MISSING_USE_CURRENT, MISSING_LIST_RATES,
               MISSING_EXCLUDE, MISSING_LEAVE_BLANK]

    for product in missing:
        m = mappings[product]
        default = strategies.get(product, m.missing_strategy
                                 or MISSING_LEAVE_BLANK)
        with st.container():
            st.markdown(
                f'<div class="fx-card"><b>{product}</b> — no table on the '
                f'Proposed rate sheet</div>', unsafe_allow_html=True)

            usable = [o for o in options
                      if not (o == MISSING_LIST_RATES and not have_list)
                      and not (o == MISSING_USE_CURRENT
                               and m.current_block is None)]
            if default not in usable:
                default = MISSING_LEAVE_BLANK

            choice = st.radio(
                f"How should {product} be rated?",
                usable,
                index=usable.index(default),
                format_func=lambda k: MISSING_STRATEGY_LABELS[k],
                key=f"dm_missing_{product}",
            )
            strategies[product] = choice

            if choice == MISSING_LIST_RATES:
                on_list = rc.pick_block(
                    _index(_s("lst_blocks") or []), product, False) is not None
                if on_list:
                    st.caption(
                        "✓ The List Rate Sheet has a table for this service.")
                else:
                    st.caption(
                        "⚠ The List Rate Sheet has **no** table for this "
                        "service — the fallback below decides what happens.")

                fb_options = [LIST_FALLBACK_CURRENT, LIST_FALLBACK_BLANK]
                if m.current_block is None:
                    fb_options = [LIST_FALLBACK_BLANK]
                fb_default = list_fallback.get(product, LIST_FALLBACK_CURRENT)
                if fb_default not in fb_options:
                    fb_default = fb_options[0]
                list_fallback[product] = st.selectbox(
                    "If the List Rate Sheet has no table for this service",
                    fb_options,
                    index=fb_options.index(fb_default),
                    format_func=lambda k: LIST_FALLBACK_LABELS[k],
                    key=f"dm_missing_fb_{product}",
                    help="A List Rate Sheet rarely covers every service, so "
                         "each product can fall back independently.",
                )
                list_for_current[product] = st.checkbox(
                    "Also rate the Current side from the List Rate Sheet",
                    value=list_for_current.get(product, False),
                    key=f"dm_missing_cur_{product}",
                    help="Use when neither sheet carries net rates for this "
                         "service and both sides should be on list rates.",
                    disabled=not on_list,
                )
            if choice == MISSING_USE_CURRENT:
                st.caption(
                    "Current and Proposed will be identical for this service, "
                    "so its impact will be $0. The substitution is recorded in "
                    "the Summary notes and in the *Proposed Rate Source* "
                    "column of the DIM Detail tab."
                )
            st.markdown("")

    _set("missing", strategies)
    _set("missing_cur", list_for_current)
    _set("missing_fb", list_fallback)


# --------------------------------------------------------------------------
def _factors() -> None:
    df = _s("df")
    if df is None:
        st.info("Load the shipment data on the **Inputs** tab first.")
        return

    theme.section("DIM factors", "procedure — DIM Change Analysis")
    theme.rule(
        "New DIM Volume = <b>L × W × H</b> where L = MAX, W = MEDIAN, "
        "H = MIN of the three dimensions.<br>"
        "Current DIM Weight = Volume ÷ current factor &nbsp;·&nbsp; "
        "Proposed DIM Weight = Volume ÷ proposed factor<br>"
        "Rated Weight = <b>ROUNDUP(MAX(actual weight, DIM weight))</b>, then "
        "floored at the MBW where one applies."
    )

    opcos = sorted(df[COL["opco"]].astype(str).str.strip().unique()) \
        if COL["opco"] in df.columns else []

    existing = None
    if COL["dim_divisor"] in df.columns:
        vals = pd.to_numeric(df[COL["dim_divisor"]], errors="coerce")
        vals = vals[vals > 1]
        if not vals.empty:
            existing = float(vals.mode().iloc[0])
            st.caption(
                f"The extract's own DIM Divisor column is mostly "
                f"**{existing:g}** — shown for reference; the factors below "
                "are what the analysis uses."
            )

    c1, c2 = st.columns(2)
    with c1:
        dcur = st.number_input("Default current DIM factor", 1.0, 1000.0,
                               float(existing or 139.0), 1.0, key="dm_dcur")
    with c2:
        dpro = st.number_input("Default proposed DIM factor", 1.0, 1000.0,
                               175.0, 1.0, key="dm_dpro")

    cur_map: Dict[str, float] = {}
    pro_map: Dict[str, float] = {}
    if opcos:
        st.markdown("**Per-OpCo override**")
        for opco in opcos:
            o1, o2, o3 = st.columns([2, 1, 1])
            o1.markdown(f"<div style='padding-top:.55rem'>{opco}</div>",
                        unsafe_allow_html=True)
            cur_map[opco] = o2.number_input(
                f"Current — {opco}", 1.0, 1000.0, float(dcur), 1.0,
                key=f"dm_c_{opco}", label_visibility="collapsed")
            pro_map[opco] = o3.number_input(
                f"Proposed — {opco}", 1.0, 1000.0, float(dpro), 1.0,
                key=f"dm_p_{opco}", label_visibility="collapsed")

    _set("dcur", dcur)
    _set("dpro", dpro)
    _set("cur_map", cur_map)
    _set("pro_map", pro_map)

    if abs(dcur - dpro) < 1e-9 and not any(
            abs(cur_map.get(o, dcur) - pro_map.get(o, dpro)) > 1e-9
            for o in opcos):
        st.warning(
            "Current and proposed DIM factors are identical — every weight "
            "impact will be zero."
        )


# --------------------------------------------------------------------------
def _rules() -> None:
    theme.section("Minimum Billable Weight",
                  "procedure — mandatory when a DIM factor changes")
    theme.rule(
        "“When a shipment qualifies for certain surcharges, the MBW rule "
        "activates … the shipment's weight is bumped up to a minimum "
        "chargeable limit if existing calculated weights are less than MBW.”"
        "<br>Where more than one applies, <b>the surcharge with the highest "
        "amount wins</b> — so the rules are tested in descending net-rate "
        "order, not a fixed order."
    )

    apply_mbw = st.checkbox("Apply MBW logic", True, key="dm_apply_mbw")
    _set("apply_mbw", apply_mbw)
    if not apply_mbw:
        st.warning(
            "MBW is a mandatory step for a DIM change request — leave this on "
            "unless you are deliberately isolating the DIM effect."
        )

    rules: List[D.MBWRule] = []
    for base in D.default_rules():
        with st.expander(
            f"**{base.code}** — {base.label}   ·   MBW {base.mbw:g} lbs",
            expanded=False,
        ):
            mbw = st.number_input("MBW (lbs)", 0.0, 1000.0, float(base.mbw),
                                  1.0, key=f"dm_mbw_{base.code}")

            st.markdown("**Rate & discount** — Ground and Express priced "
                        "separately, per the Service Guide")
            g1, g2, e1, e2 = st.columns(4)
            g_listr = g1.number_input(
                "Ground list rate ($)", 0.0, 100000.0,
                float(base.list_rate), 0.5, key=f"dm_lrg_{base.code}")
            g_disc = g2.number_input(
                "Ground discount %", 0.0, 100.0,
                float(base.discount * 100), 1.0, key=f"dm_dsg_{base.code}")
            e_listr = e1.number_input(
                "Express list rate ($)", 0.0, 100000.0,
                float(base.list_rate), 0.5, key=f"dm_lre_{base.code}")
            e_disc = e2.number_input(
                "Express discount %", 0.0, 100.0,
                float(base.discount * 100), 1.0, key=f"dm_dse_{base.code}")
            st.caption(
                f"Ground net ${g_listr * (1 - g_disc / 100):,.2f} · "
                f"Express net ${e_listr * (1 - e_disc / 100):,.2f} — the "
                "higher of the two decides which surcharge wins when "
                "several trigger on the same shipment."
            )

            t = st.columns(5)
            def _th(i, label, value, key):
                if value is None:
                    t[i].markdown(
                        f"<div style='color:#6B6675;font-size:.78rem;"
                        f"padding-top:.4rem'>{label}<br><b>n/a</b></div>",
                        unsafe_allow_html=True)
                    return None
                return t[i].number_input(label, 0.0, 1e7, float(value), 1.0,
                                         key=key)

            ml = _th(0, "Longest side (in)", base.max_length,
                     f"dm_l_{base.code}")
            ms = _th(1, "2nd longest (in)", base.max_second,
                     f"dm_s_{base.code}")
            mg = _th(2, "L + girth (in)", base.max_length_girth,
                     f"dm_g_{base.code}")
            mv = _th(3, "Cubic volume (in³)", base.max_volume,
                     f"dm_v_{base.code}")
            mw = _th(4, "Actual weight (lbs)", base.max_weight,
                     f"dm_w_{base.code}")

            products = base.products
            if base.products:
                products = st.multiselect(
                    "Applies only to these products", D.UA_PRODUCTS,
                    default=base.products, key=f"dm_pr_{base.code}")

            rules.append(D.MBWRule(
                code=base.code, label=base.label, mbw=mbw,
                list_rate=g_listr, discount=g_disc / 100,
                list_rate_ground=g_listr, discount_ground=g_disc / 100,
                list_rate_express=e_listr, discount_express=e_disc / 100,
                max_length=ml, max_second=ms,
                max_length_girth=mg, max_volume=mv, max_weight=mw,
                products=products))

    _set("rules", rules)

    order = D.by_cost(rules)
    st.markdown("**Test order** (highest net rate first — Ground or Express, "
               "whichever is higher, decides a rule's place)")
    st.dataframe(pd.DataFrame([
        {"#": i + 1, "Code": r.code, "Surcharge": r.label,
         "MBW (lbs)": f"{r.mbw:g}",
         "Ground net": f"${r.net_rate_for('ground'):,.2f}",
         "Express net": f"${r.net_rate_for('express'):,.2f}",
         "Applies to": ", ".join(r.products) if r.products else "all products"}
        for i, r in enumerate(order)]),
        use_container_width=True, hide_index=True)


# --------------------------------------------------------------------------
def _surcharges() -> None:
    theme.section(
        "Surcharge Analysis",
        "optional — append it onto the DIM change you just built")

    cfg = _s("cfg")
    if cfg is None or _s("detail") is None:
        st.info(
            "Build the DIM change first, on the **Build** tab — this step "
            "appends onto that result, and its transportation cost "
            "pre-fills the fuel calculation below from the same figures."
        )
        return

    theme.note(
        "Read a Surcharge Pricing Template here and it is added as its own "
        "Detail / Rules tabs, with its summary folded straight into the "
        "same workbook's <b>Summary</b> tab, right after the weight/cost "
        "impact table — one file, one number for both."
    )

    include = st.checkbox(
        "Include surcharge analysis in this workbook", value=_s("sc_on", False),
        key="dm_sc_on")
    _set("sc_on", include)
    if not include:
        return

    step = SurchargeStep(SURCHARGE_NS)
    st1, st2, st3, st4 = st.tabs(
        ["Template", "Surcharges", "Fuel & totals", "Build"])
    with st1:
        step.render_template()
    with st2:
        step.render_editor()
    with st3:
        prefill = rc.opco_cost_totals(_s("detail"))
        step.render_fuel(parent_totals=prefill)
    with st4:
        data = step.current()
        if data is None:
            st.info("Load a template on the **Template** tab first.")
        else:
            step.render_build_details(
                standalone=False,
                default_write_formulas=getattr(cfg, "write_formulas", True))

            if st.button("Rebuild workbook with surcharges", type="primary",
                        key="dm_sc_build"):
                surcharge_df = step.apply_fuel_flags(data)
                surcharge_cfg = step.config()
                with st.spinner("Rebuilding with surcharges…"):
                    buf, report, detail, surcharge_reported = dm.run(
                        _s("df"), _s("cur_wb"), _s("cur_blocks"),
                        _s("pro_wb"), _s("pro_blocks"), cfg,
                        surcharge_df, surcharge_cfg,
                        list_wb=_s("lst_wb"), list_blocks=_s("lst_blocks"))
                _set("output", buf.getvalue())
                _set("detail", detail)
                _set("surcharge_reported", surcharge_reported)
                st.success(
                    f"Surcharge Analysis appended ({len(surcharge_reported)} lines)."
                )

            _show_results(key_suffix="surcharges")


# --------------------------------------------------------------------------
def _build() -> None:
    df = _s("df")
    if df is None or not _s("cur_blocks"):
        st.info("Complete the **Inputs** tab first.")
        return

    theme.section("Summary tab details")
    c1, c2 = st.columns(2)
    with c1:
        cht = st.text_input("CHT / Group ID", value=_group_id(df), key="dm_cht")
    with c2:
        date_range = st.text_input(
            "Date range (blank = derive from the data)", "", key="dm_dr")

    theme.section("Heavyweight shipments", "procedure — packages over 150 lbs")
    theme.rule(
        "A per-pound row is inserted immediately below the 150 lb row on each "
        "rate sheet (<code>= 150 lb rate ÷ 150</code>, labelled <b>AS</b>), and "
        "<b>Shipment Rate = Per-Pound Rate × Rated Weight</b>. Express services "
        "with their own heavyweight table use an approximate match on rated "
        "weight and zone instead — the same rule Rate Comparison applies."
    )
    h1, h2 = st.columns([3, 2])
    with h1:
        heavy_method = st.radio(
            "Heavyweight rating method",
            [rc.HEAVY_AUTO, rc.HEAVY_TABLE, rc.HEAVY_PER_LB],
            format_func=lambda k: rc.HEAVY_METHOD_LABELS[k],
            key="dm_heavy_method")
    with h2:
        threshold = st.number_input(
            "Heavyweight threshold (lbs)", 1.0, 5000.0, 150.0, 1.0,
            key="dm_heavy_threshold")
        write_as = st.checkbox(
            'Insert the per-pound "AS" rows into the rate sheet tabs', True,
            key="dm_write_as")

    notes = st.text_area(
        "Additional notes / assumptions (one per line)",
        "Focus: impact analysis for the proposed DIM factor\n"
        "Limited to US Domestic services\n"
        "All shipments rated at Single Piece OB rates",
        key="dm_notes")
    include_data = st.checkbox("Include the cleansed Shipment Data tab", True,
                               key="dm_incl")
    write_formulas = st.checkbox(
        "Keep live formulas in the workbook", True, key="dm_write_formulas",
        help="On (default): every calculated cell is a live Excel formula "
             "against the Rules tab and the embedded rate sheets — click any "
             "cell to see the formula, but the workbook shows blank/#N/A "
             "until Excel recalculates it. Off: the same already-computed "
             "values are written as plain numbers instead — correct figures "
             "the instant the file opens, with no formula to trace.")

    if st.button("Build workbook", type="primary", key="dm_build"):
        cfg = dm.DimConfig(
            cleanse=_s("opts") or CleanseOptions(),
            mappings=_ensure_mappings(),
            current_divisors=_s("cur_map") or {},
            proposed_divisors=_s("pro_map") or {},
            default_current_divisor=float(_s("dcur", 139.0)),
            default_proposed_divisor=float(_s("dpro", 175.0)),
            rules=_s("rules") or D.default_rules(),
            apply_mbw=bool(_s("apply_mbw", True)),
            analysis_notes=[n for n in notes.splitlines() if n.strip()],
            date_range=date_range.strip(),
            cht_id=cht.strip(),
            include_shipment_data=include_data,
            same_ratesheet=bool(_s("same_sheet", True)),
            write_formulas=write_formulas,
            heavy_method=heavy_method,
            heavy_threshold=float(threshold),
            write_per_pound_rows=bool(write_as),
            missing_proposed=_s("missing") or {},
            list_rates_for_current=_s("missing_cur") or {},
            list_fallback=_s("missing_fb") or {},
        )
        with st.spinner("Recalculating weights and writing formulas…"):
            buf, report, detail, surcharge_reported = dm.run(
                df, _s("cur_wb"), _s("cur_blocks"),
                _s("pro_wb"), _s("pro_blocks"), cfg,
                list_wb=_s("lst_wb"), list_blocks=_s("lst_blocks"))
        _set("cfg", cfg)
        _set("output", buf.getvalue())
        _set("detail", detail)
        _set("surcharge_reported", surcharge_reported)
        st.success(f"Processed {report.final_rows:,} shipments.")
        theme.note(
            "Want surcharges in the same workbook? See the <b>Surcharges</b> "
            "tab — it appends onto this result."
        )

    _show_results()


def _show_results(key_suffix: str = "build") -> None:
    """Shown on both the Build tab and the Surcharges tab, since either one
    can be the last thing that produced `output` — the Surcharges tab's
    rebuild replaces the same session state the Build tab reads."""
    out = _s("output")
    if not out:
        return
    detail = _s("detail")

    if detail is not None and not detail.empty:
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Shipments", f"{len(detail):,}")
        m2.metric("With dimensions", f"{int(detail['Has DIM'].sum()):,}")
        m3.metric("MBW applied", f"{int((detail['Surcharge'] != '').sum()):,}")
        wt = detail["Proposed Rated Weight"].sum() - \
            detail["Current Rated Weight"].sum()
        m4.metric("Weight impact", f"{wt:,.0f} lbs")

        sc = detail[detail["Surcharge"] != ""]
        if not sc.empty:
            theme.section("Minimum billable weight applied")
            st.dataframe(
                sc.groupby("Surcharge").agg(
                    Shipments=("ID", "count"),
                    MBW=("MBW (lbs)", "max")).reset_index(),
                use_container_width=True, hide_index=True)

        _summary_preview(detail)

    surcharge_reported = _s("surcharge_reported")
    if surcharge_reported is not None and not surcharge_reported.empty:
        theme.section(
            "Surcharge summary",
            "folded into the same Summary tab, right after the table above")
        SurchargeStep(SURCHARGE_NS).render_summary(key_suffix=key_suffix)

    st.download_button(
        "⬇  Download DIM change workbook", data=out,
        file_name="DIM Change Analysis.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        key=f"dm_dl_{key_suffix}")
    st.caption(
        "The DIM factors, MBW values and every Service Guide threshold live on "
        "the **Rules** tab — change one there and the whole workbook "
        "recalculates in Excel."
    )


def _money(v) -> str:
    if v is None or pd.isna(v):
        return "—"
    return f"-${abs(v):,.0f}" if v < 0 else f"${v:,.0f}"


def _summary_preview(detail: pd.DataFrame) -> None:
    sf = dm.summary_frame(detail)
    if sf.empty:
        return
    theme.section("Summary tab", "exactly what the workbook's Summary shows")

    total = sf.iloc[-1]
    k1, k2, k3 = st.columns(3)
    k1.metric("Current cost", _money(total["Current Cost"]))
    k2.metric("Proposed cost", _money(total["Proposed Cost"]))
    cost_pct = (total["Cost Impact"] / total["Current Cost"]
                if total["Current Cost"] else 0)
    k3.metric("Cost impact", _money(total["Cost Impact"]),
              delta=f"{cost_pct:.1%}", delta_color="inverse")

    body = sf.copy()
    for c in ("Shipments", "Current Rated Wt", "Proposed Rated Wt",
              "Weight Impact"):
        body[c] = body[c].map(lambda v: f"{v:,.0f}")
    for c in ("Current Cost", "Proposed Cost", "Cost Impact"):
        body[c] = body[c].map(_money)

    def _bold_total(row):
        last = row.name == len(body) - 1
        return ["font-weight:700;background-color:#EFE7F7" if last else ""
                for _ in row]

    st.dataframe(body.style.apply(_bold_total, axis=1),
                 use_container_width=True, hide_index=True)

    notes = list(detail.attrs.get("notes", []))
    assumptions = list(detail.attrs.get("assumptions", []))
    if notes or assumptions:
        with st.expander("Notes, assumptions & disclaimer"):
            for title, items in (("Notes:", notes),
                                 ("Assumptions & adjustments:", assumptions)):
                if items:
                    st.markdown(f"**{title}**")
                    for n in items:
                        st.markdown(f"- {n}")
            st.markdown("**Disclaimer:**")
            st.caption(DISCLAIMER)


def _group_id(df: pd.DataFrame) -> str:
    col = COL["payer_group_id"]
    if col in df.columns:
        vals = df[col].dropna().unique()
        if len(vals):
            v = vals[0]
            return str(int(v)) if isinstance(v, float) and v.is_integer() else str(v)
    return ""
